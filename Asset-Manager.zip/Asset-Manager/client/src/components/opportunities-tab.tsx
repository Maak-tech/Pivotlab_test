import { useQuery, useMutation } from "@tanstack/react-query";
import { queryClient, apiRequest } from "@/lib/queryClient";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Checkbox } from "@/components/ui/checkbox";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
  DialogDescription,
} from "@/components/ui/dialog";
import { useToast } from "@/hooks/use-toast";
import { RefreshCw, Lightbulb, Loader2, FileText, ChevronDown, ChevronUp, Rocket, Sparkles, Map, X, TrendingUp, TrendingDown, Minus, Zap } from "lucide-react";
import { useState, useCallback } from "react";
import type { Opportunity, Evidence } from "@shared/schema";

type OpportunityWithEvidence = Opportunity & { evidence: Evidence[] };

function ScoreBar({ score, maxScore = 25 }: { score: number; maxScore?: number }) {
  const pct = Math.min(100, (score / maxScore) * 100);
  const color = score >= 15 ? "bg-chart-4" : score >= 10 ? "bg-chart-3" : score >= 5 ? "bg-chart-1" : "bg-muted-foreground";
  return (
    <div className="flex items-center gap-2 min-w-0">
      <div className="w-20 h-1.5 bg-muted rounded-full overflow-hidden flex-shrink-0">
        <div className={`h-full rounded-full ${color}`} style={{ width: `${pct}%` }} />
      </div>
      <span className="text-xs font-semibold tabular-nums">{score.toFixed(1)}</span>
    </div>
  );
}

const SOURCE_LABELS: Record<string, string> = {
  reviews: "Reviews",
  support: "Support",
  analytics: "Analytics",
  jira: "Jira",
  surveys: "Surveys",
  social: "Social",
  internal: "Internal",
  app_reviews: "App Reviews",
  zendesk: "Zendesk",
  intercom: "Intercom",
  ga4: "GA4",
};

function TrendIndicator({ direction, percent }: { direction?: string | null; percent?: number | null }) {
  if (!direction || direction === "stable") {
    return (
      <div className="flex items-center gap-0.5 text-muted-foreground" data-testid="trend-stable">
        <Minus className="w-3 h-3" />
        <span className="text-[10px]">Stable</span>
      </div>
    );
  }
  if (direction === "rising") {
    return (
      <div className="flex items-center gap-0.5 text-destructive" data-testid="trend-rising">
        <TrendingUp className="w-3 h-3" />
        <span className="text-[10px]">+{percent ?? 0}%</span>
      </div>
    );
  }
  if (direction === "falling") {
    return (
      <div className="flex items-center gap-0.5 text-chart-2" data-testid="trend-falling">
        <TrendingDown className="w-3 h-3" />
        <span className="text-[10px]">{percent ?? 0}%</span>
      </div>
    );
  }
  if (direction === "new") {
    return (
      <div className="flex items-center gap-0.5 text-chart-1" data-testid="trend-new">
        <Zap className="w-3 h-3" />
        <span className="text-[10px]">New</span>
      </div>
    );
  }
  return null;
}

function SourceBadges({ breakdown }: { breakdown?: any }) {
  if (!breakdown || !Array.isArray(breakdown)) return null;
  return (
    <div className="flex items-center gap-1 flex-wrap">
      {(breakdown as { source: string; count: number }[]).map((s) => (
        <Badge key={s.source} variant="outline" className="text-[10px]">
          {SOURCE_LABELS[s.source] || s.source} ({s.count})
        </Badge>
      ))}
    </div>
  );
}

function AiTagsRow({ opp }: { opp: OpportunityWithEvidence }) {
  const tags = opp.aiTags as Record<string, any> | null;
  if (!tags) return null;

  return (
    <div className="flex items-center gap-1.5 flex-wrap mt-2" data-testid={`ai-tags-${opp.id}`}>
      <Sparkles className="w-3 h-3 text-muted-foreground flex-shrink-0" />
      {tags.topic && (
        <Badge variant="secondary" className="text-[10px]">{tags.topic}</Badge>
      )}
      {tags.subtopics?.map((s: string) => (
        <Badge key={s} variant="outline" className="text-[10px]">{s}</Badge>
      ))}
      {tags.urgency && (
        <Badge
          variant="outline"
          className={`text-[10px] border-0 ${
            tags.urgency === "high" ? "bg-destructive/10 text-destructive" :
            tags.urgency === "medium" ? "bg-chart-1/10 text-chart-1" :
            "bg-muted text-muted-foreground"
          }`}
        >
          {tags.urgency}
        </Badge>
      )}
      {tags.sentiment && (
        <span className="text-[10px] text-muted-foreground">{tags.sentiment}</span>
      )}
    </div>
  );
}

function AiExplainButton({ opp }: { opp: OpportunityWithEvidence }) {
  const [open, setOpen] = useState(false);
  const [text, setText] = useState("");
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const abortRef = { current: null as AbortController | null };

  const fetchExplanation = useCallback(async () => {
    if (abortRef.current) abortRef.current.abort();
    const controller = new AbortController();
    abortRef.current = controller;

    setText("");
    setError(null);
    setLoading(true);
    try {
      const res = await fetch(`/api/ai/opportunities/${opp.id}/explain`, {
        credentials: "include",
        signal: controller.signal,
      });
      if (!res.ok) {
        const errData = await res.json().catch(() => ({ error: "Request failed" }));
        throw new Error(errData.error || "Failed to explain");
      }
      const reader = res.body?.getReader();
      if (!reader) throw new Error("No response stream");

      const decoder = new TextDecoder();
      let accumulated = "";
      while (true) {
        const { done, value } = await reader.read();
        if (done) break;
        accumulated += decoder.decode(value, { stream: true });
        setText(accumulated);
      }
    } catch (err: any) {
      if (err.name === "AbortError") return;
      setError(err.message);
    } finally {
      setLoading(false);
    }
  }, [opp.id]);

  const handleOpenChange = useCallback((v: boolean) => {
    setOpen(v);
    if (v) {
      fetchExplanation();
    } else {
      if (abortRef.current) abortRef.current.abort();
    }
  }, [fetchExplanation]);

  return (
    <Dialog open={open} onOpenChange={handleOpenChange}>
      <DialogTrigger asChild>
        <Button variant="ghost" size="sm" className="gap-1 text-xs" data-testid={`button-ai-explain-${opp.id}`}>
          <Sparkles className="w-3 h-3" />
          AI Explain
        </Button>
      </DialogTrigger>
      <DialogContent className="max-w-lg">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Sparkles className="w-4 h-4" />
            AI Analysis: {opp.title}
          </DialogTitle>
          <DialogDescription>
            AI-generated analysis of this opportunity
          </DialogDescription>
        </DialogHeader>
        <div className="mt-2 max-h-80 overflow-y-auto">
          {loading && !text && (
            <div className="flex items-center gap-2 text-sm text-muted-foreground">
              <Loader2 className="w-4 h-4 animate-spin" />
              Analyzing opportunity...
            </div>
          )}
          {error && (
            <div className="text-sm text-destructive">{error}</div>
          )}
          {text && (
            <div className="text-sm whitespace-pre-wrap leading-relaxed" data-testid={`text-ai-explanation-${opp.id}`}>
              {text}
              {loading && <span className="inline-block w-1.5 h-4 bg-foreground/60 animate-pulse ml-0.5 align-text-bottom" />}
            </div>
          )}
        </div>
        {opp.aiSummary && (
          <div className="mt-3 pt-3 border-t">
            <p className="text-xs text-muted-foreground mb-1 font-medium">Cached AI Summary</p>
            <p className="text-xs text-muted-foreground">{opp.aiSummary}</p>
          </div>
        )}
      </DialogContent>
    </Dialog>
  );
}

function TurnIntoWorkDialog({ opp, workspaceId }: { opp: OpportunityWithEvidence; workspaceId: string }) {
  const { toast } = useToast();
  const [open, setOpen] = useState(false);
  const [form, setForm] = useState({
    name: opp.title,
    goalKpi: "",
    targetValue: "",
    topics: "",
    createJira: false,
  });

  const mutation = useMutation({
    mutationFn: async () => {
      const topics = form.topics.split(",").map(t => t.trim()).filter(Boolean);
      return apiRequest("POST", "/api/action/turn-into-work", {
        workspaceId,
        opportunityId: opp.id,
        name: form.name,
        goalKpi: form.goalKpi || undefined,
        targetValue: form.targetValue ? parseFloat(form.targetValue) : undefined,
        topics: topics.length > 0 ? topics : undefined,
        createJiraIssue: form.createJira,
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/opportunities", workspaceId] });
      queryClient.invalidateQueries({ queryKey: ["/api/initiatives", workspaceId] });
      queryClient.invalidateQueries({ queryKey: ["/api/dashboard/stats"] });
      setOpen(false);
      toast({ title: "Initiative created from opportunity" });
    },
    onError: (err: any) => {
      toast({ title: "Failed to create", description: err.message, variant: "destructive" });
    },
  });

  return (
    <Dialog open={open} onOpenChange={(v) => { setOpen(v); if (v) setForm({ ...form, name: opp.title }); }}>
      <DialogTrigger asChild>
        <Button variant="outline" size="sm" className="gap-1" data-testid={`button-turn-into-work-${opp.id}`}>
          <Rocket className="w-3 h-3" />
          Turn into work
        </Button>
      </DialogTrigger>
      <DialogContent>
        <DialogHeader>
          <DialogTitle>Turn Opportunity into Work</DialogTitle>
          <DialogDescription>
            Create an initiative from this opportunity. Optionally push to Jira.
          </DialogDescription>
        </DialogHeader>
        <form onSubmit={(e) => { e.preventDefault(); mutation.mutate(); }} className="space-y-4 mt-2">
          <div className="space-y-1.5">
            <Label htmlFor="tiw-name">Initiative Name</Label>
            <Input
              id="tiw-name"
              value={form.name}
              onChange={(e) => setForm({ ...form, name: e.target.value })}
              required
              data-testid="input-tiw-name"
            />
          </div>
          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-1.5">
              <Label htmlFor="tiw-kpi">Goal KPI</Label>
              <Input
                id="tiw-kpi"
                placeholder="e.g., churn rate"
                value={form.goalKpi}
                onChange={(e) => setForm({ ...form, goalKpi: e.target.value })}
                data-testid="input-tiw-kpi"
              />
            </div>
            <div className="space-y-1.5">
              <Label htmlFor="tiw-target">Target Value</Label>
              <Input
                id="tiw-target"
                type="number"
                placeholder="e.g., 5"
                value={form.targetValue}
                onChange={(e) => setForm({ ...form, targetValue: e.target.value })}
                data-testid="input-tiw-target"
              />
            </div>
          </div>
          <div className="space-y-1.5">
            <Label htmlFor="tiw-topics">Topics to Track</Label>
            <Input
              id="tiw-topics"
              placeholder="payments, billing (comma-separated)"
              value={form.topics}
              onChange={(e) => setForm({ ...form, topics: e.target.value })}
              data-testid="input-tiw-topics"
            />
          </div>
          <div className="flex items-center gap-2">
            <Checkbox
              id="tiw-jira"
              checked={form.createJira}
              onCheckedChange={(v) => setForm({ ...form, createJira: !!v })}
              data-testid="checkbox-tiw-jira"
            />
            <Label htmlFor="tiw-jira" className="text-sm">Also create Jira issue (requires Jira connected)</Label>
          </div>
          <div className="bg-muted/50 rounded-md p-3 text-xs text-muted-foreground space-y-1">
            <p className="font-medium text-foreground">What will happen:</p>
            <p>1. Creates an initiative linked to this opportunity</p>
            <p>2. Sets opportunity status to "Planned"</p>
            {form.createJira && <p>3. Creates a Jira story with problem statement + evidence</p>}
          </div>
          <Button type="submit" disabled={mutation.isPending} data-testid="button-tiw-submit">
            {mutation.isPending ? <Loader2 className="w-4 h-4 mr-2 animate-spin" /> : <Rocket className="w-4 h-4 mr-2" />}
            {mutation.isPending ? "Creating..." : "Create Initiative"}
          </Button>
        </form>
      </DialogContent>
    </Dialog>
  );
}

function OpportunityCard({ opp, workspaceId }: { opp: OpportunityWithEvidence; workspaceId: string }) {
  const [expanded, setExpanded] = useState(false);
  const { toast } = useToast();

  const updateStatusMutation = useMutation({
    mutationFn: async (status: string) => {
      await apiRequest("PATCH", `/api/opportunities/${opp.id}`, { status });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/opportunities", workspaceId] });
      queryClient.invalidateQueries({ queryKey: ["/api/dashboard/stats"] });
      toast({ title: "Status updated" });
    },
    onError: (err: any) => {
      toast({ title: "Failed to update", description: err.message, variant: "destructive" });
    },
  });

  return (
    <Card data-testid={`card-opportunity-${opp.id}`}>
      <CardContent className="p-4">
        <div className="flex items-start gap-3">
          <div className="w-10 h-10 rounded-md bg-accent flex items-center justify-center flex-shrink-0">
            <span className="text-sm font-bold text-accent-foreground">{opp.score.toFixed(0)}</span>
          </div>
          <div className="flex-1 min-w-0">
            <div className="flex items-start justify-between gap-2">
              <div className="min-w-0">
                <h3 className="text-sm font-semibold">{opp.title}</h3>
                <p className="text-xs text-muted-foreground mt-0.5 line-clamp-2">{opp.problemStatement}</p>
              </div>
              <div className="flex items-center gap-2 flex-shrink-0">
                <Select value={opp.status} onValueChange={(v) => updateStatusMutation.mutate(v)}>
                  <SelectTrigger className="h-7 text-xs w-24" data-testid={`select-status-${opp.id}`}>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="open">Open</SelectItem>
                    <SelectItem value="planned">Planned</SelectItem>
                    <SelectItem value="shipped">Shipped</SelectItem>
                    <SelectItem value="rejected">Rejected</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>

            <AiTagsRow opp={opp} />

            <div className="flex items-center gap-2 mt-2 flex-wrap">
              <SourceBadges breakdown={opp.sourceBreakdown} />
              {opp.signalCount != null && opp.signalCount > 0 && (
                <span className="text-[10px] text-muted-foreground">{opp.signalCount} signals</span>
              )}
              <TrendIndicator direction={opp.trendDirection} percent={opp.trendPercent} />
            </div>

            <div className="flex items-center gap-4 mt-3 flex-wrap">
              <ScoreBar score={opp.score} />
              <div className="flex items-center gap-1.5">
                <span className="text-xs text-muted-foreground">Confidence:</span>
                <span className="text-xs font-medium">{Math.round(opp.confidence * 100)}%</span>
              </div>
              <AiExplainButton opp={opp} />
              {opp.status === "open" && (
                <TurnIntoWorkDialog opp={opp} workspaceId={workspaceId} />
              )}
              {opp.evidence.length > 0 && (
                <Button
                  variant="ghost"
                  size="sm"
                  className="text-xs gap-1 ml-auto"
                  onClick={() => setExpanded(!expanded)}
                  data-testid={`button-evidence-${opp.id}`}
                >
                  <FileText className="w-3 h-3" />
                  {opp.evidence.length} evidence
                  {expanded ? <ChevronUp className="w-3 h-3" /> : <ChevronDown className="w-3 h-3" />}
                </Button>
              )}
            </div>

            {expanded && opp.evidence.length > 0 && (
              <div className="mt-3 space-y-2 border-t pt-3">
                {opp.evidence.map((e) => (
                  <div key={e.id} className="text-xs bg-muted/50 rounded-md p-2.5">
                    {e.snippet && <p className="text-muted-foreground">{e.snippet}</p>}
                    {e.url && (
                      <a href={e.url} target="_blank" rel="noopener noreferrer" className="text-primary text-xs mt-1 inline-block">
                        View source
                      </a>
                    )}
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>
      </CardContent>
    </Card>
  );
}

type RoadmapItem = {
  title: string;
  why: string;
  expectedImpact: string;
  effortBand: string;
  confidence: number;
  kpi: string;
};

type RoadmapResult = {
  summary: string;
  items: RoadmapItem[];
};

function RoadmapGenerator({ workspaceId }: { workspaceId: string }) {
  const { toast } = useToast();
  const [open, setOpen] = useState(false);
  const [goalKpi, setGoalKpi] = useState("");
  const [budget, setBudget] = useState("");
  const [timelineWeeks, setTimelineWeeks] = useState("");
  const [roadmap, setRoadmap] = useState<RoadmapResult | null>(null);

  const mutation = useMutation({
    mutationFn: async () => {
      const res = await apiRequest("POST", "/api/ai/roadmap", {
        workspaceId,
        goalKpi,
        budget: budget ? parseFloat(budget) : undefined,
        timelineWeeks: timelineWeeks ? parseInt(timelineWeeks) : undefined,
      });
      return res.json();
    },
    onSuccess: (data) => {
      setRoadmap(data.roadmap);
    },
    onError: (err: any) => {
      toast({ title: "Roadmap generation failed", description: err.message, variant: "destructive" });
    },
  });

  const effortColor = (band: string) => {
    if (band === "xs" || band === "s") return "bg-chart-2/10 text-chart-2";
    if (band === "m") return "bg-chart-3/10 text-chart-3";
    return "bg-chart-1/10 text-chart-1";
  };

  return (
    <Dialog open={open} onOpenChange={(v) => { setOpen(v); if (!v) { setRoadmap(null); } }}>
      <DialogTrigger asChild>
        <Button variant="outline" size="sm" className="gap-1.5" data-testid="button-generate-roadmap">
          <Map className="w-4 h-4" />
          AI Roadmap
        </Button>
      </DialogTrigger>
      <DialogContent className="max-w-2xl max-h-[85vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Sparkles className="w-4 h-4" />
            Generate AI Roadmap
          </DialogTitle>
          <DialogDescription>
            AI will prioritize your top opportunities into a sequenced roadmap
          </DialogDescription>
        </DialogHeader>

        {!roadmap ? (
          <div className="space-y-4 mt-2">
            <div className="space-y-1.5">
              <Label htmlFor="rm-kpi">Target KPI</Label>
              <Input
                id="rm-kpi"
                placeholder="e.g., monthly active users, NPS, churn rate"
                value={goalKpi}
                onChange={(e) => setGoalKpi(e.target.value)}
                data-testid="input-roadmap-kpi"
              />
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-1.5">
                <Label htmlFor="rm-budget">Budget (optional)</Label>
                <Input
                  id="rm-budget"
                  type="number"
                  placeholder="e.g., 50000"
                  value={budget}
                  onChange={(e) => setBudget(e.target.value)}
                  data-testid="input-roadmap-budget"
                />
              </div>
              <div className="space-y-1.5">
                <Label htmlFor="rm-weeks">Timeline (weeks, optional)</Label>
                <Input
                  id="rm-weeks"
                  type="number"
                  min="1"
                  max="52"
                  placeholder="e.g., 12"
                  value={timelineWeeks}
                  onChange={(e) => setTimelineWeeks(e.target.value)}
                  data-testid="input-roadmap-weeks"
                />
              </div>
            </div>
            <Button
              onClick={() => mutation.mutate()}
              disabled={mutation.isPending || goalKpi.length < 2}
              data-testid="button-roadmap-submit"
            >
              {mutation.isPending ? (
                <Loader2 className="w-4 h-4 mr-2 animate-spin" />
              ) : (
                <Sparkles className="w-4 h-4 mr-2" />
              )}
              {mutation.isPending ? "Generating..." : "Generate Roadmap"}
            </Button>
          </div>
        ) : (
          <div className="space-y-4 mt-2" data-testid="roadmap-result">
            <div className="bg-muted/50 rounded-md p-3">
              <p className="text-sm">{roadmap.summary}</p>
            </div>
            <div className="space-y-3">
              {roadmap.items.map((item, i) => (
                <div key={i} className="border rounded-md p-3 space-y-2" data-testid={`roadmap-item-${i}`}>
                  <div className="flex items-start justify-between gap-2">
                    <div className="flex items-center gap-2 min-w-0">
                      <span className="text-xs font-bold text-muted-foreground flex-shrink-0">#{i + 1}</span>
                      <h4 className="text-sm font-semibold">{item.title}</h4>
                    </div>
                    <div className="flex items-center gap-1.5 flex-shrink-0">
                      <Badge variant="outline" className={`text-[10px] border-0 ${effortColor(item.effortBand)}`}>
                        {item.effortBand.toUpperCase()}
                      </Badge>
                      <Badge variant="secondary" className="text-[10px]">
                        {Math.round(item.confidence * 100)}%
                      </Badge>
                    </div>
                  </div>
                  <p className="text-xs text-muted-foreground">{item.why}</p>
                  <div className="flex items-center gap-3 text-xs flex-wrap">
                    <span className="text-muted-foreground">Impact: <span className="text-foreground font-medium">{item.expectedImpact}</span></span>
                    <span className="text-muted-foreground">KPI: <span className="text-foreground font-medium">{item.kpi}</span></span>
                  </div>
                </div>
              ))}
            </div>
            <Button variant="outline" size="sm" onClick={() => setRoadmap(null)} data-testid="button-roadmap-reset">
              Generate Another
            </Button>
          </div>
        )}
      </DialogContent>
    </Dialog>
  );
}

export default function OpportunitiesTab({ workspaceId }: { workspaceId: string }) {
  const { toast } = useToast();

  const { data: opportunities, isLoading } = useQuery<OpportunityWithEvidence[]>({
    queryKey: ["/api/opportunities", workspaceId],
  });

  const recomputeMutation = useMutation({
    mutationFn: async () => {
      await apiRequest("POST", `/api/opportunities/recompute?workspaceId=${workspaceId}`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/opportunities", workspaceId] });
      queryClient.invalidateQueries({ queryKey: ["/api/dashboard/stats"] });
      toast({ title: "Opportunities recomputed" });
    },
    onError: (err: any) => {
      toast({ title: "Failed to recompute", description: err.message, variant: "destructive" });
    },
  });

  return (
    <div className="space-y-4">
      <Card data-testid="card-ai-opportunities-banner">
        <CardContent className="p-4">
          <div className="flex items-center gap-3 flex-wrap">
            <div className="flex items-center gap-2 flex-1 min-w-0">
              <Sparkles className="w-4 h-4 text-chart-3 flex-shrink-0" />
              <div className="min-w-0">
                <p className="text-sm font-medium">AI-Powered Analysis</p>
                <p className="text-xs text-muted-foreground">Use AI to explain opportunities or generate a prioritized roadmap</p>
              </div>
            </div>
            <div className="flex items-center gap-2 flex-wrap">
              <RoadmapGenerator workspaceId={workspaceId} />
              <Button
                size="sm"
                variant="outline"
                onClick={() => recomputeMutation.mutate()}
                disabled={recomputeMutation.isPending}
                data-testid="button-recompute"
              >
                {recomputeMutation.isPending ? (
                  <Loader2 className="w-4 h-4 mr-1.5 animate-spin" />
                ) : (
                  <RefreshCw className="w-4 h-4 mr-1.5" />
                )}
                Recompute
              </Button>
            </div>
          </div>
        </CardContent>
      </Card>

      <div className="flex items-center justify-between gap-4 flex-wrap">
        <p className="text-sm text-muted-foreground">{opportunities?.length ?? 0} opportunities found</p>
      </div>

      {isLoading ? (
        <div className="space-y-3">
          {Array.from({ length: 3 }).map((_, i) => (
            <Card key={i}>
              <CardContent className="p-4">
                <div className="flex items-center gap-3">
                  <Skeleton className="w-10 h-10 rounded-md" />
                  <div className="flex-1 space-y-2">
                    <Skeleton className="h-4 w-48" />
                    <Skeleton className="h-3 w-64" />
                    <Skeleton className="h-3 w-32" />
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      ) : opportunities?.length ? (
        <div className="space-y-2">
          {opportunities.map((opp) => (
            <OpportunityCard key={opp.id} opp={opp} workspaceId={workspaceId} />
          ))}
        </div>
      ) : (
        <Card>
          <CardContent className="p-10 text-center">
            <Lightbulb className="w-8 h-8 text-muted-foreground/40 mx-auto mb-3" />
            <h3 className="font-semibold text-sm mb-1">No opportunities yet</h3>
            <p className="text-xs text-muted-foreground mb-4">Add signals and click "Recompute" to generate opportunities</p>
            <Button
              size="sm"
              variant="outline"
              onClick={() => recomputeMutation.mutate()}
              disabled={recomputeMutation.isPending}
              data-testid="button-recompute-empty"
            >
              <RefreshCw className="w-4 h-4 mr-1.5" />
              Recompute Now
            </Button>
          </CardContent>
        </Card>
      )}
    </div>
  );
}

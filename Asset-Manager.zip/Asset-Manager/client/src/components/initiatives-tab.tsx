import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { queryClient, apiRequest } from "@/lib/queryClient";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { Checkbox } from "@/components/ui/checkbox";
import { useToast } from "@/hooks/use-toast";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
  DialogDescription,
} from "@/components/ui/dialog";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Plus, TrendingUp, TrendingDown, Minus, X, Lightbulb, Target, Rocket, Ship, CheckCircle, XCircle, Clock, FileCheck, ExternalLink } from "lucide-react";
import type { Initiative, InitiativeTopic, PivotRecommendation, DecisionRecord, OutcomeCheck } from "@shared/schema";

type InitiativeWithDetails = Initiative & {
  topics: InitiativeTopic[];
  recommendations: PivotRecommendation[];
};

interface TrendData {
  topic: string;
  currentCount: number;
  previousCount: number;
  currentSeverityAvg: number;
  previousSeverityAvg: number;
  changePercent: number;
  direction: "up" | "down" | "flat";
}

interface TrendsResponse {
  trends: TrendData[];
  overallDirection: "improving" | "worsening" | "stable";
}

const statusColors: Record<string, string> = {
  active: "default",
  pivoted: "secondary",
  stopped: "destructive",
  shipped: "outline",
};

const pivotTypeLabels: Record<string, string> = {
  persevere: "Persevere",
  cut_scope: "Cut Scope",
  solution_pivot: "Solution Pivot",
  segment_pivot: "Segment Pivot",
  stop: "Stop",
};

function TrendIcon({ direction }: { direction: "up" | "down" | "flat" }) {
  if (direction === "up") return <TrendingUp className="w-4 h-4 text-destructive" />;
  if (direction === "down") return <TrendingDown className="w-4 h-4 text-green-600 dark:text-green-400" />;
  return <Minus className="w-4 h-4 text-muted-foreground" />;
}

function DecisionRecordDialog({ workspaceId, recommendationId, initiativeId }: {
  workspaceId: string;
  recommendationId?: string;
  initiativeId?: string;
}) {
  const { toast } = useToast();
  const [open, setOpen] = useState(false);
  const [form, setForm] = useState({
    decision: "accepted" as "accepted" | "rejected",
    reason: "",
    expectedKpiImpact: "",
    owner: "",
    dueDate: "",
  });

  const mutation = useMutation({
    mutationFn: async () => {
      return apiRequest("POST", "/api/decisions", {
        workspaceId,
        recommendationId,
        initiativeId,
        decision: form.decision,
        reason: form.reason || undefined,
        expectedKpiImpact: form.expectedKpiImpact || undefined,
        owner: form.owner || undefined,
        dueDate: form.dueDate || undefined,
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/decisions", workspaceId] });
      setOpen(false);
      setForm({ decision: "accepted", reason: "", expectedKpiImpact: "", owner: "", dueDate: "" });
      toast({ title: "Decision recorded" });
    },
    onError: (err: any) => {
      toast({ title: "Failed to record", description: err.message, variant: "destructive" });
    },
  });

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        <Button variant="outline" size="sm" className="gap-1" data-testid={`button-record-decision-${recommendationId || initiativeId}`}>
          <FileCheck className="w-3 h-3" />
          Record Decision
        </Button>
      </DialogTrigger>
      <DialogContent>
        <DialogHeader>
          <DialogTitle>Record Decision</DialogTitle>
          <DialogDescription>
            Log your decision for auditability and team alignment.
          </DialogDescription>
        </DialogHeader>
        <form onSubmit={(e) => { e.preventDefault(); mutation.mutate(); }} className="space-y-4 mt-2">
          <div className="space-y-1.5">
            <Label>Decision</Label>
            <Select value={form.decision} onValueChange={(v: "accepted" | "rejected") => setForm({ ...form, decision: v })}>
              <SelectTrigger data-testid="select-decision">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="accepted">Accepted</SelectItem>
                <SelectItem value="rejected">Rejected</SelectItem>
              </SelectContent>
            </Select>
          </div>
          <div className="space-y-1.5">
            <Label htmlFor="dr-reason">Reason</Label>
            <Textarea
              id="dr-reason"
              placeholder="Why did you make this decision?"
              value={form.reason}
              onChange={(e) => setForm({ ...form, reason: e.target.value })}
              className="resize-none"
              data-testid="input-decision-reason"
            />
          </div>
          <div className="space-y-1.5">
            <Label htmlFor="dr-kpi">Expected KPI Impact</Label>
            <Input
              id="dr-kpi"
              placeholder="e.g., Reduce churn by 5%"
              value={form.expectedKpiImpact}
              onChange={(e) => setForm({ ...form, expectedKpiImpact: e.target.value })}
              data-testid="input-decision-kpi"
            />
          </div>
          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-1.5">
              <Label htmlFor="dr-owner">Owner</Label>
              <Input
                id="dr-owner"
                placeholder="e.g., Jane"
                value={form.owner}
                onChange={(e) => setForm({ ...form, owner: e.target.value })}
                data-testid="input-decision-owner"
              />
            </div>
            <div className="space-y-1.5">
              <Label htmlFor="dr-due">Due Date</Label>
              <Input
                id="dr-due"
                type="date"
                value={form.dueDate}
                onChange={(e) => setForm({ ...form, dueDate: e.target.value })}
                data-testid="input-decision-due"
              />
            </div>
          </div>
          <Button type="submit" disabled={mutation.isPending} data-testid="button-submit-decision">
            {mutation.isPending ? "Saving..." : "Save Decision"}
          </Button>
        </form>
      </DialogContent>
    </Dialog>
  );
}

function OutcomeChecksSection({ initiativeId }: { initiativeId: string }) {
  const { data: checks } = useQuery<OutcomeCheck[]>({
    queryKey: ["/api/outcome-checks", initiativeId],
  });

  if (!checks || checks.length === 0) return null;

  return (
    <div>
      <Label className="text-xs text-muted-foreground mb-2 block">Outcome Checks</Label>
      <div className="space-y-2">
        {checks.map((check) => (
          <div key={check.id} className="flex items-start gap-2 text-xs bg-muted/50 rounded-md p-2.5" data-testid={`outcome-check-${check.id}`}>
            {check.status === "completed" ? (
              <CheckCircle className="w-4 h-4 text-green-600 dark:text-green-400 mt-0.5 shrink-0" />
            ) : check.status === "failed" ? (
              <XCircle className="w-4 h-4 text-destructive mt-0.5 shrink-0" />
            ) : (
              <Clock className="w-4 h-4 text-muted-foreground mt-0.5 shrink-0" />
            )}
            <div className="flex-1 min-w-0 space-y-0.5">
              <div className="flex items-center gap-2 flex-wrap">
                <span className="font-medium">{check.checkType} check</span>
                <Badge variant={check.status === "completed" ? "outline" : check.status === "failed" ? "destructive" : "secondary"} className="text-xs">
                  {check.status}
                </Badge>
                {check.slackNotified && <Badge variant="outline" className="text-xs">Slack notified</Badge>}
              </div>
              {check.resultSummary && (
                <p className="text-muted-foreground">{check.resultSummary}</p>
              )}
              <p className="text-muted-foreground">
                Scheduled: {new Date(check.scheduledAt).toLocaleDateString()}
                {check.completedAt && ` | Completed: ${new Date(check.completedAt).toLocaleDateString()}`}
              </p>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

function TurnRecIntoWorkDialog({ rec, workspaceId, initiativeName }: {
  rec: PivotRecommendation;
  workspaceId: string;
  initiativeName: string;
}) {
  const { toast } = useToast();
  const [open, setOpen] = useState(false);
  const [form, setForm] = useState({
    name: `${initiativeName} - ${pivotTypeLabels[rec.type] || rec.type}`,
    goalKpi: "",
    targetValue: "",
    topics: "",
    createJira: false,
  });

  const mutation = useMutation({
    mutationFn: async () => {
      const topics = form.topics.split(",").map(t => t.trim()).filter(Boolean);
      return apiRequest("POST", "/api/action/turn-into-work", {
        workspaceId,
        recommendationId: rec.id,
        name: form.name,
        goalKpi: form.goalKpi || undefined,
        targetValue: form.targetValue ? parseFloat(form.targetValue) : undefined,
        topics: topics.length > 0 ? topics : undefined,
        createJiraIssue: form.createJira,
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/initiatives", workspaceId] });
      setOpen(false);
      toast({ title: "New initiative created from recommendation" });
    },
    onError: (err: any) => {
      toast({ title: "Failed to create", description: err.message, variant: "destructive" });
    },
  });

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        <Button variant="outline" size="sm" className="gap-1" data-testid={`button-rec-to-work-${rec.id}`}>
          <Rocket className="w-3 h-3" />
          Turn into work
        </Button>
      </DialogTrigger>
      <DialogContent>
        <DialogHeader>
          <DialogTitle>Create Initiative from Recommendation</DialogTitle>
          <DialogDescription>
            Act on this pivot recommendation by creating a new initiative.
          </DialogDescription>
        </DialogHeader>
        <form onSubmit={(e) => { e.preventDefault(); mutation.mutate(); }} className="space-y-4 mt-2">
          <div className="space-y-1.5">
            <Label htmlFor="rec-tiw-name">Initiative Name</Label>
            <Input id="rec-tiw-name" value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} required data-testid="input-rec-tiw-name" />
          </div>
          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-1.5">
              <Label htmlFor="rec-tiw-kpi">Goal KPI</Label>
              <Input id="rec-tiw-kpi" placeholder="e.g., activation" value={form.goalKpi} onChange={(e) => setForm({ ...form, goalKpi: e.target.value })} data-testid="input-rec-tiw-kpi" />
            </div>
            <div className="space-y-1.5">
              <Label htmlFor="rec-tiw-target">Target Value</Label>
              <Input id="rec-tiw-target" type="number" value={form.targetValue} onChange={(e) => setForm({ ...form, targetValue: e.target.value })} data-testid="input-rec-tiw-target" />
            </div>
          </div>
          <div className="space-y-1.5">
            <Label htmlFor="rec-tiw-topics">Topics to Track</Label>
            <Input id="rec-tiw-topics" placeholder="comma-separated" value={form.topics} onChange={(e) => setForm({ ...form, topics: e.target.value })} data-testid="input-rec-tiw-topics" />
          </div>
          <div className="flex items-center gap-2">
            <Checkbox id="rec-tiw-jira" checked={form.createJira} onCheckedChange={(v) => setForm({ ...form, createJira: !!v })} data-testid="checkbox-rec-tiw-jira" />
            <Label htmlFor="rec-tiw-jira" className="text-sm">Also create Jira issue</Label>
          </div>
          <Button type="submit" disabled={mutation.isPending} data-testid="button-rec-tiw-submit">
            <Rocket className="w-4 h-4 mr-2" />
            {mutation.isPending ? "Creating..." : "Create Initiative"}
          </Button>
        </form>
      </DialogContent>
    </Dialog>
  );
}

function InitiativeCard({ initiative, workspaceId }: { initiative: InitiativeWithDetails; workspaceId: string }) {
  const { toast } = useToast();
  const [newTopic, setNewTopic] = useState("");

  const { data: trends } = useQuery<TrendsResponse>({
    queryKey: ["/api/initiatives", initiative.id, "trends"],
    enabled: initiative.status === "active" && initiative.topics.length > 0,
  });

  const { data: decisions } = useQuery<DecisionRecord[]>({
    queryKey: ["/api/decisions", workspaceId],
  });

  const initiativeDecisions = decisions?.filter(d => d.initiativeId === initiative.id) || [];

  const statusMutation = useMutation({
    mutationFn: async (status: string) => {
      return apiRequest("PATCH", `/api/initiatives/${initiative.id}/status`, { status });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/initiatives", workspaceId] });
      toast({ title: "Initiative status updated" });
    },
    onError: (err: any) => {
      toast({ title: "Failed to update status", description: err.message, variant: "destructive" });
    },
  });

  const shipMutation = useMutation({
    mutationFn: async () => {
      return apiRequest("POST", "/api/action/ship", { initiativeId: initiative.id });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/initiatives", workspaceId] });
      queryClient.invalidateQueries({ queryKey: ["/api/opportunities", workspaceId] });
      queryClient.invalidateQueries({ queryKey: ["/api/outcome-checks", initiative.id] });
      toast({ title: "Initiative shipped! Outcome checks scheduled for 7 and 14 days." });
    },
    onError: (err: any) => {
      toast({ title: "Failed to ship", description: err.message, variant: "destructive" });
    },
  });

  const addTopicMutation = useMutation({
    mutationFn: async () => {
      return apiRequest("POST", `/api/initiatives/${initiative.id}/topics`, { topic: newTopic });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/initiatives", workspaceId] });
      queryClient.invalidateQueries({ queryKey: ["/api/initiatives", initiative.id, "trends"] });
      setNewTopic("");
      toast({ title: "Topic added" });
    },
    onError: (err: any) => {
      toast({ title: "Failed to add topic", description: err.message, variant: "destructive" });
    },
  });

  const removeTopicMutation = useMutation({
    mutationFn: async (topicId: string) => {
      return apiRequest("DELETE", `/api/initiatives/topics/${topicId}`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/initiatives", workspaceId] });
      queryClient.invalidateQueries({ queryKey: ["/api/initiatives", initiative.id, "trends"] });
    },
  });

  const daysSinceStart = Math.floor(
    (Date.now() - new Date(initiative.startDate).getTime()) / (1000 * 60 * 60 * 24)
  );

  const latestRec = initiative.recommendations[0];

  return (
    <Card>
      <CardHeader>
        <div className="flex items-start justify-between gap-4 flex-wrap">
          <div className="space-y-1">
            <div className="flex items-center gap-2 flex-wrap">
              <Target className="w-4 h-4 text-muted-foreground" />
              <CardTitle className="text-base" data-testid={`text-initiative-name-${initiative.id}`}>
                {initiative.name}
              </CardTitle>
              <Badge
                variant={statusColors[initiative.status] as any || "default"}
                data-testid={`badge-initiative-status-${initiative.id}`}
              >
                {initiative.status}
              </Badge>
            </div>
            <CardDescription>
              Day {daysSinceStart}
              {initiative.goalKpi && ` \u00B7 KPI: ${initiative.goalKpi}`}
              {initiative.targetValue != null && ` \u00B7 Target: ${initiative.targetValue}`}
              {initiative.jiraIssueKey && (
                <span>
                  {" \u00B7 "}
                  <a href={initiative.jiraIssueUrl || "#"} target="_blank" rel="noopener noreferrer" className="text-primary inline-flex items-center gap-0.5">
                    {initiative.jiraIssueKey} <ExternalLink className="w-3 h-3" />
                  </a>
                </span>
              )}
            </CardDescription>
          </div>
          <div className="flex items-center gap-2 flex-wrap">
            {initiative.status === "active" && (
              <>
                <Button
                  size="sm"
                  onClick={() => shipMutation.mutate()}
                  disabled={shipMutation.isPending}
                  data-testid={`button-ship-${initiative.id}`}
                >
                  <Ship className="w-4 h-4 mr-1" />
                  {shipMutation.isPending ? "Shipping..." : "Ship It"}
                </Button>
                <Select onValueChange={(v) => statusMutation.mutate(v)}>
                  <SelectTrigger className="w-[130px]" data-testid={`select-initiative-status-${initiative.id}`}>
                    <SelectValue placeholder="Update" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="pivoted">Pivoted</SelectItem>
                    <SelectItem value="stopped">Stopped</SelectItem>
                  </SelectContent>
                </Select>
              </>
            )}
          </div>
        </div>
      </CardHeader>
      <CardContent className="space-y-4">
        <div>
          <Label className="text-xs text-muted-foreground mb-2 block">Tracked Topics</Label>
          <div className="flex items-center gap-2 flex-wrap">
            {initiative.topics.map((t) => (
              <Badge key={t.id} variant="secondary" className="gap-1" data-testid={`badge-topic-${t.id}`}>
                {t.topic}
                {initiative.status === "active" && (
                  <button
                    onClick={() => removeTopicMutation.mutate(t.id)}
                    className="ml-0.5 opacity-60 hover:opacity-100"
                    data-testid={`button-remove-topic-${t.id}`}
                  >
                    <X className="w-3 h-3" />
                  </button>
                )}
              </Badge>
            ))}
            {initiative.status === "active" && (
              <form
                onSubmit={(e) => {
                  e.preventDefault();
                  if (newTopic.trim()) addTopicMutation.mutate();
                }}
                className="flex items-center gap-1"
              >
                <Input
                  placeholder="Add topic..."
                  value={newTopic}
                  onChange={(e) => setNewTopic(e.target.value)}
                  className="h-7 w-28 text-xs"
                  data-testid={`input-add-topic-${initiative.id}`}
                />
                <Button
                  type="submit"
                  size="icon"
                  variant="ghost"
                  disabled={!newTopic.trim() || addTopicMutation.isPending}
                  data-testid={`button-add-topic-${initiative.id}`}
                >
                  <Plus className="w-3 h-3" />
                </Button>
              </form>
            )}
          </div>
        </div>

        {trends && trends.trends.length > 0 && (
          <div>
            <Label className="text-xs text-muted-foreground mb-2 block">
              Signal Trends (7-day vs previous 7-day)
            </Label>
            <div className="space-y-2">
              {trends.trends.map((t) => (
                <div
                  key={t.topic}
                  className="flex items-center justify-between gap-4 text-sm"
                  data-testid={`trend-row-${t.topic}`}
                >
                  <span className="font-medium">{t.topic}</span>
                  <div className="flex items-center gap-3">
                    <span className="text-muted-foreground text-xs">
                      {t.previousCount} &rarr; {t.currentCount} signals
                    </span>
                    <span className="text-muted-foreground text-xs">
                      sev: {t.previousSeverityAvg} &rarr; {t.currentSeverityAvg}
                    </span>
                    <div className="flex items-center gap-1">
                      <TrendIcon direction={t.direction} />
                      <span className={`text-xs font-medium ${
                        t.direction === "up" ? "text-destructive" :
                        t.direction === "down" ? "text-green-600 dark:text-green-400" :
                        "text-muted-foreground"
                      }`}>
                        {t.changePercent > 0 ? "+" : ""}{t.changePercent}%
                      </span>
                    </div>
                  </div>
                </div>
              ))}
            </div>
            <div className="mt-2">
              <Badge
                variant={
                  trends.overallDirection === "worsening" ? "destructive" :
                  trends.overallDirection === "improving" ? "outline" : "secondary"
                }
              >
                Overall: {trends.overallDirection}
              </Badge>
            </div>
          </div>
        )}

        {latestRec && (
          <Card className="bg-muted/50">
            <CardContent className="pt-4 pb-3">
              <div className="flex items-start gap-3">
                <Lightbulb className="w-5 h-5 text-amber-500 mt-0.5 shrink-0" />
                <div className="space-y-2 flex-1">
                  <div className="flex items-center gap-2 flex-wrap">
                    <span className="text-sm font-semibold">Pivot Suggestion</span>
                    <Badge variant="outline" data-testid={`badge-rec-type-${latestRec.id}`}>
                      {pivotTypeLabels[latestRec.type] || latestRec.type}
                    </Badge>
                    <span className="text-xs text-muted-foreground">
                      {Math.round(latestRec.confidence * 100)}% confidence
                    </span>
                  </div>
                  <p className="text-sm text-muted-foreground" data-testid={`text-rec-reason-${latestRec.id}`}>
                    {latestRec.reason}
                  </p>
                  <p className="text-xs text-muted-foreground">
                    {new Date(latestRec.createdAt).toLocaleDateString()}
                  </p>
                  <div className="flex items-center gap-2 flex-wrap pt-1">
                    <TurnRecIntoWorkDialog rec={latestRec} workspaceId={workspaceId} initiativeName={initiative.name} />
                    <DecisionRecordDialog workspaceId={workspaceId} recommendationId={latestRec.id} initiativeId={initiative.id} />
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        )}

        {initiative.status === "shipped" && (
          <OutcomeChecksSection initiativeId={initiative.id} />
        )}

        {initiative.shippedAt && (
          <p className="text-xs text-muted-foreground">
            Shipped on {new Date(initiative.shippedAt).toLocaleDateString()}
          </p>
        )}

        {initiativeDecisions.length > 0 && (
          <div>
            <Label className="text-xs text-muted-foreground mb-2 block">Decision Records</Label>
            <div className="space-y-2">
              {initiativeDecisions.map((d) => (
                <div key={d.id} className="text-xs bg-muted/50 rounded-md p-2.5 space-y-1" data-testid={`decision-record-${d.id}`}>
                  <div className="flex items-center gap-2 flex-wrap">
                    {d.decision === "accepted" ? (
                      <CheckCircle className="w-3.5 h-3.5 text-green-600 dark:text-green-400" />
                    ) : (
                      <XCircle className="w-3.5 h-3.5 text-destructive" />
                    )}
                    <span className="font-medium capitalize">{d.decision}</span>
                    {d.owner && <span className="text-muted-foreground">by {d.owner}</span>}
                    {d.dueDate && <span className="text-muted-foreground">due {new Date(d.dueDate).toLocaleDateString()}</span>}
                  </div>
                  {d.reason && <p className="text-muted-foreground">{d.reason}</p>}
                  {d.expectedKpiImpact && <p className="text-muted-foreground">Expected: {d.expectedKpiImpact}</p>}
                </div>
              ))}
            </div>
          </div>
        )}
      </CardContent>
    </Card>
  );
}

export default function InitiativesTab({ workspaceId }: { workspaceId: string }) {
  const { toast } = useToast();
  const [dialogOpen, setDialogOpen] = useState(false);
  const [form, setForm] = useState({
    name: "",
    goalKpi: "",
    targetValue: "",
    endDate: "",
    topics: "",
    dropIfNoImprovementDays: "",
  });

  const { data: initiativesList, isLoading } = useQuery<InitiativeWithDetails[]>({
    queryKey: ["/api/initiatives", workspaceId],
  });

  const createMutation = useMutation({
    mutationFn: async () => {
      const topics = form.topics.split(",").map((t) => t.trim()).filter(Boolean);
      const res = await apiRequest("POST", "/api/initiatives", {
        workspaceId,
        name: form.name,
        goalKpi: form.goalKpi || undefined,
        targetValue: form.targetValue ? parseFloat(form.targetValue) : undefined,
        endDate: form.endDate || undefined,
        topics: topics.length > 0 ? topics : undefined,
        killCriteria: form.dropIfNoImprovementDays
          ? { dropIfNoImprovementDays: parseInt(form.dropIfNoImprovementDays) }
          : undefined,
      });
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/initiatives", workspaceId] });
      setDialogOpen(false);
      setForm({ name: "", goalKpi: "", targetValue: "", endDate: "", topics: "", dropIfNoImprovementDays: "" });
      toast({ title: "Initiative created" });
    },
    onError: (err: any) => {
      toast({ title: "Failed to create initiative", description: err.message, variant: "destructive" });
    },
  });

  if (isLoading) {
    return (
      <div className="space-y-4">
        <Skeleton className="h-32 w-full" />
        <Skeleton className="h-32 w-full" />
      </div>
    );
  }

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between gap-4 flex-wrap">
        <div>
          <h2 className="text-lg font-semibold" data-testid="text-initiatives-title">Initiatives</h2>
          <p className="text-sm text-muted-foreground">Track product initiatives and get pivot recommendations based on signal trends</p>
        </div>
        <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
          <DialogTrigger asChild>
            <Button data-testid="button-create-initiative">
              <Plus className="w-4 h-4 mr-2" />
              New Initiative
            </Button>
          </DialogTrigger>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>Create Initiative</DialogTitle>
              <DialogDescription>
                Track a product initiative and monitor signal trends for pivot recommendations.
              </DialogDescription>
            </DialogHeader>
            <form
              onSubmit={(e) => {
                e.preventDefault();
                createMutation.mutate();
              }}
              className="space-y-4 mt-2"
            >
              <div className="space-y-1.5">
                <Label htmlFor="init-name">Initiative Name</Label>
                <Input
                  id="init-name"
                  placeholder="e.g., Onboarding Redesign"
                  value={form.name}
                  onChange={(e) => setForm({ ...form, name: e.target.value })}
                  required
                  data-testid="input-initiative-name"
                />
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-1.5">
                  <Label htmlFor="init-kpi">Goal KPI</Label>
                  <Input
                    id="init-kpi"
                    placeholder="e.g., activation rate"
                    value={form.goalKpi}
                    onChange={(e) => setForm({ ...form, goalKpi: e.target.value })}
                    data-testid="input-initiative-kpi"
                  />
                </div>
                <div className="space-y-1.5">
                  <Label htmlFor="init-target">Target Value</Label>
                  <Input
                    id="init-target"
                    type="number"
                    placeholder="e.g., 50"
                    value={form.targetValue}
                    onChange={(e) => setForm({ ...form, targetValue: e.target.value })}
                    data-testid="input-initiative-target"
                  />
                </div>
              </div>
              <div className="space-y-1.5">
                <Label htmlFor="init-topics">Topics to Track</Label>
                <Input
                  id="init-topics"
                  placeholder="payments, onboarding, reliability (comma-separated)"
                  value={form.topics}
                  onChange={(e) => setForm({ ...form, topics: e.target.value })}
                  data-testid="input-initiative-topics"
                />
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-1.5">
                  <Label htmlFor="init-end">End Date</Label>
                  <Input
                    id="init-end"
                    type="date"
                    value={form.endDate}
                    onChange={(e) => setForm({ ...form, endDate: e.target.value })}
                    data-testid="input-initiative-enddate"
                  />
                </div>
                <div className="space-y-1.5">
                  <Label htmlFor="init-kill">Kill After (days)</Label>
                  <Input
                    id="init-kill"
                    type="number"
                    placeholder="e.g., 14"
                    value={form.dropIfNoImprovementDays}
                    onChange={(e) => setForm({ ...form, dropIfNoImprovementDays: e.target.value })}
                    data-testid="input-initiative-killdays"
                  />
                </div>
              </div>
              <Button type="submit" disabled={createMutation.isPending} data-testid="button-submit-initiative">
                {createMutation.isPending ? "Creating..." : "Create Initiative"}
              </Button>
            </form>
          </DialogContent>
        </Dialog>
      </div>

      {(!initiativesList || initiativesList.length === 0) ? (
        <Card>
          <CardContent className="py-8 text-center">
            <Target className="w-8 h-8 mx-auto mb-2 text-muted-foreground" />
            <p className="text-muted-foreground">No initiatives yet. Create one to start tracking signal trends.</p>
          </CardContent>
        </Card>
      ) : (
        <div className="space-y-4">
          {initiativesList.map((init) => (
            <InitiativeCard key={init.id} initiative={init} workspaceId={workspaceId} />
          ))}
        </div>
      )}
    </div>
  );
}

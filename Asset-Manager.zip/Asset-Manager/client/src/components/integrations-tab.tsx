import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { queryClient, apiRequest } from "@/lib/queryClient";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { useToast } from "@/hooks/use-toast";
import { Textarea } from "@/components/ui/textarea";
import { RefreshCw, Link2, Unplug, Upload, Headset, MessageSquare, Send, Eye, Zap, BarChart3 } from "lucide-react";

interface JiraStatusResponse {
  connected: boolean;
  enabled?: boolean;
  baseUrl?: string;
  jql?: string;
  lastSyncedAt?: string | null;
}

interface ZendeskStatusResponse {
  connected: boolean;
  enabled?: boolean;
  baseUrl?: string;
  lastSyncedAt?: string | null;
}

interface SlackStatusResponse {
  connected: boolean;
  enabled?: boolean;
  channelName?: string | null;
}

interface Ga4StatusResponse {
  connected: boolean;
  enabled?: boolean;
  propertyId?: string;
  lastSyncedAt?: string | null;
  keyEvents?: string[];
}

export default function IntegrationsTab({ workspaceId }: { workspaceId: string }) {
  const { toast } = useToast();

  const { data: slackStatusData, isLoading: slackLoading } = useQuery<SlackStatusResponse>({
    queryKey: ["/api/integrations/slack/status", workspaceId],
    queryFn: async () => {
      const res = await fetch(`/api/integrations/slack/status?workspaceId=${workspaceId}`, { credentials: "include" });
      if (!res.ok) throw new Error("Failed to fetch Slack status");
      return res.json();
    },
  });

  const { data: jiraStatusData, isLoading: jiraLoading } = useQuery<JiraStatusResponse>({
    queryKey: ["/api/integrations/jira/status", workspaceId],
    queryFn: async () => {
      const res = await fetch(`/api/integrations/jira/status?workspaceId=${workspaceId}`, { credentials: "include" });
      if (!res.ok) throw new Error("Failed to fetch Jira status");
      return res.json();
    },
  });

  const { data: zendeskStatusData, isLoading: zendeskLoading } = useQuery<ZendeskStatusResponse>({
    queryKey: ["/api/integrations/zendesk/status", workspaceId],
    queryFn: async () => {
      const res = await fetch(`/api/integrations/zendesk/status?workspaceId=${workspaceId}`, { credentials: "include" });
      if (!res.ok) throw new Error("Failed to fetch Zendesk status");
      return res.json();
    },
  });

  const [jiraForm, setJiraForm] = useState({
    baseUrl: "",
    email: "",
    apiToken: "",
    jql: "issuetype = Bug AND updated >= -30d ORDER BY updated DESC",
  });

  const [zdForm, setZdForm] = useState({
    baseUrl: "",
    email: "",
    apiToken: "",
    startDaysAgo: "30",
  });

  const [vocJson, setVocJson] = useState("");

  const { data: ga4StatusData, isLoading: ga4Loading } = useQuery<Ga4StatusResponse>({
    queryKey: ["/api/integrations/ga4/status", workspaceId],
    queryFn: async () => {
      const res = await fetch(`/api/integrations/ga4/status?workspaceId=${workspaceId}`, { credentials: "include" });
      if (!res.ok) throw new Error("Failed to fetch GA4 status");
      return res.json();
    },
  });

  const [ga4Form, setGa4Form] = useState({
    propertyId: "",
    keyEvents: "",
  });

  const ga4ConnectMutation = useMutation({
    mutationFn: async () => {
      const keyEvents = ga4Form.keyEvents.trim()
        ? ga4Form.keyEvents.split(",").map((s) => s.trim()).filter(Boolean)
        : undefined;
      return apiRequest("POST", "/api/integrations/ga4/connect", {
        workspaceId,
        propertyId: ga4Form.propertyId,
        keyEvents,
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/integrations/ga4/status", workspaceId] });
      toast({ title: "GA4 connected successfully" });
      setGa4Form({ propertyId: "", keyEvents: "" });
    },
    onError: (err: any) => {
      toast({ title: "Failed to connect GA4", description: err.message, variant: "destructive" });
    },
  });

  const ga4SyncMutation = useMutation({
    mutationFn: async () => {
      const res = await apiRequest("POST", "/api/integrations/ga4/sync", { workspaceId });
      return res.json();
    },
    onSuccess: (data) => {
      queryClient.invalidateQueries({ queryKey: ["/api/integrations/ga4/status", workspaceId] });
      queryClient.invalidateQueries({ queryKey: ["/api/signals", workspaceId] });
      toast({ title: "GA4 sync complete", description: `Generated ${data.fetchedSignals} signals, imported ${data.inserted} new` });
    },
    onError: (err: any) => {
      toast({ title: "GA4 sync failed", description: err.message, variant: "destructive" });
    },
  });

  const [slackForm, setSlackForm] = useState({
    webhookUrl: "",
    channelName: "",
  });

  const [digestPreview, setDigestPreview] = useState<string | null>(null);

  const slackConnectMutation = useMutation({
    mutationFn: async () => {
      return apiRequest("POST", "/api/integrations/slack/connect", {
        workspaceId,
        webhookUrl: slackForm.webhookUrl,
        channelName: slackForm.channelName || undefined,
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/integrations/slack/status", workspaceId] });
      toast({ title: "Slack connected successfully" });
      setSlackForm({ webhookUrl: "", channelName: "" });
    },
    onError: (err: any) => {
      toast({ title: "Failed to connect Slack", description: err.message, variant: "destructive" });
    },
  });

  const slackTestMutation = useMutation({
    mutationFn: async () => {
      return apiRequest("POST", "/api/integrations/slack/test", { workspaceId });
    },
    onSuccess: () => {
      toast({ title: "Test message sent to Slack" });
    },
    onError: (err: any) => {
      toast({ title: "Test failed", description: err.message, variant: "destructive" });
    },
  });

  const slackPreviewMutation = useMutation({
    mutationFn: async () => {
      const res = await apiRequest("POST", "/api/integrations/slack/preview-digest", { workspaceId });
      return res.json();
    },
    onSuccess: (data) => {
      setDigestPreview(data.digest);
    },
    onError: (err: any) => {
      toast({ title: "Preview failed", description: err.message, variant: "destructive" });
    },
  });

  const slackSendDigestMutation = useMutation({
    mutationFn: async () => {
      return apiRequest("POST", "/api/integrations/slack/send-digest", { workspaceId });
    },
    onSuccess: () => {
      toast({ title: "Weekly digest sent to Slack" });
    },
    onError: (err: any) => {
      toast({ title: "Send failed", description: err.message, variant: "destructive" });
    },
  });

  const slackDisconnectMutation = useMutation({
    mutationFn: async () => {
      return apiRequest("POST", "/api/integrations/slack/disconnect", { workspaceId });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/integrations/slack/status", workspaceId] });
      toast({ title: "Slack disconnected" });
      setDigestPreview(null);
    },
    onError: (err: any) => {
      toast({ title: "Failed to disconnect Slack", description: err.message, variant: "destructive" });
    },
  });

  const jiraConnectMutation = useMutation({
    mutationFn: async () => {
      return apiRequest("POST", "/api/integrations/jira/connect", {
        workspaceId,
        baseUrl: jiraForm.baseUrl,
        email: jiraForm.email,
        apiToken: jiraForm.apiToken,
        jql: jiraForm.jql,
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/integrations/jira/status", workspaceId] });
      toast({ title: "Jira connected successfully" });
    },
    onError: (err: any) => {
      toast({ title: "Failed to connect Jira", description: err.message, variant: "destructive" });
    },
  });

  const jiraSyncMutation = useMutation({
    mutationFn: async () => {
      const res = await apiRequest("POST", "/api/integrations/jira/sync", { workspaceId });
      return res.json();
    },
    onSuccess: (data) => {
      queryClient.invalidateQueries({ queryKey: ["/api/integrations/jira/status", workspaceId] });
      queryClient.invalidateQueries({ queryKey: ["/api/signals", workspaceId] });
      toast({ title: "Jira sync complete", description: `Fetched ${data.fetched} issues, imported ${data.inserted} new signals` });
    },
    onError: (err: any) => {
      toast({ title: "Sync failed", description: err.message, variant: "destructive" });
    },
  });

  const zdConnectMutation = useMutation({
    mutationFn: async () => {
      return apiRequest("POST", "/api/integrations/zendesk/connect", {
        workspaceId,
        baseUrl: zdForm.baseUrl,
        email: zdForm.email,
        apiToken: zdForm.apiToken,
        startDaysAgo: parseInt(zdForm.startDaysAgo) || 30,
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/integrations/zendesk/status", workspaceId] });
      toast({ title: "Zendesk connected successfully" });
    },
    onError: (err: any) => {
      toast({ title: "Failed to connect Zendesk", description: err.message, variant: "destructive" });
    },
  });

  const zdSyncMutation = useMutation({
    mutationFn: async () => {
      const res = await apiRequest("POST", "/api/integrations/zendesk/sync", { workspaceId });
      return res.json();
    },
    onSuccess: (data) => {
      queryClient.invalidateQueries({ queryKey: ["/api/integrations/zendesk/status", workspaceId] });
      queryClient.invalidateQueries({ queryKey: ["/api/signals", workspaceId] });
      toast({ title: "Zendesk sync complete", description: `Fetched ${data.fetched} tickets, imported ${data.inserted} new signals` });
    },
    onError: (err: any) => {
      toast({ title: "Zendesk sync failed", description: err.message, variant: "destructive" });
    },
  });

  const vocImportMutation = useMutation({
    mutationFn: async () => {
      let items;
      try {
        const parsed = JSON.parse(vocJson);
        items = Array.isArray(parsed) ? parsed : parsed.items;
      } catch {
        throw new Error("Invalid JSON format");
      }
      if (!items || !Array.isArray(items) || items.length === 0) {
        throw new Error("JSON must contain an array of items with at least a 'title' field");
      }
      const res = await apiRequest("POST", "/api/integrations/voc/import", {
        workspaceId,
        items,
      });
      return res.json();
    },
    onSuccess: (data) => {
      queryClient.invalidateQueries({ queryKey: ["/api/signals", workspaceId] });
      toast({ title: "Reviews imported", description: `Imported ${data.inserted} of ${data.total} items as signals` });
      setVocJson("");
    },
    onError: (err: any) => {
      toast({ title: "Import failed", description: err.message, variant: "destructive" });
    },
  });

  if (jiraLoading || zendeskLoading || slackLoading || ga4Loading) {
    return (
      <div className="space-y-4">
        <Skeleton className="h-48 w-full" />
        <Skeleton className="h-48 w-full" />
      </div>
    );
  }

  const jiraConnected = jiraStatusData?.connected;
  const zdConnected = zendeskStatusData?.connected;
  const slackConnected = slackStatusData?.connected;
  const ga4Connected = ga4StatusData?.connected;

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <div className="flex items-center justify-between gap-4 flex-wrap">
            <div className="flex items-center gap-3">
              <Link2 className="w-5 h-5 text-muted-foreground" />
              <div>
                <CardTitle className="text-base">Jira Integration</CardTitle>
                <CardDescription>Import issues from Jira as signals</CardDescription>
              </div>
            </div>
            {jiraConnected && (
              <Badge variant="secondary" data-testid="badge-jira-connected">Connected</Badge>
            )}
          </div>
        </CardHeader>
        <CardContent>
          {jiraConnected ? (
            <div className="space-y-4">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <Label className="text-xs text-muted-foreground">Base URL</Label>
                  <p className="text-sm font-medium mt-0.5" data-testid="text-jira-baseurl">{jiraStatusData.baseUrl}</p>
                </div>
                <div>
                  <Label className="text-xs text-muted-foreground">Last Synced</Label>
                  <p className="text-sm font-medium mt-0.5" data-testid="text-jira-last-synced">
                    {jiraStatusData.lastSyncedAt
                      ? new Date(jiraStatusData.lastSyncedAt).toLocaleString()
                      : "Never"}
                  </p>
                </div>
              </div>
              <div>
                <Label className="text-xs text-muted-foreground">JQL Query</Label>
                <p className="text-sm font-mono mt-0.5 break-all" data-testid="text-jira-jql">{jiraStatusData.jql}</p>
              </div>
              <div className="flex items-center gap-2 flex-wrap pt-2">
                <Button
                  onClick={() => jiraSyncMutation.mutate()}
                  disabled={jiraSyncMutation.isPending}
                  data-testid="button-jira-sync"
                >
                  <RefreshCw className={`w-4 h-4 mr-2 ${jiraSyncMutation.isPending ? "animate-spin" : ""}`} />
                  {jiraSyncMutation.isPending ? "Syncing..." : "Sync Now"}
                </Button>
                <Button
                  variant="outline"
                  onClick={() => {
                    setJiraForm({
                      baseUrl: jiraStatusData.baseUrl || "",
                      email: "",
                      apiToken: "",
                      jql: jiraStatusData.jql || "",
                    });
                    queryClient.setQueryData(
                      ["/api/integrations/jira/status", workspaceId],
                      { connected: false }
                    );
                  }}
                  data-testid="button-jira-reconfigure"
                >
                  <Unplug className="w-4 h-4 mr-2" />
                  Reconfigure
                </Button>
              </div>
            </div>
          ) : (
            <form
              onSubmit={(e) => {
                e.preventDefault();
                jiraConnectMutation.mutate();
              }}
              className="space-y-4"
            >
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div className="space-y-1.5">
                  <Label htmlFor="jira-base-url">Jira Base URL</Label>
                  <Input
                    id="jira-base-url"
                    placeholder="https://yourcompany.atlassian.net"
                    value={jiraForm.baseUrl}
                    onChange={(e) => setJiraForm({ ...jiraForm, baseUrl: e.target.value })}
                    required
                    data-testid="input-jira-baseurl"
                  />
                </div>
                <div className="space-y-1.5">
                  <Label htmlFor="jira-email">Email</Label>
                  <Input
                    id="jira-email"
                    type="email"
                    placeholder="you@company.com"
                    value={jiraForm.email}
                    onChange={(e) => setJiraForm({ ...jiraForm, email: e.target.value })}
                    required
                    data-testid="input-jira-email"
                  />
                </div>
              </div>
              <div className="space-y-1.5">
                <Label htmlFor="jira-api-token">API Token</Label>
                <Input
                  id="jira-api-token"
                  type="password"
                  placeholder="Your Jira API token"
                  value={jiraForm.apiToken}
                  onChange={(e) => setJiraForm({ ...jiraForm, apiToken: e.target.value })}
                  required
                  data-testid="input-jira-apitoken"
                />
              </div>
              <div className="space-y-1.5">
                <Label htmlFor="jira-jql">JQL Query</Label>
                <Input
                  id="jira-jql"
                  placeholder="issuetype = Bug AND updated >= -30d"
                  value={jiraForm.jql}
                  onChange={(e) => setJiraForm({ ...jiraForm, jql: e.target.value })}
                  data-testid="input-jira-jql"
                />
              </div>
              <Button type="submit" disabled={jiraConnectMutation.isPending} data-testid="button-jira-connect">
                {jiraConnectMutation.isPending ? "Connecting..." : "Connect Jira"}
              </Button>
            </form>
          )}
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <div className="flex items-center justify-between gap-4 flex-wrap">
            <div className="flex items-center gap-3">
              <Headset className="w-5 h-5 text-muted-foreground" />
              <div>
                <CardTitle className="text-base">Zendesk Integration</CardTitle>
                <CardDescription>Import support tickets from Zendesk as signals</CardDescription>
              </div>
            </div>
            {zdConnected && (
              <Badge variant="secondary" data-testid="badge-zendesk-connected">Connected</Badge>
            )}
          </div>
        </CardHeader>
        <CardContent>
          {zdConnected ? (
            <div className="space-y-4">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <Label className="text-xs text-muted-foreground">Base URL</Label>
                  <p className="text-sm font-medium mt-0.5" data-testid="text-zendesk-baseurl">{zendeskStatusData.baseUrl}</p>
                </div>
                <div>
                  <Label className="text-xs text-muted-foreground">Last Synced</Label>
                  <p className="text-sm font-medium mt-0.5" data-testid="text-zendesk-last-synced">
                    {zendeskStatusData.lastSyncedAt
                      ? new Date(zendeskStatusData.lastSyncedAt).toLocaleString()
                      : "Never"}
                  </p>
                </div>
              </div>
              <div className="flex items-center gap-2 flex-wrap pt-2">
                <Button
                  onClick={() => zdSyncMutation.mutate()}
                  disabled={zdSyncMutation.isPending}
                  data-testid="button-zendesk-sync"
                >
                  <RefreshCw className={`w-4 h-4 mr-2 ${zdSyncMutation.isPending ? "animate-spin" : ""}`} />
                  {zdSyncMutation.isPending ? "Syncing..." : "Sync Now"}
                </Button>
                <Button
                  variant="outline"
                  onClick={() => {
                    setZdForm({
                      baseUrl: zendeskStatusData.baseUrl || "",
                      email: "",
                      apiToken: "",
                      startDaysAgo: "30",
                    });
                    queryClient.setQueryData(
                      ["/api/integrations/zendesk/status", workspaceId],
                      { connected: false }
                    );
                  }}
                  data-testid="button-zendesk-reconfigure"
                >
                  <Unplug className="w-4 h-4 mr-2" />
                  Reconfigure
                </Button>
              </div>
            </div>
          ) : (
            <form
              onSubmit={(e) => {
                e.preventDefault();
                zdConnectMutation.mutate();
              }}
              className="space-y-4"
            >
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div className="space-y-1.5">
                  <Label htmlFor="zd-base-url">Zendesk URL</Label>
                  <Input
                    id="zd-base-url"
                    placeholder="https://yourcompany.zendesk.com"
                    value={zdForm.baseUrl}
                    onChange={(e) => setZdForm({ ...zdForm, baseUrl: e.target.value })}
                    required
                    data-testid="input-zendesk-baseurl"
                  />
                </div>
                <div className="space-y-1.5">
                  <Label htmlFor="zd-email">Agent Email</Label>
                  <Input
                    id="zd-email"
                    type="email"
                    placeholder="agent@company.com"
                    value={zdForm.email}
                    onChange={(e) => setZdForm({ ...zdForm, email: e.target.value })}
                    required
                    data-testid="input-zendesk-email"
                  />
                </div>
              </div>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div className="space-y-1.5">
                  <Label htmlFor="zd-api-token">API Token</Label>
                  <Input
                    id="zd-api-token"
                    type="password"
                    placeholder="Your Zendesk API token"
                    value={zdForm.apiToken}
                    onChange={(e) => setZdForm({ ...zdForm, apiToken: e.target.value })}
                    required
                    data-testid="input-zendesk-apitoken"
                  />
                </div>
                <div className="space-y-1.5">
                  <Label htmlFor="zd-days">Import Last N Days</Label>
                  <Input
                    id="zd-days"
                    type="number"
                    min="1"
                    max="365"
                    placeholder="30"
                    value={zdForm.startDaysAgo}
                    onChange={(e) => setZdForm({ ...zdForm, startDaysAgo: e.target.value })}
                    data-testid="input-zendesk-days"
                  />
                </div>
              </div>
              <Button type="submit" disabled={zdConnectMutation.isPending} data-testid="button-zendesk-connect">
                {zdConnectMutation.isPending ? "Connecting..." : "Connect Zendesk"}
              </Button>
            </form>
          )}
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <div className="flex items-center gap-3">
            <Upload className="w-5 h-5 text-muted-foreground" />
            <div>
              <CardTitle className="text-base">Review Import</CardTitle>
              <CardDescription>Import customer reviews or feedback as signals via JSON</CardDescription>
            </div>
          </div>
        </CardHeader>
        <CardContent>
          <form
            onSubmit={(e) => {
              e.preventDefault();
              vocImportMutation.mutate();
            }}
            className="space-y-4"
          >
            <div className="space-y-1.5">
              <Label htmlFor="voc-json">JSON Data</Label>
              <Textarea
                id="voc-json"
                placeholder={`[
  {"rating": 1, "title": "App crashes on login", "body": "Crashes every time", "source": "app_reviews"},
  {"rating": 3, "title": "Slow loading", "body": "Takes 10s to load dashboard", "topic": "performance"}
]`}
                value={vocJson}
                onChange={(e) => setVocJson(e.target.value)}
                className="font-mono text-xs min-h-[120px]"
                required
                data-testid="textarea-voc-json"
              />
              <p className="text-xs text-muted-foreground">
                Each item needs a <code className="text-xs">title</code>. Optional: <code className="text-xs">rating</code> (1-5), <code className="text-xs">body</code>, <code className="text-xs">url</code>, <code className="text-xs">source</code>, <code className="text-xs">topic</code>
              </p>
            </div>
            <Button type="submit" disabled={vocImportMutation.isPending} data-testid="button-voc-import">
              <Upload className="w-4 h-4 mr-2" />
              {vocImportMutation.isPending ? "Importing..." : "Import Reviews"}
            </Button>
          </form>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <div className="flex items-center justify-between gap-4 flex-wrap">
            <div className="flex items-center gap-3">
              <BarChart3 className="w-5 h-5 text-muted-foreground" />
              <div>
                <CardTitle className="text-base">Google Analytics (GA4)</CardTitle>
                <CardDescription>Import analytics signals from GA4 Data API</CardDescription>
              </div>
            </div>
            {ga4Connected && (
              <Badge variant="secondary" data-testid="badge-ga4-connected">Connected</Badge>
            )}
          </div>
        </CardHeader>
        <CardContent>
          {ga4Connected ? (
            <div className="space-y-4">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <Label className="text-xs text-muted-foreground">Property ID</Label>
                  <p className="text-sm font-medium mt-0.5" data-testid="text-ga4-property">{ga4StatusData.propertyId}</p>
                </div>
                <div>
                  <Label className="text-xs text-muted-foreground">Last Synced</Label>
                  <p className="text-sm font-medium mt-0.5" data-testid="text-ga4-last-synced">
                    {ga4StatusData.lastSyncedAt
                      ? new Date(ga4StatusData.lastSyncedAt).toLocaleString()
                      : "Never"}
                  </p>
                </div>
              </div>
              {Array.isArray(ga4StatusData.keyEvents) && ga4StatusData.keyEvents.length > 0 && (
                <div>
                  <Label className="text-xs text-muted-foreground">Key Events</Label>
                  <div className="flex items-center gap-1.5 flex-wrap mt-1">
                    {ga4StatusData.keyEvents.map((ev: string) => (
                      <Badge key={ev} variant="outline" className="text-xs">{ev}</Badge>
                    ))}
                  </div>
                </div>
              )}
              <p className="text-xs text-muted-foreground">
                Sync compares last 7 days vs previous 7 days. Drops in sessions, users, or key events become analytics signals that flow into opportunity scoring.
              </p>
              <div className="flex items-center gap-2 flex-wrap pt-2">
                <Button
                  onClick={() => ga4SyncMutation.mutate()}
                  disabled={ga4SyncMutation.isPending}
                  data-testid="button-ga4-sync"
                >
                  <RefreshCw className={`w-4 h-4 mr-2 ${ga4SyncMutation.isPending ? "animate-spin" : ""}`} />
                  {ga4SyncMutation.isPending ? "Syncing..." : "Sync Now"}
                </Button>
                <Button
                  variant="outline"
                  onClick={() => {
                    setGa4Form({
                      propertyId: ga4StatusData.propertyId || "",
                      keyEvents: Array.isArray(ga4StatusData.keyEvents) ? ga4StatusData.keyEvents.join(", ") : "",
                    });
                    queryClient.setQueryData(
                      ["/api/integrations/ga4/status", workspaceId],
                      { connected: false }
                    );
                  }}
                  data-testid="button-ga4-reconfigure"
                >
                  <Unplug className="w-4 h-4 mr-2" />
                  Reconfigure
                </Button>
              </div>
            </div>
          ) : (
            <form
              onSubmit={(e) => {
                e.preventDefault();
                ga4ConnectMutation.mutate();
              }}
              className="space-y-4"
            >
              <div className="space-y-1.5">
                <Label htmlFor="ga4-property-id">GA4 Property ID</Label>
                <Input
                  id="ga4-property-id"
                  placeholder="123456789"
                  value={ga4Form.propertyId}
                  onChange={(e) => setGa4Form({ ...ga4Form, propertyId: e.target.value })}
                  required
                  data-testid="input-ga4-property"
                />
                <p className="text-xs text-muted-foreground">
                  The numeric Property ID from GA4 Admin (not the Measurement ID starting with G-).
                </p>
              </div>
              <div className="space-y-1.5">
                <Label htmlFor="ga4-key-events">Key Events (optional, comma-separated)</Label>
                <Input
                  id="ga4-key-events"
                  placeholder="sign_up, purchase, add_to_cart"
                  value={ga4Form.keyEvents}
                  onChange={(e) => setGa4Form({ ...ga4Form, keyEvents: e.target.value })}
                  data-testid="input-ga4-events"
                />
                <p className="text-xs text-muted-foreground">
                  Specific events to monitor. Leave blank to auto-detect top events.
                </p>
              </div>
              <Button type="submit" disabled={ga4ConnectMutation.isPending} data-testid="button-ga4-connect">
                <BarChart3 className="w-4 h-4 mr-2" />
                {ga4ConnectMutation.isPending ? "Connecting..." : "Connect GA4"}
              </Button>
            </form>
          )}
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <div className="flex items-center justify-between gap-4 flex-wrap">
            <div className="flex items-center gap-3">
              <MessageSquare className="w-5 h-5 text-muted-foreground" />
              <div>
                <CardTitle className="text-base">Slack Integration</CardTitle>
                <CardDescription>Weekly digests and real-time pivot alerts via Slack webhook</CardDescription>
              </div>
            </div>
            {slackConnected && (
              <Badge variant="secondary" data-testid="badge-slack-connected">Connected</Badge>
            )}
          </div>
        </CardHeader>
        <CardContent>
          {slackConnected ? (
            <div className="space-y-4">
              {slackStatusData?.channelName && (
                <div>
                  <Label className="text-xs text-muted-foreground">Channel</Label>
                  <p className="text-sm font-medium mt-0.5" data-testid="text-slack-channel">#{slackStatusData.channelName}</p>
                </div>
              )}
              <div className="space-y-3">
                <p className="text-sm text-muted-foreground">
                  PivotLab will automatically post weekly opportunity digests and real-time pivot alerts to your Slack channel.
                </p>
                <div className="flex items-center gap-2 flex-wrap">
                  <Button
                    variant="outline"
                    onClick={() => slackTestMutation.mutate()}
                    disabled={slackTestMutation.isPending}
                    data-testid="button-slack-test"
                  >
                    <Zap className="w-4 h-4 mr-2" />
                    {slackTestMutation.isPending ? "Sending..." : "Send Test"}
                  </Button>
                  <Button
                    variant="outline"
                    onClick={() => slackPreviewMutation.mutate()}
                    disabled={slackPreviewMutation.isPending}
                    data-testid="button-slack-preview"
                  >
                    <Eye className="w-4 h-4 mr-2" />
                    {slackPreviewMutation.isPending ? "Loading..." : "Preview Digest"}
                  </Button>
                  <Button
                    onClick={() => slackSendDigestMutation.mutate()}
                    disabled={slackSendDigestMutation.isPending}
                    data-testid="button-slack-send-digest"
                  >
                    <Send className="w-4 h-4 mr-2" />
                    {slackSendDigestMutation.isPending ? "Sending..." : "Send Digest Now"}
                  </Button>
                  <Button
                    variant="outline"
                    onClick={() => slackDisconnectMutation.mutate()}
                    disabled={slackDisconnectMutation.isPending}
                    data-testid="button-slack-disconnect"
                  >
                    <Unplug className="w-4 h-4 mr-2" />
                    Disconnect
                  </Button>
                </div>
              </div>
              {digestPreview && (
                <div className="mt-4">
                  <Label className="text-xs text-muted-foreground">Digest Preview</Label>
                  <pre className="mt-1.5 text-xs whitespace-pre-wrap bg-muted/50 rounded-md p-3 border" data-testid="text-digest-preview">
                    {digestPreview}
                  </pre>
                </div>
              )}
            </div>
          ) : (
            <form
              onSubmit={(e) => {
                e.preventDefault();
                slackConnectMutation.mutate();
              }}
              className="space-y-4"
            >
              <div className="space-y-1.5">
                <Label htmlFor="slack-webhook">Webhook URL</Label>
                <Input
                  id="slack-webhook"
                  type="url"
                  placeholder="https://hooks.slack.com/services/T.../B.../..."
                  value={slackForm.webhookUrl}
                  onChange={(e) => setSlackForm({ ...slackForm, webhookUrl: e.target.value })}
                  required
                  data-testid="input-slack-webhook"
                />
                <p className="text-xs text-muted-foreground">
                  Create an Incoming Webhook in your Slack workspace settings, then paste the URL here.
                </p>
              </div>
              <div className="space-y-1.5">
                <Label htmlFor="slack-channel">Channel Name (optional)</Label>
                <Input
                  id="slack-channel"
                  placeholder="product-signals"
                  value={slackForm.channelName}
                  onChange={(e) => setSlackForm({ ...slackForm, channelName: e.target.value })}
                  data-testid="input-slack-channel"
                />
              </div>
              <Button type="submit" disabled={slackConnectMutation.isPending} data-testid="button-slack-connect">
                <MessageSquare className="w-4 h-4 mr-2" />
                {slackConnectMutation.isPending ? "Connecting..." : "Connect Slack"}
              </Button>
            </form>
          )}
        </CardContent>
      </Card>
    </div>
  );
}

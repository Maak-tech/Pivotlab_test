import { useState, useEffect } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { queryClient, apiRequest } from "@/lib/queryClient";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { useToast } from "@/hooks/use-toast";
import { Save, Loader2, Target, DollarSign, Calendar, TrendingUp } from "lucide-react";
import type { Constraint } from "@shared/schema";

export default function ConstraintsTab({ workspaceId }: { workspaceId: string }) {
  const { toast } = useToast();

  const { data: constraint, isLoading } = useQuery<Constraint | null>({
    queryKey: ["/api/workspaces", workspaceId, "constraints"],
    queryFn: async () => {
      const res = await fetch(`/api/workspaces/${workspaceId}/constraints`, { credentials: "include" });
      if (res.status === 404) return null;
      if (!res.ok) throw new Error("Failed to fetch constraints");
      return res.json();
    },
  });

  const [form, setForm] = useState({
    primaryKpi: "",
    targetValue: "",
    budgetCap: "",
    deadlineDate: "",
  });

  useEffect(() => {
    if (constraint) {
      setForm({
        primaryKpi: constraint.primaryKpi || "",
        targetValue: constraint.targetValue ? String(constraint.targetValue) : "",
        budgetCap: constraint.budgetCap ? String(constraint.budgetCap) : "",
        deadlineDate: constraint.deadlineDate
          ? new Date(constraint.deadlineDate).toISOString().split("T")[0]
          : "",
      });
    }
  }, [constraint]);

  const saveMutation = useMutation({
    mutationFn: async () => {
      await apiRequest("PUT", `/api/workspaces/${workspaceId}/constraints`, {
        primaryKpi: form.primaryKpi || undefined,
        targetValue: form.targetValue ? Number(form.targetValue) : undefined,
        budgetCap: form.budgetCap ? Number(form.budgetCap) : undefined,
        deadlineDate: form.deadlineDate ? new Date(form.deadlineDate).toISOString() : undefined,
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/workspaces", workspaceId, "constraints"] });
      toast({ title: "Constraints saved" });
    },
    onError: (err: any) => {
      toast({ title: "Failed to save constraints", description: err.message, variant: "destructive" });
    },
  });

  if (isLoading) {
    return (
      <Card>
        <CardContent className="p-6 space-y-4">
          <div className="h-6 w-32 bg-muted rounded animate-pulse" />
          <div className="h-10 w-full bg-muted rounded animate-pulse" />
          <div className="h-10 w-full bg-muted rounded animate-pulse" />
        </CardContent>
      </Card>
    );
  }

  return (
    <div className="max-w-2xl space-y-4">
      <p className="text-sm text-muted-foreground">
        Define your business constraints to influence opportunity scoring. Opportunities mentioning your KPI get a boost.
      </p>

      <Card>
        <CardHeader className="pb-4">
          <CardTitle className="text-base">Business Constraints</CardTitle>
        </CardHeader>
        <CardContent>
          <form
            onSubmit={(e) => {
              e.preventDefault();
              saveMutation.mutate();
            }}
            className="space-y-5"
          >
            <div className="space-y-2">
              <Label className="flex items-center gap-2">
                <Target className="w-3.5 h-3.5 text-muted-foreground" />
                Primary KPI
              </Label>
              <Input
                data-testid="input-kpi"
                value={form.primaryKpi}
                onChange={(e) => setForm({ ...form, primaryKpi: e.target.value })}
                placeholder="e.g., conversion rate, NPS, revenue"
              />
              <p className="text-xs text-muted-foreground">Opportunities mentioning this KPI get a +5 score boost</p>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label className="flex items-center gap-2">
                  <TrendingUp className="w-3.5 h-3.5 text-muted-foreground" />
                  Target Value
                </Label>
                <Input
                  data-testid="input-target"
                  type="number"
                  step="any"
                  value={form.targetValue}
                  onChange={(e) => setForm({ ...form, targetValue: e.target.value })}
                  placeholder="e.g., 50"
                />
              </div>

              <div className="space-y-2">
                <Label className="flex items-center gap-2">
                  <DollarSign className="w-3.5 h-3.5 text-muted-foreground" />
                  Budget Cap
                </Label>
                <Input
                  data-testid="input-budget"
                  type="number"
                  step="any"
                  value={form.budgetCap}
                  onChange={(e) => setForm({ ...form, budgetCap: e.target.value })}
                  placeholder="e.g., 100000"
                />
              </div>
            </div>

            <div className="space-y-2">
              <Label className="flex items-center gap-2">
                <Calendar className="w-3.5 h-3.5 text-muted-foreground" />
                Deadline
              </Label>
              <Input
                data-testid="input-deadline"
                type="date"
                value={form.deadlineDate}
                onChange={(e) => setForm({ ...form, deadlineDate: e.target.value })}
              />
            </div>

            <Button type="submit" disabled={saveMutation.isPending} data-testid="button-save-constraints">
              {saveMutation.isPending ? (
                <Loader2 className="mr-2 h-4 w-4 animate-spin" />
              ) : (
                <Save className="mr-2 h-4 w-4" />
              )}
              Save Constraints
            </Button>
          </form>
        </CardContent>
      </Card>
    </div>
  );
}

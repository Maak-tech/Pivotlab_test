import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { queryClient, apiRequest } from "@/lib/queryClient";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { useToast } from "@/hooks/use-toast";
import { Plus, Signal, AlertTriangle, Loader2, ExternalLink, Sparkles, Wand2 } from "lucide-react";
import { format } from "date-fns";
import type { Signal as SignalType } from "@shared/schema";

const SOURCE_LABELS: Record<string, string> = {
  reviews: "Reviews",
  support: "Support",
  analytics: "Analytics",
  jira: "Jira",
  surveys: "Surveys",
  social: "Social",
  internal: "Internal",
};

const KIND_LABELS: Record<string, string> = {
  voc: "Voice of Customer",
  metric: "Metric",
  delivery: "Delivery",
};

function SeverityDots({ severity }: { severity: number }) {
  return (
    <div className="flex items-center gap-0.5">
      {Array.from({ length: 5 }).map((_, i) => (
        <div
          key={i}
          className={`w-1.5 h-1.5 rounded-full ${
            i < severity
              ? severity >= 4
                ? "bg-chart-4"
                : severity >= 3
                  ? "bg-chart-3"
                  : "bg-chart-2"
              : "bg-muted"
          }`}
        />
      ))}
    </div>
  );
}

function AiAnalyzeWidget() {
  const [text, setText] = useState("");
  const [result, setResult] = useState<any>(null);
  const [expanded, setExpanded] = useState(false);

  const mutation = useMutation({
    mutationFn: async () => {
      const res = await apiRequest("POST", "/api/ai/theme", { text });
      const data = await res.json().catch(() => null);
      if (!data) throw new Error("Invalid response from AI");
      return data;
    },
    onSuccess: (data) => {
      setResult(data);
    },
  });

  return (
    <Card data-testid="card-ai-analyze-signals">
      <CardContent className="p-4">
        <button
          type="button"
          className="flex items-center gap-2 w-full text-left"
          onClick={() => setExpanded(!expanded)}
          data-testid="button-toggle-ai-analyze"
        >
          <Sparkles className="w-4 h-4 text-chart-3 flex-shrink-0" />
          <span className="text-sm font-medium flex-1">AI Signal Analyzer</span>
          <Badge variant="outline" className="text-[10px] border-0 bg-chart-3/10 text-chart-3">AI</Badge>
        </button>
        {expanded && (
          <div className="mt-3 space-y-3 border-t pt-3">
            <p className="text-xs text-muted-foreground">
              Paste customer feedback to extract themes, sentiment, and urgency before adding as a signal.
            </p>
            <Textarea
              data-testid="input-ai-signal-text"
              placeholder="Paste a customer review, support ticket, or feedback..."
              value={text}
              onChange={(e) => setText(e.target.value)}
              rows={3}
              className="resize-none text-sm"
            />
            <Button
              size="sm"
              onClick={() => mutation.mutate()}
              disabled={mutation.isPending || text.length < 10}
              data-testid="button-ai-signal-analyze"
            >
              {mutation.isPending ? (
                <Loader2 className="w-4 h-4 mr-1.5 animate-spin" />
              ) : (
                <Wand2 className="w-4 h-4 mr-1.5" />
              )}
              {mutation.isPending ? "Analyzing..." : "Extract Themes"}
            </Button>
            {result && (
              <div className="border rounded-md p-3 space-y-2 bg-muted/30" data-testid="ai-signal-result">
                <div className="flex items-center gap-2 flex-wrap">
                  <Badge variant="secondary">{result.topic || "Unknown"}</Badge>
                  {result.sentiment && (
                    <Badge variant="outline" className="text-xs">{result.sentiment}</Badge>
                  )}
                  {result.urgency && (
                    <Badge
                      variant="outline"
                      className={`text-xs border-0 ${
                        result.urgency === "high" ? "bg-destructive/10 text-destructive" :
                        result.urgency === "medium" ? "bg-chart-1/10 text-chart-1" :
                        "bg-muted text-muted-foreground"
                      }`}
                    >
                      {result.urgency} urgency
                    </Badge>
                  )}
                </div>
                {result.subtopics?.length > 0 && (
                  <div className="flex items-center gap-1 flex-wrap">
                    <span className="text-xs text-muted-foreground">Subtopics:</span>
                    {result.subtopics.map((s: string) => (
                      <Badge key={s} variant="outline" className="text-[10px]">{s}</Badge>
                    ))}
                  </div>
                )}
                {result.userPain && (
                  <p className="text-xs text-muted-foreground">
                    <span className="font-medium text-foreground">User Pain:</span> {result.userPain}
                  </p>
                )}
                {result.kpiHints?.length > 0 && (
                  <div className="flex items-center gap-1 flex-wrap">
                    <span className="text-xs text-muted-foreground">KPI Hints:</span>
                    {result.kpiHints.map((k: string) => (
                      <span key={k} className="text-xs text-foreground font-medium">{k}</span>
                    ))}
                  </div>
                )}
              </div>
            )}
            {mutation.isError && (
              <p className="text-xs text-destructive">AI analysis requires an OpenAI API key.</p>
            )}
          </div>
        )}
      </CardContent>
    </Card>
  );
}

export default function SignalsTab({ workspaceId }: { workspaceId: string }) {
  const { toast } = useToast();
  const [open, setOpen] = useState(false);
  const [form, setForm] = useState({
    source: "support",
    kind: "voc",
    title: "",
    topic: "",
    body: "",
    severity: 3,
    externalUrl: "",
  });

  const { data: signals, isLoading } = useQuery<SignalType[]>({
    queryKey: ["/api/signals", workspaceId],
  });

  const createMutation = useMutation({
    mutationFn: async () => {
      await apiRequest("POST", "/api/signals", {
        workspaceId,
        ...form,
        topic: form.topic || undefined,
        body: form.body || undefined,
        externalUrl: form.externalUrl || undefined,
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/signals", workspaceId] });
      queryClient.invalidateQueries({ queryKey: ["/api/dashboard/stats"] });
      setOpen(false);
      setForm({ source: "support", kind: "voc", title: "", topic: "", body: "", severity: 3, externalUrl: "" });
      toast({ title: "Signal added" });
    },
    onError: (err: any) => {
      toast({ title: "Failed to add signal", description: err.message, variant: "destructive" });
    },
  });

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between gap-4 flex-wrap">
        <p className="text-sm text-muted-foreground">{signals?.length ?? 0} signals collected</p>
        <Dialog open={open} onOpenChange={setOpen}>
          <DialogTrigger asChild>
            <Button size="sm" data-testid="button-add-signal">
              <Plus className="w-4 h-4 mr-1.5" />
              Add Signal
            </Button>
          </DialogTrigger>
          <DialogContent className="max-w-lg">
            <DialogHeader>
              <DialogTitle>Add Signal</DialogTitle>
            </DialogHeader>
            <form
              onSubmit={(e) => {
                e.preventDefault();
                createMutation.mutate();
              }}
              className="space-y-4 mt-2"
            >
              <div className="grid grid-cols-2 gap-3">
                <div className="space-y-2">
                  <Label>Source</Label>
                  <Select value={form.source} onValueChange={(v) => setForm({ ...form, source: v })}>
                    <SelectTrigger data-testid="select-source">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      {Object.entries(SOURCE_LABELS).map(([k, v]) => (
                        <SelectItem key={k} value={k}>{v}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                <div className="space-y-2">
                  <Label>Kind</Label>
                  <Select value={form.kind} onValueChange={(v) => setForm({ ...form, kind: v })}>
                    <SelectTrigger data-testid="select-kind">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      {Object.entries(KIND_LABELS).map(([k, v]) => (
                        <SelectItem key={k} value={k}>{v}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              </div>
              <div className="space-y-2">
                <Label>Title</Label>
                <Input
                  data-testid="input-signal-title"
                  value={form.title}
                  onChange={(e) => setForm({ ...form, title: e.target.value })}
                  placeholder="Brief description of the signal"
                  required
                />
              </div>
              <div className="space-y-2">
                <Label>Topic (optional clustering key)</Label>
                <Input
                  data-testid="input-signal-topic"
                  value={form.topic}
                  onChange={(e) => setForm({ ...form, topic: e.target.value })}
                  placeholder="e.g., onboarding, checkout"
                />
              </div>
              <div className="space-y-2">
                <Label>Details (optional)</Label>
                <Textarea
                  data-testid="input-signal-body"
                  value={form.body}
                  onChange={(e) => setForm({ ...form, body: e.target.value })}
                  placeholder="Full context of the signal"
                  className="resize-none"
                  rows={3}
                />
              </div>
              <div className="grid grid-cols-2 gap-3">
                <div className="space-y-2">
                  <Label>Severity (1-5)</Label>
                  <Select value={String(form.severity)} onValueChange={(v) => setForm({ ...form, severity: Number(v) })}>
                    <SelectTrigger data-testid="select-severity">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      {[1, 2, 3, 4, 5].map((v) => (
                        <SelectItem key={v} value={String(v)}>{v} - {v === 1 ? "Low" : v === 2 ? "Minor" : v === 3 ? "Medium" : v === 4 ? "High" : "Critical"}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                <div className="space-y-2">
                  <Label>URL (optional)</Label>
                  <Input
                    data-testid="input-signal-url"
                    value={form.externalUrl}
                    onChange={(e) => setForm({ ...form, externalUrl: e.target.value })}
                    placeholder="https://..."
                    type="url"
                  />
                </div>
              </div>
              <Button type="submit" className="w-full" disabled={createMutation.isPending} data-testid="button-submit-signal">
                {createMutation.isPending && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
                Add Signal
              </Button>
            </form>
          </DialogContent>
        </Dialog>
      </div>

      <AiAnalyzeWidget />

      {isLoading ? (
        <div className="space-y-3">
          {Array.from({ length: 5 }).map((_, i) => (
            <Card key={i}>
              <CardContent className="p-4">
                <div className="flex items-center gap-3">
                  <Skeleton className="w-8 h-8 rounded-md" />
                  <div className="flex-1 space-y-2">
                    <Skeleton className="h-4 w-48" />
                    <Skeleton className="h-3 w-32" />
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      ) : signals?.length ? (
        <div className="space-y-2">
          {signals.map((s) => (
            <Card key={s.id} data-testid={`card-signal-${s.id}`}>
              <CardContent className="p-4">
                <div className="flex items-start gap-3">
                  <div className="mt-0.5 flex-shrink-0">
                    {s.severity >= 4 ? (
                      <AlertTriangle className="w-4 h-4 text-chart-4" />
                    ) : (
                      <Signal className="w-4 h-4 text-muted-foreground" />
                    )}
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2 flex-wrap">
                      <p className="text-sm font-medium">{s.title}</p>
                      {s.externalUrl && (
                        <a href={s.externalUrl} target="_blank" rel="noopener noreferrer" className="text-muted-foreground">
                          <ExternalLink className="w-3 h-3" />
                        </a>
                      )}
                    </div>
                    {s.body && (
                      <p className="text-xs text-muted-foreground mt-1 line-clamp-2">{s.body}</p>
                    )}
                    <div className="flex items-center gap-3 mt-2 flex-wrap">
                      <Badge variant="secondary" className="text-xs">{SOURCE_LABELS[s.source] || s.source}</Badge>
                      <Badge variant="outline" className="text-xs">{KIND_LABELS[s.kind] || s.kind}</Badge>
                      {(s as any).normTopic ? (
                        <Badge variant="outline" className="text-xs bg-accent/30">
                          {(s as any).normTopic}
                        </Badge>
                      ) : s.topic ? (
                        <span className="text-xs text-muted-foreground">#{s.topic}</span>
                      ) : null}
                      {(s as any).normTags && (s as any).normTags.length > 0 && (
                        <div className="flex items-center gap-1">
                          {((s as any).normTags as string[]).slice(0, 3).map((tag: string) => (
                            <span key={tag} className="text-[10px] text-muted-foreground">#{tag}</span>
                          ))}
                        </div>
                      )}
                      <SeverityDots severity={s.severity} />
                      <span className="text-xs text-muted-foreground ml-auto">{format(new Date(s.createdAt), "MMM d, HH:mm")}</span>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      ) : (
        <Card>
          <CardContent className="p-10 text-center">
            <Signal className="w-8 h-8 text-muted-foreground/40 mx-auto mb-3" />
            <h3 className="font-semibold text-sm mb-1">No signals yet</h3>
            <p className="text-xs text-muted-foreground mb-4">Signals are customer feedback, metrics, and delivery data</p>
            <Button size="sm" onClick={() => setOpen(true)} data-testid="button-add-signal-empty">
              <Plus className="w-4 h-4 mr-1.5" />
              Add First Signal
            </Button>
          </CardContent>
        </Card>
      )}
    </div>
  );
}

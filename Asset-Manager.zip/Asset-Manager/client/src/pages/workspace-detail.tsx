import { useQuery } from "@tanstack/react-query";
import { useRoute, useLocation } from "wouter";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Skeleton } from "@/components/ui/skeleton";
import { Button } from "@/components/ui/button";
import { ArrowLeft } from "lucide-react";
import type { Workspace } from "@shared/schema";
import SignalsTab from "@/components/signals-tab";
import OpportunitiesTab from "@/components/opportunities-tab";
import ConstraintsTab from "@/components/constraints-tab";
import IntegrationsTab from "@/components/integrations-tab";
import InitiativesTab from "@/components/initiatives-tab";

export default function WorkspaceDetail() {
  const [matchSignals, paramsSignals] = useRoute("/workspaces/:id/signals");
  const [matchOpps, paramsOpps] = useRoute("/workspaces/:id/opportunities");
  const [matchConstraints, paramsConstraints] = useRoute("/workspaces/:id/constraints");
  const [matchIntegrations, paramsIntegrations] = useRoute("/workspaces/:id/integrations");
  const [matchInitiatives, paramsInitiatives] = useRoute("/workspaces/:id/initiatives");
  const [, navigate] = useLocation();

  const id = paramsSignals?.id || paramsOpps?.id || paramsConstraints?.id || paramsIntegrations?.id || paramsInitiatives?.id || "";
  const defaultTab = matchOpps ? "opportunities" : matchConstraints ? "constraints" : matchIntegrations ? "integrations" : matchInitiatives ? "initiatives" : "signals";

  const { data: workspace, isLoading } = useQuery<Workspace>({
    queryKey: ["/api/workspaces", id],
    enabled: !!id,
  });

  if (isLoading) {
    return (
      <div className="p-6 max-w-6xl mx-auto space-y-6">
        <Skeleton className="h-8 w-48" />
        <Skeleton className="h-10 w-64" />
        <Skeleton className="h-64 w-full" />
      </div>
    );
  }

  if (!workspace) {
    return (
      <div className="p-6 text-center">
        <p className="text-muted-foreground">Workspace not found</p>
      </div>
    );
  }

  return (
    <div className="p-6 max-w-6xl mx-auto space-y-4">
      <div className="flex items-center gap-3">
        <Button variant="ghost" size="icon" onClick={() => navigate("/workspaces")} data-testid="button-back">
          <ArrowLeft className="w-4 h-4" />
        </Button>
        <div>
          <h1 className="text-xl font-bold tracking-tight" data-testid="text-workspace-name">{workspace.name}</h1>
          {workspace.description && (
            <p className="text-sm text-muted-foreground mt-0.5">{workspace.description}</p>
          )}
        </div>
      </div>

      <Tabs
        defaultValue={defaultTab}
        onValueChange={(v) => navigate(`/workspaces/${id}/${v}`)}
      >
        <TabsList>
          <TabsTrigger value="signals" data-testid="tab-signals">Signals</TabsTrigger>
          <TabsTrigger value="opportunities" data-testid="tab-opportunities">Opportunities</TabsTrigger>
          <TabsTrigger value="constraints" data-testid="tab-constraints">Constraints</TabsTrigger>
          <TabsTrigger value="integrations" data-testid="tab-integrations">Integrations</TabsTrigger>
          <TabsTrigger value="initiatives" data-testid="tab-initiatives">Initiatives</TabsTrigger>
        </TabsList>

        <TabsContent value="signals" className="mt-4">
          <SignalsTab workspaceId={id} />
        </TabsContent>

        <TabsContent value="opportunities" className="mt-4">
          <OpportunitiesTab workspaceId={id} />
        </TabsContent>

        <TabsContent value="constraints" className="mt-4">
          <ConstraintsTab workspaceId={id} />
        </TabsContent>

        <TabsContent value="integrations" className="mt-4">
          <IntegrationsTab workspaceId={id} />
        </TabsContent>

        <TabsContent value="initiatives" className="mt-4">
          <InitiativesTab workspaceId={id} />
        </TabsContent>
      </Tabs>
    </div>
  );
}

import { useQuery, useMutation } from "@tanstack/react-query";
import { useAuth } from "@/lib/auth";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { Check, CreditCard, Zap, Building2, ArrowRight } from "lucide-react";
import { useState } from "react";

const PLAN_FEATURES: Record<string, { features: string[]; highlight?: boolean }> = {
  free: {
    features: [
      "2 workspaces",
      "100 signals",
      "1 integration",
      "10 AI calls/month",
      "Weekly digest",
    ],
  },
  pro: {
    features: [
      "10 workspaces",
      "5,000 signals",
      "5 integrations",
      "500 AI calls/month",
      "Real-time alerts",
      "Pivot mode",
      "AI normalization",
    ],
    highlight: true,
  },
  enterprise: {
    features: [
      "Unlimited workspaces",
      "Unlimited signals",
      "Unlimited integrations",
      "Unlimited AI calls",
      "Priority support",
      "Custom SLAs",
      "Advanced analytics",
    ],
  },
};

export default function BillingPage() {
  const { user } = useAuth();
  const { toast } = useToast();
  const [billingInterval, setBillingInterval] = useState<"month" | "year">("month");

  const { data: planData, isLoading: planLoading } = useQuery<{
    plan: string;
    limits: any;
    usage: any;
  }>({
    queryKey: ["/api/plan"],
  });

  const { data: productsData, isLoading: productsLoading } = useQuery<{
    products: Array<{
      id: string;
      name: string;
      description: string;
      metadata: any;
      prices: Array<{
        id: string;
        unitAmount: number;
        currency: string;
        recurring: any;
      }>;
    }>;
  }>({
    queryKey: ["/api/stripe/products"],
  });

  const checkoutMutation = useMutation({
    mutationFn: async (priceId: string) => {
      const res = await apiRequest("POST", "/api/stripe/checkout", { priceId });
      return await res.json();
    },
    onSuccess: (data) => {
      if (data.url) {
        window.location.href = data.url;
      }
    },
    onError: (err: any) => {
      toast({
        title: "Checkout failed",
        description: err.message || "Could not start checkout",
        variant: "destructive",
      });
    },
  });

  const portalMutation = useMutation({
    mutationFn: async () => {
      const res = await apiRequest("POST", "/api/stripe/portal");
      return await res.json();
    },
    onSuccess: (data) => {
      if (data.url) {
        window.location.href = data.url;
      }
    },
    onError: (err: any) => {
      toast({
        title: "Could not open billing portal",
        description: err.message,
        variant: "destructive",
      });
    },
  });

  const syncMutation = useMutation({
    mutationFn: async () => {
      const res = await apiRequest("POST", "/api/stripe/sync-plan");
      return await res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/plan"] });
      queryClient.invalidateQueries({ queryKey: ["/api/auth/me"] });
      toast({ title: "Plan synced successfully" });
    },
  });

  const currentPlan = planData?.plan || user?.plan || "free";
  const products = productsData?.products || [];

  function getPriceForInterval(product: any) {
    return product.prices?.find((p: any) => {
      const rec = typeof p.recurring === "string" ? JSON.parse(p.recurring) : p.recurring;
      return rec?.interval === billingInterval;
    });
  }

  function formatPrice(amount: number, currency: string) {
    return new Intl.NumberFormat("en-US", {
      style: "currency",
      currency: currency || "usd",
      minimumFractionDigits: 0,
    }).format(amount / 100);
  }

  const isLoading = planLoading || productsLoading;

  if (isLoading) {
    return (
      <div className="p-6 max-w-5xl mx-auto space-y-6">
        <Skeleton className="h-8 w-48" />
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <Skeleton className="h-80" />
          <Skeleton className="h-80" />
          <Skeleton className="h-80" />
        </div>
      </div>
    );
  }

  const params = new URLSearchParams(window.location.search);
  const checkoutSuccess = params.get("success") === "true";
  const checkoutCanceled = params.get("canceled") === "true";

  return (
    <div className="p-6 max-w-5xl mx-auto space-y-6">
      <div>
        <h1 className="text-2xl font-bold" data-testid="text-billing-title">Plans & Billing</h1>
        <p className="text-muted-foreground mt-1">
          Choose the plan that fits your product intelligence needs.
        </p>
      </div>

      {checkoutSuccess && (
        <Card className="border-green-500/30 bg-green-500/5">
          <CardContent className="flex items-center gap-3 pt-6">
            <Check className="w-5 h-5 text-green-500 flex-shrink-0" />
            <div>
              <p className="font-medium">Payment successful</p>
              <p className="text-sm text-muted-foreground">
                Your plan has been upgraded. It may take a moment to reflect.
              </p>
            </div>
            <Button
              variant="outline"
              size="sm"
              className="ml-auto"
              onClick={() => syncMutation.mutate()}
              disabled={syncMutation.isPending}
              data-testid="button-sync-plan"
            >
              Sync Plan
            </Button>
          </CardContent>
        </Card>
      )}

      {checkoutCanceled && (
        <Card className="border-yellow-500/30 bg-yellow-500/5">
          <CardContent className="flex items-center gap-3 pt-6">
            <CreditCard className="w-5 h-5 text-yellow-500 flex-shrink-0" />
            <p className="text-sm text-muted-foreground">Checkout was canceled. No charges were made.</p>
          </CardContent>
        </Card>
      )}

      <Card>
        <CardHeader>
          <div className="flex items-center justify-between gap-2 flex-wrap">
            <div>
              <CardTitle className="text-lg">Current Plan</CardTitle>
              <CardDescription>
                You are on the <span className="font-medium capitalize">{currentPlan}</span> plan.
              </CardDescription>
            </div>
            <div className="flex items-center gap-2">
              <Badge variant={currentPlan === "free" ? "secondary" : "default"} data-testid="badge-current-plan">
                {currentPlan.toUpperCase()}
              </Badge>
              {currentPlan !== "free" && (
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => portalMutation.mutate()}
                  disabled={portalMutation.isPending}
                  data-testid="button-manage-billing"
                >
                  <CreditCard className="w-4 h-4 mr-1.5" />
                  Manage Billing
                </Button>
              )}
            </div>
          </div>
        </CardHeader>
        {planData?.usage && (
          <CardContent>
            <div className="flex items-center gap-4 flex-wrap text-sm text-muted-foreground">
              <span>
                Workspaces: {planData.usage.workspaces} / {planData.limits.workspaces === -1 ? "Unlimited" : planData.limits.workspaces}
              </span>
              <span>
                Signals limit: {planData.limits.signals === -1 ? "Unlimited" : planData.limits.signals.toLocaleString()}
              </span>
              <span>
                Integrations: {planData.limits.integrations === -1 ? "Unlimited" : planData.limits.integrations}
              </span>
            </div>
          </CardContent>
        )}
      </Card>

      <div className="flex items-center justify-center gap-2">
        <Button
          variant={billingInterval === "month" ? "default" : "outline"}
          size="sm"
          onClick={() => setBillingInterval("month")}
          data-testid="button-monthly"
        >
          Monthly
        </Button>
        <Button
          variant={billingInterval === "year" ? "default" : "outline"}
          size="sm"
          onClick={() => setBillingInterval("year")}
          data-testid="button-yearly"
        >
          Yearly
          <Badge variant="secondary" className="ml-1.5 no-default-hover-elevate no-default-active-elevate">Save 20%</Badge>
        </Button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <Card data-testid="card-plan-free">
          <CardHeader>
            <CardTitle className="text-lg">Free</CardTitle>
            <CardDescription>Get started with basic features</CardDescription>
            <div className="pt-2">
              <span className="text-3xl font-bold">$0</span>
              <span className="text-muted-foreground text-sm">/month</span>
            </div>
          </CardHeader>
          <CardContent className="space-y-3">
            <ul className="space-y-2">
              {PLAN_FEATURES.free.features.map((f) => (
                <li key={f} className="flex items-start gap-2 text-sm">
                  <Check className="w-4 h-4 text-muted-foreground flex-shrink-0 mt-0.5" />
                  <span>{f}</span>
                </li>
              ))}
            </ul>
            {currentPlan === "free" && (
              <Button variant="outline" className="w-full" disabled data-testid="button-current-free">
                Current Plan
              </Button>
            )}
          </CardContent>
        </Card>

        {products.map((product) => {
          const meta = typeof product.metadata === "string" ? JSON.parse(product.metadata) : product.metadata;
          const planKey = meta?.plan || "pro";
          const price = getPriceForInterval(product);
          const features = PLAN_FEATURES[planKey] || PLAN_FEATURES.pro;
          const isCurrentPlan = currentPlan === planKey;
          const isPro = planKey === "pro";

          return (
            <Card
              key={product.id}
              className={features.highlight ? "border-primary/40" : ""}
              data-testid={`card-plan-${planKey}`}
            >
              <CardHeader>
                <div className="flex items-center gap-2">
                  <CardTitle className="text-lg">{product.name?.replace("PivotLab ", "")}</CardTitle>
                  {features.highlight && (
                    <Badge variant="default" className="no-default-hover-elevate no-default-active-elevate">Popular</Badge>
                  )}
                </div>
                <CardDescription>{product.description}</CardDescription>
                <div className="pt-2">
                  {price ? (
                    <>
                      <span className="text-3xl font-bold">
                        {formatPrice(price.unitAmount, price.currency)}
                      </span>
                      <span className="text-muted-foreground text-sm">/{billingInterval === "month" ? "mo" : "yr"}</span>
                    </>
                  ) : (
                    <span className="text-muted-foreground text-sm">Contact us</span>
                  )}
                </div>
              </CardHeader>
              <CardContent className="space-y-3">
                <ul className="space-y-2">
                  {features.features.map((f) => (
                    <li key={f} className="flex items-start gap-2 text-sm">
                      <Check className="w-4 h-4 text-primary flex-shrink-0 mt-0.5" />
                      <span>{f}</span>
                    </li>
                  ))}
                </ul>
                {isCurrentPlan ? (
                  <Button variant="outline" className="w-full" disabled data-testid={`button-current-${planKey}`}>
                    Current Plan
                  </Button>
                ) : (
                  <Button
                    className="w-full"
                    variant={features.highlight ? "default" : "outline"}
                    disabled={!price || checkoutMutation.isPending}
                    onClick={() => price && checkoutMutation.mutate(price.id)}
                    data-testid={`button-upgrade-${planKey}`}
                  >
                    {isPro ? <Zap className="w-4 h-4 mr-1.5" /> : <Building2 className="w-4 h-4 mr-1.5" />}
                    Upgrade
                    <ArrowRight className="w-4 h-4 ml-1.5" />
                  </Button>
                )}
              </CardContent>
            </Card>
          );
        })}

        {products.length === 0 && (
          <>
            <Card data-testid="card-plan-pro">
              <CardHeader>
                <CardTitle className="text-lg">Pro</CardTitle>
                <CardDescription>For growing teams</CardDescription>
                <div className="pt-2">
                  <span className="text-3xl font-bold">$49</span>
                  <span className="text-muted-foreground text-sm">/mo</span>
                </div>
              </CardHeader>
              <CardContent>
                <ul className="space-y-2">
                  {PLAN_FEATURES.pro.features.map((f) => (
                    <li key={f} className="flex items-start gap-2 text-sm">
                      <Check className="w-4 h-4 text-primary flex-shrink-0 mt-0.5" />
                      <span>{f}</span>
                    </li>
                  ))}
                </ul>
                <p className="text-xs text-muted-foreground mt-3">Products syncing...</p>
              </CardContent>
            </Card>
            <Card data-testid="card-plan-enterprise">
              <CardHeader>
                <CardTitle className="text-lg">Enterprise</CardTitle>
                <CardDescription>For large organizations</CardDescription>
                <div className="pt-2">
                  <span className="text-3xl font-bold">$199</span>
                  <span className="text-muted-foreground text-sm">/mo</span>
                </div>
              </CardHeader>
              <CardContent>
                <ul className="space-y-2">
                  {PLAN_FEATURES.enterprise.features.map((f) => (
                    <li key={f} className="flex items-start gap-2 text-sm">
                      <Check className="w-4 h-4 text-primary flex-shrink-0 mt-0.5" />
                      <span>{f}</span>
                    </li>
                  ))}
                </ul>
                <p className="text-xs text-muted-foreground mt-3">Products syncing...</p>
              </CardContent>
            </Card>
          </>
        )}
      </div>
    </div>
  );
}

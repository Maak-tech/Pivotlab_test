import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { queryClient, apiRequest } from "@/lib/queryClient";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Skeleton } from "@/components/ui/skeleton";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { useToast } from "@/hooks/use-toast";
import { Plus, FolderOpen, ArrowRight, Calendar, Loader2 } from "lucide-react";
import { useLocation } from "wouter";
import type { Workspace } from "@shared/schema";
import { format } from "date-fns";

export default function WorkspacesPage() {
  const [, navigate] = useLocation();
  const { toast } = useToast();
  const [open, setOpen] = useState(false);
  const [name, setName] = useState("");
  const [description, setDescription] = useState("");

  const { data: workspaces, isLoading } = useQuery<Workspace[]>({
    queryKey: ["/api/workspaces"],
  });

  const createMutation = useMutation({
    mutationFn: async () => {
      await apiRequest("POST", "/api/workspaces", { name, description: description || undefined });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/workspaces"] });
      setOpen(false);
      setName("");
      setDescription("");
      toast({ title: "Workspace created" });
    },
    onError: (err: any) => {
      toast({ title: "Failed to create workspace", description: err.message, variant: "destructive" });
    },
  });

  return (
    <div className="p-6 max-w-5xl mx-auto space-y-6">
      <div className="flex items-center justify-between gap-4 flex-wrap">
        <div>
          <h1 className="text-2xl font-bold tracking-tight" data-testid="text-workspaces-title">Workspaces</h1>
          <p className="text-muted-foreground text-sm mt-1">Organize your product areas</p>
        </div>
        <Dialog open={open} onOpenChange={setOpen}>
          <DialogTrigger asChild>
            <Button data-testid="button-create-workspace">
              <Plus className="w-4 h-4 mr-1.5" />
              New Workspace
            </Button>
          </DialogTrigger>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>Create Workspace</DialogTitle>
            </DialogHeader>
            <form
              onSubmit={(e) => {
                e.preventDefault();
                createMutation.mutate();
              }}
              className="space-y-4 mt-2"
            >
              <div className="space-y-2">
                <Label>Name</Label>
                <Input
                  data-testid="input-workspace-name"
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  placeholder="e.g., Mobile App, API Platform"
                  required
                />
              </div>
              <div className="space-y-2">
                <Label>Description (optional)</Label>
                <Textarea
                  data-testid="input-workspace-description"
                  value={description}
                  onChange={(e) => setDescription(e.target.value)}
                  placeholder="What product area does this cover?"
                  className="resize-none"
                />
              </div>
              <Button type="submit" className="w-full" disabled={createMutation.isPending} data-testid="button-submit-workspace">
                {createMutation.isPending && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
                Create Workspace
              </Button>
            </form>
          </DialogContent>
        </Dialog>
      </div>

      {isLoading ? (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {Array.from({ length: 3 }).map((_, i) => (
            <Card key={i}>
              <CardContent className="p-5 space-y-3">
                <Skeleton className="h-5 w-32" />
                <Skeleton className="h-4 w-48" />
                <Skeleton className="h-3 w-24" />
              </CardContent>
            </Card>
          ))}
        </div>
      ) : workspaces?.length ? (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {workspaces.map((ws) => (
            <Card
              key={ws.id}
              className="hover-elevate cursor-pointer group"
              onClick={() => navigate(`/workspaces/${ws.id}/signals`)}
              data-testid={`card-workspace-${ws.id}`}
            >
              <CardContent className="p-5">
                <div className="flex items-start justify-between gap-2">
                  <div className="w-9 h-9 rounded-md bg-accent flex items-center justify-center flex-shrink-0">
                    <FolderOpen className="w-4 h-4 text-accent-foreground" />
                  </div>
                  <ArrowRight className="w-4 h-4 text-muted-foreground opacity-0 group-hover:opacity-100 transition-opacity mt-2.5" />
                </div>
                <h3 className="font-semibold mt-3 text-sm">{ws.name}</h3>
                {ws.description && (
                  <p className="text-xs text-muted-foreground mt-1 line-clamp-2">{ws.description}</p>
                )}
                <div className="flex items-center gap-1 mt-3 text-xs text-muted-foreground">
                  <Calendar className="w-3 h-3" />
                  <span>{format(new Date(ws.createdAt), "MMM d, yyyy")}</span>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      ) : (
        <Card>
          <CardContent className="p-12 text-center">
            <FolderOpen className="w-10 h-10 text-muted-foreground/40 mx-auto mb-4" />
            <h3 className="font-semibold mb-1">No workspaces yet</h3>
            <p className="text-sm text-muted-foreground mb-4">Create your first workspace to start collecting signals</p>
            <Button onClick={() => setOpen(true)} data-testid="button-create-workspace-empty">
              <Plus className="w-4 h-4 mr-1.5" />
              Create Workspace
            </Button>
          </CardContent>
        </Card>
      )}
    </div>
  );
}

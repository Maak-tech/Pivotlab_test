import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import { Progress } from "@/components/ui/progress";
import { Textarea } from "@/components/ui/textarea";
import { useToast } from "@/hooks/use-toast";
import { BarChart3, TrendingUp, Signal, Lightbulb, ArrowRight, Target, AlertTriangle, Sparkles, Loader2, Brain, Wand2 } from "lucide-react";
import { useLocation } from "wouter";
import { apiRequest } from "@/lib/queryClient";
import type { Workspace, Opportunity, Signal as SignalType } from "@shared/schema";

function StatCard({ title, value, subtitle, icon: Icon, trend }: {
  title: string;
  value: string | number;
  subtitle?: string;
  icon: any;
  trend?: string;
}) {
  return (
    <Card>
      <CardContent className="p-5">
        <div className="flex items-start justify-between gap-2">
          <div className="space-y-1">
            <p className="text-sm text-muted-foreground">{title}</p>
            <p className="text-2xl font-bold tracking-tight">{value}</p>
            {subtitle && <p className="text-xs text-muted-foreground">{subtitle}</p>}
          </div>
          <div className="w-9 h-9 rounded-md bg-accent flex items-center justify-center flex-shrink-0">
            <Icon className="w-4 h-4 text-accent-foreground" />
          </div>
        </div>
        {trend && (
          <div className="mt-3 flex items-center gap-1">
            <TrendingUp className="w-3 h-3 text-chart-2" />
            <span className="text-xs text-chart-2 font-medium">{trend}</span>
          </div>
        )}
      </CardContent>
    </Card>
  );
}

function StatusBadge({ status }: { status: string }) {
  const variants: Record<string, string> = {
    open: "bg-chart-1/10 text-chart-1 dark:bg-chart-1/20",
    planned: "bg-chart-3/10 text-chart-3 dark:bg-chart-3/20",
    shipped: "bg-chart-2/10 text-chart-2 dark:bg-chart-2/20",
    rejected: "bg-destructive/10 text-destructive dark:bg-destructive/20",
  };
  return (
    <Badge variant="outline" className={`${variants[status] || ""} border-0 text-xs capitalize`}>
      {status}
    </Badge>
  );
}

function AiThemeAnalyzer() {
  const [text, setText] = useState("");
  const [result, setResult] = useState<any>(null);
  const { toast } = useToast();

  const mutation = useMutation({
    mutationFn: async () => {
      const res = await apiRequest("POST", "/api/ai/theme", { text });
      const data = await res.json().catch(() => null);
      if (!data) throw new Error("Invalid response from AI");
      return data;
    },
    onSuccess: (data) => {
      setResult(data);
    },
    onError: (err: any) => {
      toast({ title: "AI analysis failed", description: err.message, variant: "destructive" });
    },
  });

  return (
    <Card data-testid="card-ai-theme-analyzer">
      <CardHeader className="pb-3">
        <CardTitle className="text-base font-semibold flex items-center gap-2">
          <Sparkles className="w-4 h-4" />
          AI Theme Analyzer
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-3">
        <p className="text-xs text-muted-foreground">
          Paste any customer feedback, review, or support ticket and AI will extract the theme, sentiment, urgency, and KPI hints.
        </p>
        <Textarea
          data-testid="input-ai-theme-text"
          placeholder="e.g., Users are complaining that the checkout flow takes too long and they abandon their cart..."
          value={text}
          onChange={(e) => setText(e.target.value)}
          rows={3}
          className="resize-none text-sm"
        />
        <Button
          size="sm"
          onClick={() => mutation.mutate()}
          disabled={mutation.isPending || text.length < 10}
          data-testid="button-ai-analyze"
        >
          {mutation.isPending ? (
            <Loader2 className="w-4 h-4 mr-1.5 animate-spin" />
          ) : (
            <Wand2 className="w-4 h-4 mr-1.5" />
          )}
          {mutation.isPending ? "Analyzing..." : "Analyze with AI"}
        </Button>

        {result && (
          <div className="border rounded-md p-3 space-y-2 bg-muted/30" data-testid="ai-theme-result">
            <div className="flex items-center gap-2 flex-wrap">
              <Badge variant="secondary">{result.topic || "Unknown"}</Badge>
              {result.sentiment && (
                <Badge variant="outline" className="text-xs">{result.sentiment}</Badge>
              )}
              {result.urgency && (
                <Badge
                  variant="outline"
                  className={`text-xs border-0 ${
                    result.urgency === "high" ? "bg-destructive/10 text-destructive" :
                    result.urgency === "medium" ? "bg-chart-1/10 text-chart-1" :
                    "bg-muted text-muted-foreground"
                  }`}
                >
                  {result.urgency} urgency
                </Badge>
              )}
            </div>
            {result.subtopics?.length > 0 && (
              <div className="flex items-center gap-1 flex-wrap">
                <span className="text-xs text-muted-foreground">Subtopics:</span>
                {result.subtopics.map((s: string) => (
                  <Badge key={s} variant="outline" className="text-[10px]">{s}</Badge>
                ))}
              </div>
            )}
            {result.userPain && (
              <p className="text-xs text-muted-foreground">
                <span className="font-medium text-foreground">User Pain:</span> {result.userPain}
              </p>
            )}
            {result.kpiHints?.length > 0 && (
              <div className="flex items-center gap-1 flex-wrap">
                <span className="text-xs text-muted-foreground">KPI Hints:</span>
                {result.kpiHints.map((k: string) => (
                  <span key={k} className="text-xs text-foreground font-medium">{k}</span>
                ))}
              </div>
            )}
          </div>
        )}

        {mutation.isError && (
          <p className="text-xs text-destructive" data-testid="text-ai-error">
            AI analysis requires an OpenAI API key to be configured. Contact your admin.
          </p>
        )}
      </CardContent>
    </Card>
  );
}

function AiInsightsPanel({ workspaces }: { workspaces?: Workspace[] }) {
  const [, navigate] = useLocation();
  const hasWorkspace = workspaces && workspaces.length > 0;

  return (
    <Card data-testid="card-ai-insights">
      <CardHeader className="pb-3">
        <CardTitle className="text-base font-semibold flex items-center gap-2">
          <Brain className="w-4 h-4" />
          AI-Powered Features
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-3">
        {!hasWorkspace && (
          <p className="text-xs text-muted-foreground p-2 bg-muted/50 rounded-md">
            Create a workspace first to use AI features on your data.
          </p>
        )}
        <div className="space-y-2">
          <div
            className={`flex items-start gap-3 p-3 rounded-md border ${hasWorkspace ? "hover-elevate cursor-pointer" : "opacity-60"}`}
            onClick={() => hasWorkspace && navigate(`/workspaces/${workspaces[0].id}/opportunities`)}
            data-testid="link-ai-explain"
          >
            <Sparkles className="w-4 h-4 text-chart-3 mt-0.5 flex-shrink-0" />
            <div>
              <p className="text-sm font-medium">AI Opportunity Explanations</p>
              <p className="text-xs text-muted-foreground mt-0.5">Get AI-generated deep analysis of any opportunity with evidence synthesis</p>
            </div>
          </div>
          <div
            className={`flex items-start gap-3 p-3 rounded-md border ${hasWorkspace ? "hover-elevate cursor-pointer" : "opacity-60"}`}
            onClick={() => hasWorkspace && navigate(`/workspaces/${workspaces[0].id}/opportunities`)}
            data-testid="link-ai-roadmap"
          >
            <Wand2 className="w-4 h-4 text-chart-1 mt-0.5 flex-shrink-0" />
            <div>
              <p className="text-sm font-medium">AI Roadmap Generator</p>
              <p className="text-xs text-muted-foreground mt-0.5">AI prioritizes and sequences your top opportunities into an actionable roadmap</p>
            </div>
          </div>
          <div
            className={`flex items-start gap-3 p-3 rounded-md border ${hasWorkspace ? "hover-elevate cursor-pointer" : "opacity-60"}`}
            onClick={() => hasWorkspace && navigate(`/workspaces/${workspaces[0].id}/signals`)}
            data-testid="link-ai-themes"
          >
            <Brain className="w-4 h-4 text-chart-2 mt-0.5 flex-shrink-0" />
            <div>
              <p className="text-sm font-medium">Auto Theme Extraction</p>
              <p className="text-xs text-muted-foreground mt-0.5">Signals are automatically tagged with AI-extracted topics, sentiment, and urgency</p>
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}

export default function Dashboard() {
  const [, navigate] = useLocation();

  const { data: workspaces, isLoading: wsLoading } = useQuery<Workspace[]>({
    queryKey: ["/api/workspaces"],
  });

  const { data: stats, isLoading: statsLoading } = useQuery<{
    totalSignals: number;
    totalOpportunities: number;
    avgScore: number;
    topOpportunities: (Opportunity & { evidenceCount: number })[];
    recentSignals: SignalType[];
    statusBreakdown: Record<string, number>;
  }>({
    queryKey: ["/api/dashboard/stats"],
  });

  const isLoading = wsLoading || statsLoading;

  return (
    <div className="p-6 max-w-7xl mx-auto space-y-6">
      <div>
        <h1 className="text-2xl font-bold tracking-tight" data-testid="text-dashboard-title">Dashboard</h1>
        <p className="text-muted-foreground text-sm mt-1">Overview of your product opportunities</p>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {isLoading ? (
          Array.from({ length: 4 }).map((_, i) => (
            <Card key={i}>
              <CardContent className="p-5 space-y-3">
                <Skeleton className="h-4 w-24" />
                <Skeleton className="h-8 w-16" />
                <Skeleton className="h-3 w-32" />
              </CardContent>
            </Card>
          ))
        ) : (
          <>
            <StatCard
              title="Workspaces"
              value={workspaces?.length ?? 0}
              subtitle="Active product areas"
              icon={Target}
            />
            <StatCard
              title="Total Signals"
              value={stats?.totalSignals ?? 0}
              subtitle="Across all workspaces"
              icon={Signal}
            />
            <StatCard
              title="Opportunities"
              value={stats?.totalOpportunities ?? 0}
              subtitle="Identified patterns"
              icon={Lightbulb}
            />
            <StatCard
              title="Avg Score"
              value={stats?.avgScore?.toFixed(1) ?? "0.0"}
              subtitle="Opportunity impact"
              icon={BarChart3}
            />
          </>
        )}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2 space-y-4">
          <Card>
            <CardHeader className="flex flex-row items-center justify-between gap-2 pb-3">
              <CardTitle className="text-base font-semibold">Top Opportunities</CardTitle>
              <Button
                variant="ghost"
                size="sm"
                onClick={() => workspaces?.[0] && navigate(`/workspaces/${workspaces[0].id}/opportunities`)}
                data-testid="button-view-all-opportunities"
              >
                View All <ArrowRight className="ml-1 w-3 h-3" />
              </Button>
            </CardHeader>
            <CardContent className="p-0">
              {isLoading ? (
                <div className="p-5 space-y-4">
                  {Array.from({ length: 3 }).map((_, i) => (
                    <div key={i} className="flex items-center gap-3">
                      <Skeleton className="w-10 h-10 rounded-md" />
                      <div className="flex-1 space-y-2">
                        <Skeleton className="h-4 w-48" />
                        <Skeleton className="h-3 w-32" />
                      </div>
                    </div>
                  ))}
                </div>
              ) : stats?.topOpportunities?.length ? (
                <div className="divide-y divide-border">
                  {stats.topOpportunities.map((opp) => (
                    <div
                      key={opp.id}
                      className="flex items-center gap-4 p-4 hover-elevate cursor-pointer"
                      onClick={() => navigate(`/workspaces/${opp.workspaceId}/opportunities`)}
                      data-testid={`card-opportunity-${opp.id}`}
                    >
                      <div className="w-10 h-10 rounded-md bg-accent flex items-center justify-center flex-shrink-0">
                        <span className="text-sm font-bold text-accent-foreground">{opp.score.toFixed(0)}</span>
                      </div>
                      <div className="flex-1 min-w-0">
                        <p className="text-sm font-medium truncate">{opp.title}</p>
                        <p className="text-xs text-muted-foreground truncate mt-0.5">{opp.problemStatement}</p>
                      </div>
                      <div className="flex items-center gap-2 flex-shrink-0">
                        <StatusBadge status={opp.status} />
                        <span className="text-xs text-muted-foreground">{Math.round(opp.confidence * 100)}%</span>
                      </div>
                    </div>
                  ))}
                </div>
              ) : (
                <div className="p-8 text-center">
                  <Lightbulb className="w-8 h-8 text-muted-foreground/40 mx-auto mb-3" />
                  <p className="text-sm text-muted-foreground">No opportunities yet</p>
                  <p className="text-xs text-muted-foreground mt-1">Add signals to generate opportunities</p>
                </div>
              )}
            </CardContent>
          </Card>

          <AiThemeAnalyzer />
        </div>

        <div className="space-y-4">
          <AiInsightsPanel workspaces={workspaces} />

          <Card>
            <CardHeader className="pb-3">
              <CardTitle className="text-base font-semibold">Status Breakdown</CardTitle>
            </CardHeader>
            <CardContent>
              {isLoading ? (
                <div className="space-y-3">
                  {Array.from({ length: 4 }).map((_, i) => (
                    <Skeleton key={i} className="h-6 w-full" />
                  ))}
                </div>
              ) : (
                <div className="space-y-3">
                  {["open", "planned", "shipped", "rejected"].map((status) => {
                    const count = stats?.statusBreakdown?.[status] ?? 0;
                    const total = stats?.totalOpportunities || 1;
                    const pct = Math.round((count / total) * 100);
                    return (
                      <div key={status} className="space-y-1">
                        <div className="flex items-center justify-between">
                          <span className="text-xs capitalize text-muted-foreground">{status}</span>
                          <span className="text-xs font-medium">{count}</span>
                        </div>
                        <Progress value={pct} className="h-1.5" />
                      </div>
                    );
                  })}
                </div>
              )}
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="pb-3">
              <CardTitle className="text-base font-semibold">Recent Signals</CardTitle>
            </CardHeader>
            <CardContent>
              {isLoading ? (
                <div className="space-y-3">
                  {Array.from({ length: 3 }).map((_, i) => (
                    <Skeleton key={i} className="h-10 w-full" />
                  ))}
                </div>
              ) : stats?.recentSignals?.length ? (
                <div className="space-y-3">
                  {stats.recentSignals.slice(0, 5).map((s) => (
                    <div key={s.id} className="flex items-start gap-2.5">
                      <div className="mt-0.5">
                        {s.severity >= 4 ? (
                          <AlertTriangle className="w-3.5 h-3.5 text-chart-4" />
                        ) : (
                          <Signal className="w-3.5 h-3.5 text-muted-foreground" />
                        )}
                      </div>
                      <div className="min-w-0">
                        <p className="text-xs font-medium truncate">{s.title}</p>
                        <p className="text-xs text-muted-foreground capitalize">{s.source} / {s.kind}</p>
                      </div>
                    </div>
                  ))}
                </div>
              ) : (
                <p className="text-xs text-muted-foreground text-center py-4">No signals yet</p>
              )}
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}

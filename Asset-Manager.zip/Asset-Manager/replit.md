# PivotLab - Product Intelligence Platform

## Overview
PivotLab is a product management tool that transforms customer signals into prioritized product opportunities. It aggregates feedback from reviews, support tickets, analytics, and more into a scored opportunity backlog aligned with business constraints.

## Architecture
- **Frontend**: React + Vite + TanStack Query + Wouter + shadcn/ui + Tailwind CSS
- **Backend**: Express.js with session-based authentication
- **Database**: PostgreSQL with Drizzle ORM + Stripe schema (via stripe-replit-sync)
- **Auth**: Custom session-based auth (username/password with scrypt hashing)
- **Billing**: Stripe (via Replit connector) with checkout sessions, customer portal, webhook sync

## Project Structure
```
client/src/
  App.tsx              - Main app with auth routing and sidebar layout
  lib/auth.tsx         - Auth context/provider with login/register/logout
  lib/theme.tsx        - Dark/light theme provider
  lib/queryClient.ts   - TanStack Query client setup
  pages/
    auth-page.tsx      - Login/Register page
    dashboard.tsx      - Overview with stats and top opportunities
    workspaces.tsx     - Workspace listing and creation
    workspace-detail.tsx - Workspace with tabs (signals/opportunities/constraints/integrations)
  components/
    app-sidebar.tsx    - Sidebar navigation
    theme-toggle.tsx   - Dark/light mode toggle
    signals-tab.tsx    - Signal listing and creation
    opportunities-tab.tsx - Opportunity listing with evidence
    constraints-tab.tsx - Business constraints form
    integrations-tab.tsx - Jira + VoC import UI
    initiatives-tab.tsx - Pivot Mode: initiatives, topics, trends, pivot recs

server/
  index.ts             - Express server entry
  routes.ts            - All API routes with auth middleware
  storage.ts           - Database storage layer (IStorage interface)
  db.ts                - Drizzle DB connection
  recompute.ts         - Opportunity scoring engine
  seed.ts              - Demo data seeder
  scheduler.ts         - Daily cron: Jira sync + pivot analysis + outcome checks + AI queue
  pivot-analysis.ts    - Trend computation + pivot recommendation engine
  slack.ts             - Slack webhook posting, weekly digest builder, pivot alerts
  outcome-checker.ts   - Post-ship outcome evaluation (VoC/Jira metrics + Slack notification)
  integrations/
    jira.ts            - Jira sync + createJiraIssue + getJiraDeliveryMetrics
  ai/
    client.ts          - OpenAI client init
    theme.ts           - AI theme extraction (structured output)
    explainOpportunity.ts - Streaming opportunity explanation
    roadmap.ts         - AI roadmap generation
    schemas.ts         - Zod schemas for AI outputs
    hash.ts            - SHA256 hashing for cache keys
    normalizeSignal.ts - Per-signal AI normalization with cache
    enqueue.ts         - Enqueue signal normalization jobs
    worker.ts          - AI job queue runner with rate limiting
  jobs/
    dailySync.ts       - Standalone daily sync for Scheduled Deployments
    weeklyDigest.ts    - Standalone weekly digest for Scheduled Deployments
    aiNormalize.ts     - Standalone AI queue runner for Scheduled Deployments

shared/
  schema.ts            - Drizzle schemas for all models
```

## Data Models
- **Users**: Auth with username/password
- **Organizations**: Top-level entity, auto-created on registration
- **Workspaces**: Product areas within an org
- **Constraints**: KPI, budget, deadline per workspace (influences scoring)
- **Signals**: Customer feedback, metrics, delivery data (source + kind + severity + externalId for dedup)
- **Opportunities**: Auto-generated from signal clustering, scored by volume + severity + KPI match
- **Evidence**: Snippets from signals linked to opportunities
- **JiraIntegrations**: Per-workspace Jira connection config (baseUrl, email, apiToken, jql, enabled, lastSyncedAt)
- **Initiatives**: Product initiatives with goalKpi, targetValue, killCriteria (jsonb), status (active/pivoted/stopped/shipped), shippedAt, jiraIssueKey/jiraIssueUrl, opportunityId/recommendationId links
- **InitiativeTopics**: Links topics to initiatives for trend tracking
- **PivotRecommendations**: Auto-generated pivot suggestions (type: persevere/cut_scope/solution_pivot/segment_pivot/stop)
- **DecisionRecords**: PM accept/reject decisions with reason, expectedKpiImpact, owner, dueDate for auditability
- **OutcomeChecks**: Scheduled 7d/14d post-ship checks with resultData (jsonb), resultSummary, verdict, slackNotified
- **ZendeskIntegrations**: Per-workspace Zendesk connection config (baseUrl, email, apiToken, startTime for cursor-based incremental export, cursor, enabled, lastSyncedAt)
- **SlackIntegrations**: Per-workspace Slack webhook config (webhookUrl, channelName, enabled) for weekly digests and pivot alerts
- **Ga4Integrations**: Per-workspace GA4 connection config (propertyId, keyEvents jsonb, enabled, lastSyncedAt)
- **AiNormalizationCache**: SHA256-keyed cache for AI theme extraction results (cacheKey unique, result jsonb)
- **AiJobs**: Queue table for async AI processing (type, uniqueKey, payload jsonb, status pending/running/done/failed, attempts, rate-limited)

## API Routes
- `POST /api/auth/register` - Create account
- `POST /api/auth/login` - Login
- `POST /api/auth/logout` - Logout
- `GET /api/auth/me` - Current user
- `GET /api/workspaces` - List workspaces for current user
- `GET /api/workspaces/:id` - Get workspace
- `POST /api/workspaces` - Create workspace
- `GET /api/workspaces/:id/constraints` - Get constraints
- `PUT /api/workspaces/:id/constraints` - Set constraints
- `GET /api/signals/:workspaceId` - List signals
- `POST /api/signals` - Create signal
- `GET /api/opportunities/:workspaceId` - List opportunities with evidence
- `POST /api/opportunities/recompute?workspaceId=X` - Recompute scores
- `PATCH /api/opportunities/:id` - Update status
- `GET /api/dashboard/stats` - Dashboard statistics
- `POST /api/integrations/jira/connect` - Connect Jira to workspace
- `POST /api/integrations/jira/sync` - Sync Jira issues as signals
- `GET /api/integrations/jira/status?workspaceId=X` - Jira integration status
- `POST /api/integrations/voc/import` - Import VoC reviews as signals
- `GET /api/initiatives/:workspaceId` - List initiatives for workspace
- `POST /api/initiatives` - Create initiative with topics and kill criteria
- `PATCH /api/initiatives/:id/status` - Update initiative status
- `POST /api/initiatives/:id/topics` - Add topic to initiative
- `DELETE /api/initiatives/topics/:topicId` - Remove topic
- `GET /api/initiatives/:id/trends` - Get signal trends for initiative
- `POST /api/integrations/zendesk/connect` - Connect Zendesk to workspace
- `POST /api/integrations/zendesk/sync` - Sync Zendesk tickets as signals (cursor-based incremental)
- `GET /api/integrations/zendesk/status?workspaceId=X` - Zendesk integration status
- `POST /api/integrations/slack/connect` - Connect Slack webhook to workspace
- `POST /api/integrations/slack/test` - Send test message to Slack
- `POST /api/integrations/slack/preview-digest` - Preview weekly digest text
- `POST /api/integrations/slack/send-digest` - Send weekly digest to Slack now
- `GET /api/integrations/slack/status?workspaceId=X` - Slack integration status
- `POST /api/integrations/slack/disconnect` - Disable Slack integration
- `POST /api/integrations/ga4/connect` - Connect GA4 to workspace
- `POST /api/integrations/ga4/sync` - Sync GA4 analytics as signals
- `GET /api/integrations/ga4/status?workspaceId=X` - GA4 integration status
- `POST /api/action/turn-into-work` - Create initiative from opportunity/recommendation with optional Jira issue
- `POST /api/action/ship` - Mark initiative shipped + schedule outcome checks
- `POST /api/decisions` - Create decision record (accept/reject with reason, KPI impact, owner, due date)
- `GET /api/decisions/:workspaceId` - List decision records for workspace
- `GET /api/outcome-checks/:initiativeId` - Get outcome checks for initiative
- `POST /api/ai/theme` - AI theme extraction from text (structured output: topic, subtopics, sentiment, userPain, kpiHints, urgency)
- `GET /api/ai/opportunities/:id/explain` - Streaming AI explanation of an opportunity (text/plain chunked)
- `POST /api/ai/roadmap` - AI-generated prioritized roadmap from workspace opportunities
- `POST /api/opportunities/:id/accept` - Accept opportunity (creates Jira issue + decision record)
- `GET /api/plan` - Current user plan limits and usage
- `POST /api/alert-rules` - Create alert rule
- `GET /api/alert-rules/:workspaceId` - List alert rules
- `PUT /api/alert-rules/:id` - Update alert rule
- `DELETE /api/alert-rules/:id` - Delete alert rule
- `POST /admin/ai/run` - Manually run AI normalization queue
- `GET /admin/ai/stats` - AI queue health metrics
- `GET /api/stripe/publishable-key` - Stripe publishable key for frontend
- `GET /api/stripe/products` - List Stripe products with prices
- `POST /api/stripe/checkout` - Create Stripe checkout session
- `POST /api/stripe/portal` - Create Stripe customer portal session
- `GET /api/stripe/subscription` - Get current user subscription
- `POST /api/stripe/sync-plan` - Sync user plan from Stripe subscription

## Seed Data
Demo account: username `demo`, password `demo123`. Pre-loaded with 3 workspaces (Mobile App, API Platform, Web Dashboard), 18 signals, and auto-computed opportunities.

## Recent Changes
- 2026-02-17: Stripe billing integration - checkout sessions, customer portal, plan sync, webhook handling, Pro ($49/mo) and Enterprise ($199/mo) products, billing page UI
- 2026-02-17: RBAC + plan gating - role (admin/viewer) and plan (free/pro/enterprise) on users, plan limits for workspaces/signals/integrations/aiCalls, GET /api/plan endpoint
- 2026-02-17: GA4 segments - deviceCategory/country/channel grouping with WoW comparison, segment-level drop signals
- 2026-02-17: Outcome tracking v2 - GA4 KPI movement checks, improved Slack verdicts ([WIN]/[MISS]/[WATCH]), multi-signal verdict aggregation
- 2026-02-17: Opportunity accept flow - POST /opportunities/:id/accept with Jira issue creation, decision record, jiraIssueKey/Url storage
- 2026-02-17: Smart alerts - alertRules/alertLogs schema, condition-based evaluator (score_above, trend_rising, ga4_drop_and_voc_rising, multi_source), topic wildcards, Slack channel routing, 24h cooldown, daily scheduler integration
- 2026-02-17: Admin AI controls - POST /admin/ai/run, GET /admin/ai/stats with health metrics
- 2026-02-17: Enhanced clustering - normTopic-based grouping, 7d trend scoring (rising/falling/stable/new), sourceBreakdown/trendPercent/signalCount on opportunities
- 2026-02-17: AI topic normalization - SHA256-cached AI theme extraction on signal ingestion (Jira/Zendesk/VoC), rate-limited job queue, normTopic/normTags on signals, recompute clusters on normTopic, scheduled AI queue processing
- 2026-02-17: Action Loop - "Turn into work" button on opportunities/recs creates initiatives with optional Jira issue, Ship button with outcome checks (7d/14d), decision records for auditability
- 2026-02-17: GA4 integration (connect, sync via Data API runReport, WoW comparison signals, UI in Integrations tab, daily sync)
- 2026-02-17: Slack integration (webhook connect, test, weekly digest builder, real-time pivot alerts, UI in Integrations tab)
- 2026-02-17: Standalone weekly digest job (server/jobs/weeklyDigest.ts) for Replit Scheduled Deployments
- 2026-02-17: Standalone daily sync job (server/jobs/dailySync.ts) for Replit Scheduled Deployments
- 2026-02-17: Zendesk form/group name lookups for richer topic mapping (form > group > theme engine > tags)
- 2026-02-17: VoC Theme Engine v1 - keyword-based theme extraction (billing, login, crash, performance, etc.) applied to Zendesk, Jira, and VoC imports
- 2026-02-17: Multi-factor scoring upgrade - severity-weighted volume with source weights, 7d volume trends, KPI match bonus, deadline urgency bonus, multi-source confidence
- 2026-02-17: Added Zendesk integration (cursor-based incremental ticket export, connect/sync/status, UI in Integrations tab)
- 2026-02-17: Added Pivot Mode (initiatives, topic tracking, trend analysis, pivot recommendations), VoC import, daily scheduler
- 2026-02-17: Added Jira integration (connect, sync issues as signals, dedup via externalId, Integrations tab in workspace detail)
- 2026-02-17: Initial MVP build with auth, workspaces, signals, opportunities, constraints, dashboard

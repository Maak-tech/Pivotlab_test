import type { Express, Request, Response } from "express";
import { createServer, type Server } from "http";
import session from "express-session";
import { storage } from "./storage";
import { z } from "zod";
import { recomputeOpportunities } from "./recompute";
import { connectJira, syncJira, jiraStatus, createJiraIssue } from "./integrations/jira";
import { connectZendesk, syncZendesk, zendeskStatus } from "./integrations/zendesk";
import { connectGa4, syncGa4, ga4Status } from "./integrations/ga4";
import { computeInitiativeTrends } from "./pivot-analysis";
import { extractTheme } from "./theme-engine";
import { postToSlack, buildWeeklyDigest } from "./slack";
import { scheduleOutcomeChecks } from "./outcome-checker";
import { extractThemeAI } from "./ai/theme";
import { explainOpportunity } from "./ai/explainOpportunity";
import { generateRoadmap } from "./ai/roadmap";
import { enqueueNormalizeSignal } from "./ai/enqueue";
import { runAiQueue } from "./ai/worker";
import { evaluateAlerts, routeTopicToChannel } from "./alert-evaluator";
import { db } from "./db";
import { eq, sql } from "drizzle-orm";
import { opportunities } from "@shared/schema";
import { scrypt, randomBytes, timingSafeEqual } from "crypto";
import { promisify } from "util";
import { getUncachableStripeClient, getStripePublishableKey } from "./stripeClient";

const scryptAsync = promisify(scrypt);

function qstr(val: string | string[] | undefined): string {
  return Array.isArray(val) ? val[0] : val || "";
}

async function hashPassword(password: string): Promise<string> {
  const salt = randomBytes(16).toString("hex");
  const buf = (await scryptAsync(password, salt, 64)) as Buffer;
  return `${buf.toString("hex")}.${salt}`;
}

async function comparePasswords(supplied: string, stored: string): Promise<boolean> {
  const [hashed, salt] = stored.split(".");
  const buf = (await scryptAsync(supplied, salt, 64)) as Buffer;
  return timingSafeEqual(Buffer.from(hashed, "hex"), buf);
}

declare module "express-session" {
  interface SessionData {
    userId: string;
  }
}

function requireAuth(req: Request, res: Response): string | null {
  if (!req.session.userId) {
    res.status(401).json({ error: "Unauthorized" });
    return null;
  }
  return req.session.userId;
}

const PLAN_LIMITS: Record<string, { workspaces: number; signals: number; integrations: number; aiCalls: number }> = {
  free: { workspaces: 2, signals: 100, integrations: 1, aiCalls: 10 },
  pro: { workspaces: 10, signals: 5000, integrations: 5, aiCalls: 500 },
  enterprise: { workspaces: -1, signals: -1, integrations: -1, aiCalls: -1 },
};

function getPlanLimits(plan: string) {
  return PLAN_LIMITS[plan] || PLAN_LIMITS.free;
}

async function requireRole(req: Request, res: Response, allowedRoles: string[]): Promise<string | null> {
  const userId = requireAuth(req, res);
  if (!userId) return null;

  const user = await storage.getUser(userId);
  if (!user || !allowedRoles.includes(user.role)) {
    res.status(403).json({ error: "Insufficient permissions" });
    return null;
  }
  return userId;
}

async function checkPlanLimit(userId: string, limitType: keyof typeof PLAN_LIMITS["free"]): Promise<{ allowed: boolean; limit: number; current: number }> {
  const user = await storage.getUser(userId);
  const limits = getPlanLimits(user?.plan || "free");
  const max = limits[limitType];
  if (max === -1) return { allowed: true, limit: -1, current: 0 };

  let current = 0;
  if (limitType === "workspaces") {
    const orgs = await storage.getOrganizationsByOwner(userId);
    if (orgs.length > 0) {
      const workspaces = await storage.getWorkspacesByOrg(orgs[0].id);
      current = workspaces.length;
    }
  }

  return { allowed: current < max, limit: max, current };
}

async function verifyWorkspaceOwnership(userId: string, workspaceId: string): Promise<boolean> {
  const ws = await storage.getWorkspace(workspaceId);
  if (!ws) return false;
  const orgs = await storage.getOrganizationsByOwner(userId);
  return orgs.some((org) => org.id === ws.orgId);
}

async function verifyInitiativeOwnership(userId: string, initiativeId: string): Promise<boolean> {
  const init = await storage.getInitiative(initiativeId);
  if (!init) return false;
  return verifyWorkspaceOwnership(userId, init.workspaceId);
}

export async function registerRoutes(
  httpServer: Server,
  app: Express
): Promise<Server> {
  app.use(
    session({
      secret: process.env.SESSION_SECRET || "pivotlab-secret-key-change-me",
      resave: false,
      saveUninitialized: false,
      cookie: {
        maxAge: 30 * 24 * 60 * 60 * 1000,
        httpOnly: true,
        sameSite: "lax",
      },
    })
  );

  app.post("/api/auth/register", async (req: Request, res: Response) => {
    try {
      const { username, password, displayName } = z.object({
        username: z.string().min(3).max(50),
        password: z.string().min(6),
        displayName: z.string().min(1).max(100),
      }).parse(req.body);

      const existing = await storage.getUserByUsername(username);
      if (existing) {
        return res.status(400).json({ error: "Username already taken" });
      }

      const hashedPassword = await hashPassword(password);
      const user = await storage.createUser({
        username,
        password: hashedPassword,
        displayName,
      });

      const org = await storage.createOrganization({
        name: `${displayName}'s Organization`,
        ownerId: user.id,
      });

      req.session.userId = user.id;
      return res.json({ id: user.id, username: user.username, displayName: user.displayName });
    } catch (err: any) {
      if (err instanceof z.ZodError) {
        return res.status(400).json({ error: err.errors[0]?.message || "Validation error" });
      }
      return res.status(500).json({ error: err.message });
    }
  });

  app.post("/api/auth/login", async (req: Request, res: Response) => {
    try {
      const { username, password } = z.object({
        username: z.string(),
        password: z.string(),
      }).parse(req.body);

      const user = await storage.getUserByUsername(username);
      if (!user || !(await comparePasswords(password, user.password))) {
        return res.status(401).json({ error: "Invalid credentials" });
      }

      req.session.userId = user.id;
      return res.json({ id: user.id, username: user.username, displayName: user.displayName });
    } catch (err: any) {
      return res.status(500).json({ error: err.message });
    }
  });

  app.post("/api/auth/logout", (req: Request, res: Response) => {
    req.session.destroy((err) => {
      if (err) return res.status(500).json({ error: "Failed to logout" });
      res.clearCookie("connect.sid");
      return res.json({ ok: true });
    });
  });

  app.get("/api/auth/me", async (req: Request, res: Response) => {
    if (!req.session.userId) {
      return res.status(401).json({ error: "Not authenticated" });
    }
    const user = await storage.getUser(req.session.userId);
    if (!user) {
      return res.status(401).json({ error: "User not found" });
    }
    return res.json({
      id: user.id,
      username: user.username,
      displayName: user.displayName,
      role: user.role,
      plan: user.plan,
    });
  });

  app.get("/api/plan", async (req: Request, res: Response) => {
    const userId = requireAuth(req, res);
    if (!userId) return;

    const user = await storage.getUser(userId);
    if (!user) return res.status(401).json({ error: "User not found" });

    const limits = getPlanLimits(user.plan);
    const workspaceCheck = await checkPlanLimit(userId, "workspaces");

    return res.json({
      plan: user.plan,
      limits,
      usage: {
        workspaces: workspaceCheck.current,
      },
    });
  });

  app.get("/api/workspaces", async (req: Request, res: Response) => {
    const userId = requireAuth(req, res);
    if (!userId) return;

    const ws = await storage.getWorkspacesByOwner(userId);
    return res.json(ws);
  });

  app.get("/api/workspaces/:id", async (req: Request, res: Response) => {
    const userId = requireAuth(req, res);
    if (!userId) return;

    if (!(await verifyWorkspaceOwnership(userId, qstr(req.params.id)))) {
      return res.status(404).json({ error: "Workspace not found" });
    }
    const ws = await storage.getWorkspace(qstr(req.params.id));
    return res.json(ws);
  });

  app.post("/api/workspaces", async (req: Request, res: Response) => {
    const userId = requireAuth(req, res);
    if (!userId) return;

    try {
      const planCheck = await checkPlanLimit(userId, "workspaces");
      if (!planCheck.allowed) {
        return res.status(403).json({
          error: `Workspace limit reached (${planCheck.limit}). Upgrade your plan for more.`,
          limitReached: true,
          plan: (await storage.getUser(userId))?.plan || "free",
        });
      }

      const { name, description } = z.object({
        name: z.string().min(1),
        description: z.string().optional(),
      }).parse(req.body);

      const orgs = await storage.getOrganizationsByOwner(userId);
      let orgId: string;
      if (orgs.length === 0) {
        const org = await storage.createOrganization({ name: "My Organization", ownerId: userId });
        orgId = org.id;
      } else {
        orgId = orgs[0].id;
      }

      const ws = await storage.createWorkspace({ orgId, name, description });
      return res.json(ws);
    } catch (err: any) {
      if (err instanceof z.ZodError) {
        return res.status(400).json({ error: err.errors[0]?.message });
      }
      return res.status(500).json({ error: err.message });
    }
  });

  app.get("/api/workspaces/:id/constraints", async (req: Request, res: Response) => {
    const userId = requireAuth(req, res);
    if (!userId) return;

    if (!(await verifyWorkspaceOwnership(userId, qstr(req.params.id)))) {
      return res.status(404).json({ error: "Workspace not found" });
    }
    const constraint = await storage.getConstraint(qstr(req.params.id));
    if (!constraint) return res.status(404).json({ error: "No constraints set" });
    return res.json(constraint);
  });

  app.put("/api/workspaces/:id/constraints", async (req: Request, res: Response) => {
    const userId = requireAuth(req, res);
    if (!userId) return;

    if (!(await verifyWorkspaceOwnership(userId, qstr(req.params.id)))) {
      return res.status(404).json({ error: "Workspace not found" });
    }

    try {
      const parsed = z.object({
        primaryKpi: z.string().optional(),
        targetValue: z.number().optional(),
        budgetCap: z.number().optional(),
        deadlineDate: z.string().optional(),
      }).parse(req.body);

      const constraint = await storage.upsertConstraint({
        workspaceId: qstr(req.params.id),
        primaryKpi: parsed.primaryKpi,
        targetValue: parsed.targetValue,
        budgetCap: parsed.budgetCap,
        deadlineDate: parsed.deadlineDate ? new Date(parsed.deadlineDate) : undefined,
      });
      return res.json(constraint);
    } catch (err: any) {
      if (err instanceof z.ZodError) {
        return res.status(400).json({ error: err.errors[0]?.message });
      }
      return res.status(500).json({ error: err.message });
    }
  });

  app.get("/api/signals/:workspaceId", async (req: Request, res: Response) => {
    const userId = requireAuth(req, res);
    if (!userId) return;

    if (!(await verifyWorkspaceOwnership(userId, qstr(req.params.workspaceId)))) {
      return res.status(404).json({ error: "Workspace not found" });
    }
    const sigs = await storage.getSignals(qstr(req.params.workspaceId));
    return res.json(sigs);
  });

  app.post("/api/signals", async (req: Request, res: Response) => {
    const userId = requireAuth(req, res);
    if (!userId) return;

    try {
      const parsed = z.object({
        workspaceId: z.string(),
        source: z.string(),
        kind: z.string(),
        title: z.string().min(1),
        topic: z.string().optional(),
        body: z.string().optional(),
        severity: z.number().int().min(1).max(5).optional(),
        externalUrl: z.string().url().optional(),
      }).parse(req.body);

      const signal = await storage.createSignal({
        workspaceId: parsed.workspaceId,
        source: parsed.source,
        kind: parsed.kind,
        title: parsed.title,
        topic: parsed.topic,
        body: parsed.body,
        severity: parsed.severity ?? 3,
        externalUrl: parsed.externalUrl,
      });
      return res.json(signal);
    } catch (err: any) {
      if (err instanceof z.ZodError) {
        return res.status(400).json({ error: err.errors[0]?.message });
      }
      return res.status(500).json({ error: err.message });
    }
  });

  app.get("/api/opportunities/:workspaceId", async (req: Request, res: Response) => {
    const userId = requireAuth(req, res);
    if (!userId) return;

    if (!(await verifyWorkspaceOwnership(userId, qstr(req.params.workspaceId)))) {
      return res.status(404).json({ error: "Workspace not found" });
    }
    const opps = await storage.getOpportunities(qstr(req.params.workspaceId));
    return res.json(opps);
  });

  app.post("/api/opportunities/recompute", async (req: Request, res: Response) => {
    const userId = requireAuth(req, res);
    if (!userId) return;

    const workspaceId = req.query.workspaceId as string;
    if (!workspaceId) return res.status(400).json({ error: "workspaceId required" });

    if (!(await verifyWorkspaceOwnership(userId, workspaceId))) {
      return res.status(404).json({ error: "Workspace not found" });
    }

    try {
      const result = await recomputeOpportunities(workspaceId);
      return res.json(result);
    } catch (err: any) {
      return res.status(500).json({ error: err.message });
    }
  });

  app.patch("/api/opportunities/:id", async (req: Request, res: Response) => {
    const userId = requireAuth(req, res);
    if (!userId) return;

    try {
      const { status } = z.object({
        status: z.enum(["open", "planned", "shipped", "rejected"]),
      }).parse(req.body);

      const updated = await storage.updateOpportunityStatus(qstr(req.params.id), status);
      if (!updated) return res.status(404).json({ error: "Opportunity not found" });
      return res.json(updated);
    } catch (err: any) {
      if (err instanceof z.ZodError) {
        return res.status(400).json({ error: err.errors[0]?.message });
      }
      return res.status(500).json({ error: err.message });
    }
  });

  app.post("/api/integrations/jira/connect", async (req: Request, res: Response) => {
    const userId = requireAuth(req, res);
    if (!userId) return;

    try {
      const parsed = z.object({
        workspaceId: z.string(),
        baseUrl: z.string().url(),
        email: z.string().email(),
        apiToken: z.string().min(10),
        jql: z.string().optional(),
      }).parse(req.body);

      if (!(await verifyWorkspaceOwnership(userId, parsed.workspaceId))) {
        return res.status(404).json({ error: "Workspace not found" });
      }

      const saved = await connectJira(parsed);
      return res.json({ ok: true, integration: { workspaceId: saved.workspaceId, baseUrl: saved.baseUrl, jql: saved.jql } });
    } catch (err: any) {
      if (err instanceof z.ZodError) {
        return res.status(400).json({ error: err.errors[0]?.message });
      }
      return res.status(500).json({ error: err.message });
    }
  });

  app.post("/api/integrations/jira/sync", async (req: Request, res: Response) => {
    const userId = requireAuth(req, res);
    if (!userId) return;

    try {
      const { workspaceId } = z.object({ workspaceId: z.string() }).parse(req.body);

      if (!(await verifyWorkspaceOwnership(userId, workspaceId))) {
        return res.status(404).json({ error: "Workspace not found" });
      }

      const result = await syncJira(workspaceId);
      return res.json({ ok: true, ...result });
    } catch (err: any) {
      if (err instanceof z.ZodError) {
        return res.status(400).json({ error: err.errors[0]?.message });
      }
      return res.status(500).json({ error: err.message });
    }
  });

  app.get("/api/integrations/jira/status", async (req: Request, res: Response) => {
    const userId = requireAuth(req, res);
    if (!userId) return;

    const workspaceId = req.query.workspaceId as string;
    if (!workspaceId) return res.status(400).json({ error: "workspaceId required" });

    if (!(await verifyWorkspaceOwnership(userId, workspaceId))) {
      return res.status(404).json({ error: "Workspace not found" });
    }

    const status = await jiraStatus(workspaceId);
    return res.json(status);
  });

  app.post("/api/integrations/zendesk/connect", async (req: Request, res: Response) => {
    const userId = requireAuth(req, res);
    if (!userId) return;

    try {
      const parsed = z.object({
        workspaceId: z.string(),
        baseUrl: z.string().url(),
        email: z.string().email(),
        apiToken: z.string().min(10),
        startDaysAgo: z.number().int().min(1).max(365).optional(),
      }).parse(req.body);

      if (!(await verifyWorkspaceOwnership(userId, parsed.workspaceId))) {
        return res.status(404).json({ error: "Workspace not found" });
      }

      const saved = await connectZendesk(parsed);
      return res.json({ ok: true, workspaceId: saved.workspaceId });
    } catch (err: any) {
      if (err instanceof z.ZodError) {
        return res.status(400).json({ error: err.errors[0]?.message });
      }
      return res.status(500).json({ error: err.message });
    }
  });

  app.post("/api/integrations/zendesk/sync", async (req: Request, res: Response) => {
    const userId = requireAuth(req, res);
    if (!userId) return;

    try {
      const { workspaceId } = z.object({ workspaceId: z.string() }).parse(req.body);

      if (!(await verifyWorkspaceOwnership(userId, workspaceId))) {
        return res.status(404).json({ error: "Workspace not found" });
      }

      const result = await syncZendesk(workspaceId);
      await recomputeOpportunities(workspaceId);

      return res.json({ ok: true, ...result });
    } catch (err: any) {
      if (err instanceof z.ZodError) {
        return res.status(400).json({ error: err.errors[0]?.message });
      }
      return res.status(500).json({ error: err.message });
    }
  });

  app.get("/api/integrations/zendesk/status", async (req: Request, res: Response) => {
    const userId = requireAuth(req, res);
    if (!userId) return;

    const workspaceId = req.query.workspaceId as string;
    if (!workspaceId) return res.status(400).json({ error: "workspaceId required" });

    if (!(await verifyWorkspaceOwnership(userId, workspaceId))) {
      return res.status(404).json({ error: "Workspace not found" });
    }

    const status = await zendeskStatus(workspaceId);
    return res.json(status);
  });

  app.post("/api/integrations/ga4/connect", async (req: Request, res: Response) => {
    const userId = requireAuth(req, res);
    if (!userId) return;

    try {
      const parsed = z.object({
        workspaceId: z.string(),
        propertyId: z.string().min(3),
        keyEvents: z.array(z.string()).optional(),
      }).parse(req.body);

      if (!(await verifyWorkspaceOwnership(userId, parsed.workspaceId))) {
        return res.status(404).json({ error: "Workspace not found" });
      }

      const saved = await connectGa4(parsed);
      return res.json({ ok: true, connected: true, workspaceId: saved.workspaceId });
    } catch (err: any) {
      if (err.name === "ZodError") {
        return res.status(400).json({ error: err.errors[0]?.message });
      }
      return res.status(500).json({ error: err.message });
    }
  });

  app.post("/api/integrations/ga4/sync", async (req: Request, res: Response) => {
    const userId = requireAuth(req, res);
    if (!userId) return;

    try {
      const parsed = z.object({ workspaceId: z.string() }).parse(req.body);

      if (!(await verifyWorkspaceOwnership(userId, parsed.workspaceId))) {
        return res.status(404).json({ error: "Workspace not found" });
      }

      const result = await syncGa4(parsed.workspaceId);
      return res.json({ ok: true, ...result });
    } catch (err: any) {
      return res.status(500).json({ error: err.message });
    }
  });

  app.get("/api/integrations/ga4/status", async (req: Request, res: Response) => {
    const userId = requireAuth(req, res);
    if (!userId) return;

    const workspaceId = req.query.workspaceId as string;
    if (!workspaceId) return res.status(400).json({ error: "workspaceId required" });

    if (!(await verifyWorkspaceOwnership(userId, workspaceId))) {
      return res.status(404).json({ error: "Workspace not found" });
    }

    const status = await ga4Status(workspaceId);
    return res.json(status);
  });

  app.get("/api/initiatives/:workspaceId", async (req: Request, res: Response) => {
    const userId = requireAuth(req, res);
    if (!userId) return;

    if (!(await verifyWorkspaceOwnership(userId, qstr(req.params.workspaceId)))) {
      return res.status(404).json({ error: "Workspace not found" });
    }

    const inits = await storage.getInitiativesByWorkspace(qstr(req.params.workspaceId));
    return res.json(inits);
  });

  app.post("/api/initiatives", async (req: Request, res: Response) => {
    const userId = requireAuth(req, res);
    if (!userId) return;

    try {
      const parsed = z.object({
        workspaceId: z.string(),
        name: z.string().min(1),
        goalKpi: z.string().optional(),
        targetValue: z.number().optional(),
        endDate: z.string().optional(),
        topics: z.array(z.string()).optional(),
        killCriteria: z.object({
          dropIfNoImprovementDays: z.number().optional(),
          maxSlipDays: z.number().optional(),
        }).optional(),
      }).parse(req.body);

      if (!(await verifyWorkspaceOwnership(userId, parsed.workspaceId))) {
        return res.status(404).json({ error: "Workspace not found" });
      }

      const initiative = await storage.createInitiative({
        workspaceId: parsed.workspaceId,
        name: parsed.name,
        goalKpi: parsed.goalKpi,
        targetValue: parsed.targetValue,
        endDate: parsed.endDate ? new Date(parsed.endDate) : undefined,
        killCriteria: parsed.killCriteria,
      });

      if (parsed.topics) {
        for (const topic of parsed.topics) {
          await storage.addInitiativeTopic(initiative.id, topic);
        }
      }

      const full = await storage.getInitiative(initiative.id);
      return res.json(full);
    } catch (err: any) {
      if (err instanceof z.ZodError) {
        return res.status(400).json({ error: err.errors[0]?.message });
      }
      return res.status(500).json({ error: err.message });
    }
  });

  app.patch("/api/initiatives/:id/status", async (req: Request, res: Response) => {
    const userId = requireAuth(req, res);
    if (!userId) return;

    try {
      const { status } = z.object({
        status: z.enum(["active", "pivoted", "stopped", "shipped"]),
      }).parse(req.body);

      if (!(await verifyInitiativeOwnership(userId, qstr(req.params.id)))) {
        return res.status(404).json({ error: "Initiative not found" });
      }

      const updated = await storage.updateInitiativeStatus(qstr(req.params.id), status);
      if (!updated) return res.status(404).json({ error: "Initiative not found" });
      return res.json(updated);
    } catch (err: any) {
      if (err instanceof z.ZodError) {
        return res.status(400).json({ error: err.errors[0]?.message });
      }
      return res.status(500).json({ error: err.message });
    }
  });

  app.post("/api/initiatives/:id/topics", async (req: Request, res: Response) => {
    const userId = requireAuth(req, res);
    if (!userId) return;

    if (!(await verifyInitiativeOwnership(userId, qstr(req.params.id)))) {
      return res.status(404).json({ error: "Initiative not found" });
    }

    try {
      const { topic } = z.object({ topic: z.string().min(1) }).parse(req.body);
      const created = await storage.addInitiativeTopic(qstr(req.params.id), topic);
      return res.json(created);
    } catch (err: any) {
      if (err instanceof z.ZodError) {
        return res.status(400).json({ error: err.errors[0]?.message });
      }
      if (err.code === "23505") {
        return res.status(400).json({ error: "Topic already tracked" });
      }
      return res.status(500).json({ error: err.message });
    }
  });

  app.delete("/api/initiatives/topics/:topicId", async (req: Request, res: Response) => {
    const userId = requireAuth(req, res);
    if (!userId) return;

    await storage.removeInitiativeTopic(qstr(req.params.topicId));
    return res.json({ ok: true });
  });

  app.get("/api/initiatives/:id/trends", async (req: Request, res: Response) => {
    const userId = requireAuth(req, res);
    if (!userId) return;

    if (!(await verifyInitiativeOwnership(userId, qstr(req.params.id)))) {
      return res.status(404).json({ error: "Initiative not found" });
    }

    try {
      const result = await computeInitiativeTrends(qstr(req.params.id));
      return res.json(result);
    } catch (err: any) {
      return res.status(500).json({ error: err.message });
    }
  });

  app.post("/api/integrations/voc/import", async (req: Request, res: Response) => {
    const userId = requireAuth(req, res);
    if (!userId) return;

    try {
      const parsed = z.object({
        workspaceId: z.string(),
        items: z.array(z.object({
          rating: z.number().int().min(1).max(5).optional(),
          title: z.string().min(1),
          body: z.string().optional(),
          url: z.string().optional(),
          source: z.string().optional(),
          topic: z.string().optional(),
        })).min(1),
      }).parse(req.body);

      if (!(await verifyWorkspaceOwnership(userId, parsed.workspaceId))) {
        return res.status(404).json({ error: "Workspace not found" });
      }

      const signalData = parsed.items.map((item, idx) => ({
        workspaceId: parsed.workspaceId,
        source: item.source || "app_reviews",
        kind: "voc",
        title: item.title.slice(0, 250),
        topic: item.topic || extractTheme(`${item.title} ${item.body || ""}`) || undefined,
        body: item.body || undefined,
        severity: item.rating ? 6 - item.rating : 3,
        externalUrl: item.url || undefined,
        externalId: item.url ? `voc:${item.url}` : `voc:import-${Date.now()}-${idx}`,
      }));

      const inserted = await storage.createSignalsSkipDuplicates(signalData);

      if (inserted > 0 && process.env.OPENAI_API_KEY) {
        try {
          const externalIds = signalData.map(s => s.externalId).filter(Boolean) as string[];
          const unnormalized = await storage.getUnnormalizedSignals(parsed.workspaceId, externalIds);
          if (unnormalized.length > 0) {
            await enqueueNormalizeSignal(unnormalized.map(s => s.id));
          }
        } catch (err: any) {
          console.error(`[voc-import] Failed to enqueue AI normalization: ${err.message}`);
        }
      }

      return res.json({ ok: true, total: parsed.items.length, inserted });
    } catch (err: any) {
      if (err instanceof z.ZodError) {
        return res.status(400).json({ error: err.errors[0]?.message });
      }
      return res.status(500).json({ error: err.message });
    }
  });

  app.post("/api/integrations/slack/connect", async (req: Request, res: Response) => {
    const userId = requireAuth(req, res);
    if (!userId) return;

    try {
      const parsed = z.object({
        workspaceId: z.string(),
        webhookUrl: z.string().url().refine(
          (url) => url.startsWith("https://hooks.slack.com/services/") || url.startsWith("https://hooks.slack.com/workflows/"),
          { message: "Must be a valid Slack webhook URL (https://hooks.slack.com/services/...)" }
        ),
        channelName: z.string().optional(),
      }).parse(req.body);

      if (!(await verifyWorkspaceOwnership(userId, parsed.workspaceId))) {
        return res.status(404).json({ error: "Workspace not found" });
      }

      const integ = await storage.upsertSlackIntegration({
        workspaceId: parsed.workspaceId,
        webhookUrl: parsed.webhookUrl,
        channelName: parsed.channelName,
      });

      return res.json({ ok: true, connected: true, workspaceId: integ.workspaceId });
    } catch (err: any) {
      if (err instanceof z.ZodError) {
        return res.status(400).json({ error: err.errors[0]?.message });
      }
      return res.status(500).json({ error: err.message });
    }
  });

  app.post("/api/integrations/slack/test", async (req: Request, res: Response) => {
    const userId = requireAuth(req, res);
    if (!userId) return;

    try {
      const { workspaceId } = z.object({ workspaceId: z.string() }).parse(req.body);

      if (!(await verifyWorkspaceOwnership(userId, workspaceId))) {
        return res.status(404).json({ error: "Workspace not found" });
      }

      const integ = await storage.getSlackIntegration(workspaceId);
      if (!integ || !integ.enabled) {
        return res.status(400).json({ error: "Slack not connected" });
      }

      await postToSlack(integ.webhookUrl, "PivotLab AI connected. Weekly digests will post here.");
      return res.json({ ok: true });
    } catch (err: any) {
      return res.status(500).json({ error: err.message });
    }
  });

  app.post("/api/integrations/slack/preview-digest", async (req: Request, res: Response) => {
    const userId = requireAuth(req, res);
    if (!userId) return;

    try {
      const { workspaceId } = z.object({ workspaceId: z.string() }).parse(req.body);

      if (!(await verifyWorkspaceOwnership(userId, workspaceId))) {
        return res.status(404).json({ error: "Workspace not found" });
      }

      const digest = await buildWeeklyDigest(workspaceId);
      return res.json({ digest });
    } catch (err: any) {
      return res.status(500).json({ error: err.message });
    }
  });

  app.post("/api/integrations/slack/send-digest", async (req: Request, res: Response) => {
    const userId = requireAuth(req, res);
    if (!userId) return;

    try {
      const { workspaceId } = z.object({ workspaceId: z.string() }).parse(req.body);

      if (!(await verifyWorkspaceOwnership(userId, workspaceId))) {
        return res.status(404).json({ error: "Workspace not found" });
      }

      const integ = await storage.getSlackIntegration(workspaceId);
      if (!integ || !integ.enabled) {
        return res.status(400).json({ error: "Slack not connected" });
      }

      const digest = await buildWeeklyDigest(workspaceId);
      await postToSlack(integ.webhookUrl, digest);
      return res.json({ ok: true });
    } catch (err: any) {
      return res.status(500).json({ error: err.message });
    }
  });

  app.get("/api/integrations/slack/status", async (req: Request, res: Response) => {
    const userId = requireAuth(req, res);
    if (!userId) return;

    const workspaceId = req.query.workspaceId as string;
    if (!workspaceId) return res.status(400).json({ error: "workspaceId required" });

    if (!(await verifyWorkspaceOwnership(userId, workspaceId))) {
      return res.status(404).json({ error: "Workspace not found" });
    }

    const integ = await storage.getSlackIntegration(workspaceId);
    if (!integ) return res.json({ connected: false });
    return res.json({
      connected: true,
      enabled: integ.enabled,
      channelName: integ.channelName,
    });
  });

  app.post("/api/integrations/slack/disconnect", async (req: Request, res: Response) => {
    const userId = requireAuth(req, res);
    if (!userId) return;

    try {
      const { workspaceId } = z.object({ workspaceId: z.string() }).parse(req.body);

      if (!(await verifyWorkspaceOwnership(userId, workspaceId))) {
        return res.status(404).json({ error: "Workspace not found" });
      }

      await storage.disableSlackIntegration(workspaceId);
      return res.json({ ok: true });
    } catch (err: any) {
      return res.status(500).json({ error: err.message });
    }
  });

  app.post("/api/action/turn-into-work", async (req: Request, res: Response) => {
    const userId = requireAuth(req, res);
    if (!userId) return;

    try {
      const parsed = z.object({
        workspaceId: z.string(),
        opportunityId: z.string().optional(),
        recommendationId: z.string().optional(),
        name: z.string().min(1),
        goalKpi: z.string().optional(),
        targetValue: z.number().optional(),
        topics: z.array(z.string()).optional(),
        createJiraIssue: z.boolean().optional(),
        jiraProjectKey: z.string().optional(),
        jiraIssueType: z.string().optional(),
      }).parse(req.body);

      if (!(await verifyWorkspaceOwnership(userId, parsed.workspaceId))) {
        return res.status(404).json({ error: "Workspace not found" });
      }

      let problemStatement = "";
      let evidenceSnippets: string[] = [];

      if (parsed.opportunityId) {
        const opp = await storage.getOpportunity(parsed.opportunityId);
        if (opp) {
          problemStatement = opp.problemStatement;
          evidenceSnippets = opp.evidence.map(e => e.snippet || "").filter(Boolean).slice(0, 5);
        }
      }

      if (parsed.recommendationId) {
        const init = await storage.getInitiative(parsed.recommendationId);
        if (!init) {
          const allInits = await storage.getInitiativesByWorkspace(parsed.workspaceId);
          for (const i of allInits) {
            const rec = i.recommendations.find(r => r.id === parsed.recommendationId);
            if (rec) {
              problemStatement = rec.reason;
              break;
            }
          }
        }
      }

      const initiative = await storage.createInitiative({
        workspaceId: parsed.workspaceId,
        name: parsed.name,
        goalKpi: parsed.goalKpi,
        targetValue: parsed.targetValue,
        opportunityId: parsed.opportunityId,
        recommendationId: parsed.recommendationId,
      });

      if (parsed.topics) {
        for (const topic of parsed.topics) {
          try {
            await storage.addInitiativeTopic(initiative.id, topic);
          } catch (e) {}
        }
      }

      let jiraResult: { key: string; url: string } | null = null;
      if (parsed.createJiraIssue) {
        try {
          const description = [
            problemStatement ? `Problem Statement:\n${problemStatement}` : "",
            parsed.goalKpi ? `KPI Target: ${parsed.goalKpi}${parsed.targetValue ? ` = ${parsed.targetValue}` : ""}` : "",
            parsed.topics?.length ? `Topics tracked: ${parsed.topics.join(", ")}` : "",
            evidenceSnippets.length > 0
              ? `Evidence:\n${evidenceSnippets.map((s, i) => `${i + 1}. ${s}`).join("\n")}`
              : "",
          ].filter(Boolean).join("\n\n");

          jiraResult = await createJiraIssue(parsed.workspaceId, {
            summary: parsed.name,
            description,
            issueType: parsed.jiraIssueType || "Story",
            projectKey: parsed.jiraProjectKey,
          });

          await storage.updateInitiativeJira(initiative.id, jiraResult.key, jiraResult.url);
        } catch (err: any) {
          console.error(`[action] Jira issue creation failed: ${err.message}`);
        }
      }

      if (parsed.opportunityId) {
        await storage.updateOpportunityStatus(parsed.opportunityId, "planned");
      }

      const full = await storage.getInitiative(initiative.id);
      return res.json({
        ok: true,
        initiative: full,
        jira: jiraResult,
      });
    } catch (err: any) {
      if (err instanceof z.ZodError) {
        return res.status(400).json({ error: err.errors[0]?.message });
      }
      return res.status(500).json({ error: err.message });
    }
  });

  app.post("/api/action/ship", async (req: Request, res: Response) => {
    const userId = requireAuth(req, res);
    if (!userId) return;

    try {
      const { initiativeId } = z.object({ initiativeId: z.string() }).parse(req.body);

      if (!(await verifyInitiativeOwnership(userId, initiativeId))) {
        return res.status(404).json({ error: "Initiative not found" });
      }

      const init = await storage.getInitiative(initiativeId);
      if (!init) return res.status(404).json({ error: "Initiative not found" });

      const shippedAt = new Date();
      await storage.updateInitiativeShipped(initiativeId, shippedAt);
      await scheduleOutcomeChecks(initiativeId, init.workspaceId, shippedAt);

      if (init.opportunityId) {
        await storage.updateOpportunityStatus(init.opportunityId, "shipped");
      }

      return res.json({ ok: true, shippedAt });
    } catch (err: any) {
      if (err instanceof z.ZodError) {
        return res.status(400).json({ error: err.errors[0]?.message });
      }
      return res.status(500).json({ error: err.message });
    }
  });

  app.post("/api/decisions", async (req: Request, res: Response) => {
    const userId = requireAuth(req, res);
    if (!userId) return;

    try {
      const parsed = z.object({
        workspaceId: z.string(),
        recommendationId: z.string().optional(),
        opportunityId: z.string().optional(),
        initiativeId: z.string().optional(),
        decision: z.enum(["accepted", "rejected"]),
        reason: z.string().optional(),
        expectedKpiImpact: z.string().optional(),
        owner: z.string().optional(),
        dueDate: z.string().optional(),
      }).parse(req.body);

      if (!(await verifyWorkspaceOwnership(userId, parsed.workspaceId))) {
        return res.status(404).json({ error: "Workspace not found" });
      }

      const record = await storage.createDecisionRecord({
        workspaceId: parsed.workspaceId,
        recommendationId: parsed.recommendationId,
        opportunityId: parsed.opportunityId,
        initiativeId: parsed.initiativeId,
        decision: parsed.decision,
        reason: parsed.reason,
        expectedKpiImpact: parsed.expectedKpiImpact,
        owner: parsed.owner,
        dueDate: parsed.dueDate ? new Date(parsed.dueDate) : undefined,
      });

      return res.json(record);
    } catch (err: any) {
      if (err instanceof z.ZodError) {
        return res.status(400).json({ error: err.errors[0]?.message });
      }
      return res.status(500).json({ error: err.message });
    }
  });

  app.get("/api/decisions/:workspaceId", async (req: Request, res: Response) => {
    const userId = requireAuth(req, res);
    if (!userId) return;

    if (!(await verifyWorkspaceOwnership(userId, qstr(req.params.workspaceId)))) {
      return res.status(404).json({ error: "Workspace not found" });
    }

    const records = await storage.getDecisionRecords(qstr(req.params.workspaceId));
    return res.json(records);
  });

  app.get("/api/outcome-checks/:initiativeId", async (req: Request, res: Response) => {
    const userId = requireAuth(req, res);
    if (!userId) return;

    if (!(await verifyInitiativeOwnership(userId, qstr(req.params.initiativeId)))) {
      return res.status(404).json({ error: "Initiative not found" });
    }

    const checks = await storage.getOutcomeChecksByInitiative(qstr(req.params.initiativeId));
    return res.json(checks);
  });

  app.post("/api/ai/theme", async (req: Request, res: Response) => {
    const userId = requireAuth(req, res);
    if (!userId) return;

    try {
      const parsed = z.object({
        text: z.string().min(10),
        source: z.string().optional(),
      }).parse(req.body);

      const theme = await extractThemeAI({ text: parsed.text, source: parsed.source });
      return res.json({ ok: true, theme });
    } catch (err: any) {
      if (err?.name === "ZodError") return res.status(400).json({ error: "Invalid input", details: err.errors });
      return res.status(500).json({ error: err.message });
    }
  });

  app.get("/api/ai/opportunities/:id/explain", async (req: Request, res: Response) => {
    const userId = requireAuth(req, res);
    if (!userId) return;

    try {
      const id = qstr(req.params.id);
      const opp = await storage.getOpportunity(id);
      if (!opp) return res.status(404).json({ error: "Opportunity not found" });

      const wsIds = (await storage.getWorkspacesByOwner(userId)).map(w => w.id);
      if (!wsIds.includes(opp.workspaceId)) return res.status(404).json({ error: "Not found" });

      const constraint = await storage.getConstraint(opp.workspaceId);

      const stream = explainOpportunity({
        title: opp.title,
        problemStatement: opp.problemStatement,
        evidenceSnippets: opp.evidence.map(e => e.snippet || "").filter(Boolean),
        constraints: {
          kpi: constraint?.primaryKpi ?? null,
          budget: constraint?.budgetCap ?? null,
          deadline: constraint?.deadlineDate ? constraint.deadlineDate.toISOString().slice(0, 10) : null,
        },
      });

      res.setHeader("Content-Type", "text/plain; charset=utf-8");
      res.setHeader("Transfer-Encoding", "chunked");
      res.setHeader("Cache-Control", "no-cache");

      for await (const chunk of stream.textStream) {
        res.write(chunk);
      }
      res.end();
    } catch (err: any) {
      if (!res.headersSent) {
        return res.status(500).json({ error: err.message });
      }
      res.end();
    }
  });

  app.post("/api/ai/roadmap", async (req: Request, res: Response) => {
    const userId = requireAuth(req, res);
    if (!userId) return;

    try {
      const parsed = z.object({
        workspaceId: z.string(),
        goalKpi: z.string().min(2),
        budget: z.number().optional(),
        timelineWeeks: z.number().int().min(1).max(52).optional(),
      }).parse(req.body);

      const wsIds = (await storage.getWorkspacesByOwner(userId)).map(w => w.id);
      if (!wsIds.includes(parsed.workspaceId)) return res.status(404).json({ error: "Workspace not found" });

      const opps = await storage.getOpportunities(parsed.workspaceId);
      const openOpps = opps
        .filter(o => o.status === "open")
        .sort((a, b) => b.score - a.score)
        .slice(0, 10);

      const roadmap = await generateRoadmap({
        goalKpi: parsed.goalKpi,
        budget: parsed.budget ?? null,
        timelineWeeks: parsed.timelineWeeks ?? null,
        opportunities: openOpps.map(o => ({
          title: o.title,
          score: o.score,
          problemStatement: o.problemStatement,
        })),
      });

      return res.json({ ok: true, roadmap });
    } catch (err: any) {
      if (err?.name === "ZodError") return res.status(400).json({ error: "Invalid input", details: err.errors });
      return res.status(500).json({ error: err.message });
    }
  });

  app.get("/api/dashboard/stats", async (req: Request, res: Response) => {
    const userId = requireAuth(req, res);
    if (!userId) return;

    try {
      const stats = await storage.getDashboardStats(userId);
      return res.json(stats);
    } catch (err: any) {
      return res.status(500).json({ error: err.message });
    }
  });

  app.post("/api/opportunities/:id/accept", async (req: Request, res: Response) => {
    const userId = requireAuth(req, res);
    if (!userId) return;

    try {
      const oppId = req.params.id;
      const parsed = z.object({
        reason: z.string().optional(),
        expectedKpiImpact: z.string().optional(),
        owner: z.string().optional(),
        dueDate: z.string().optional(),
        createJiraIssue: z.boolean().optional(),
      }).parse(req.body);

      const opp = await storage.getOpportunity(oppId);
      if (!opp) return res.status(404).json({ error: "Opportunity not found" });
      if (!(await verifyWorkspaceOwnership(userId, opp.workspaceId))) {
        return res.status(404).json({ error: "Workspace not found" });
      }

      await storage.updateOpportunityStatus(oppId, "planned");

      let jiraResult: { key?: string; url?: string } = {};
      if (parsed.createJiraIssue) {
        try {
          const evidenceText = opp.evidence?.map((e: any) => `- ${e.snippet || ""}${e.url ? ` (${e.url})` : ""}`).join("\n") || "";
          const description = [
            `*Problem Statement*\n${opp.problemStatement || opp.title}`,
            evidenceText ? `\n*Evidence*\n${evidenceText}` : "",
            parsed.expectedKpiImpact ? `\n*Expected KPI Impact*: ${parsed.expectedKpiImpact}` : "",
            opp.aiSummary ? `\n*AI Summary*: ${opp.aiSummary}` : "",
            `\nScore: ${opp.score.toFixed(1)} | Confidence: ${Math.round(opp.confidence * 100)}%`,
          ].filter(Boolean).join("\n");

          const jiraIssue = await createJiraIssue(opp.workspaceId, {
            summary: `[PivotLab] ${opp.title}`,
            description,
            issueType: "Story",
          });

          jiraResult = { key: jiraIssue.key, url: jiraIssue.url };

          await db.update(opportunities)
            .set({
              jiraIssueKey: jiraIssue.key,
              jiraIssueUrl: jiraIssue.url,
              updatedAt: new Date(),
            })
            .where(eq(opportunities.id, oppId));
        } catch (jiraErr: any) {
          console.error(`[accept] Jira issue creation failed: ${jiraErr.message}`);
        }
      }

      const decisionRecord = await storage.createDecisionRecord({
        workspaceId: opp.workspaceId,
        opportunityId: oppId,
        decision: "accepted",
        reason: parsed.reason || "Accepted from opportunity list",
        expectedKpiImpact: parsed.expectedKpiImpact || undefined,
        owner: parsed.owner || undefined,
        dueDate: parsed.dueDate ? new Date(parsed.dueDate) : undefined,
      });

      return res.json({
        ok: true,
        opportunityId: oppId,
        status: "planned",
        jiraIssueKey: jiraResult.key,
        jiraIssueUrl: jiraResult.url,
        decisionRecordId: decisionRecord.id,
      });
    } catch (err: any) {
      if (err instanceof z.ZodError) return res.status(400).json({ error: err.errors[0]?.message });
      return res.status(500).json({ error: err.message });
    }
  });

  app.get("/api/alert-rules/:workspaceId", async (req: Request, res: Response) => {
    const userId = requireAuth(req, res);
    if (!userId) return;
    try {
      if (!(await verifyWorkspaceOwnership(userId, req.params.workspaceId))) {
        return res.status(404).json({ error: "Workspace not found" });
      }
      const rules = await storage.getAlertRules(req.params.workspaceId);
      return res.json(rules);
    } catch (err: any) {
      return res.status(500).json({ error: err.message });
    }
  });

  app.post("/api/alert-rules", async (req: Request, res: Response) => {
    const userId = requireAuth(req, res);
    if (!userId) return;
    try {
      const parsed = z.object({
        workspaceId: z.string(),
        name: z.string().min(1),
        topicPattern: z.string().optional(),
        conditions: z.any(),
        scoreThreshold: z.number().optional(),
        cooldownHours: z.number().int().min(1).optional(),
        slackChannel: z.string().optional(),
        enabled: z.boolean().optional(),
      }).parse(req.body);
      if (!(await verifyWorkspaceOwnership(userId, parsed.workspaceId))) {
        return res.status(404).json({ error: "Workspace not found" });
      }
      const rule = await storage.createAlertRule(parsed as any);
      return res.json(rule);
    } catch (err: any) {
      if (err instanceof z.ZodError) return res.status(400).json({ error: err.errors[0]?.message });
      return res.status(500).json({ error: err.message });
    }
  });

  app.patch("/api/alert-rules/:id", async (req: Request, res: Response) => {
    const userId = requireAuth(req, res);
    if (!userId) return;
    try {
      const updated = await storage.updateAlertRule(req.params.id, req.body);
      if (!updated) return res.status(404).json({ error: "Rule not found" });
      return res.json(updated);
    } catch (err: any) {
      return res.status(500).json({ error: err.message });
    }
  });

  app.delete("/api/alert-rules/:id", async (req: Request, res: Response) => {
    const userId = requireAuth(req, res);
    if (!userId) return;
    try {
      await storage.deleteAlertRule(req.params.id);
      return res.json({ ok: true });
    } catch (err: any) {
      return res.status(500).json({ error: err.message });
    }
  });

  app.get("/api/alert-logs/:workspaceId", async (req: Request, res: Response) => {
    const userId = requireAuth(req, res);
    if (!userId) return;
    try {
      if (!(await verifyWorkspaceOwnership(userId, req.params.workspaceId))) {
        return res.status(404).json({ error: "Workspace not found" });
      }
      const logs = await storage.getAlertLogs(req.params.workspaceId);
      return res.json(logs);
    } catch (err: any) {
      return res.status(500).json({ error: err.message });
    }
  });

  app.post("/api/admin/alerts/evaluate", async (req: Request, res: Response) => {
    const userId = requireAuth(req, res);
    if (!userId) return;
    try {
      const result = await evaluateAlerts();
      return res.json(result);
    } catch (err: any) {
      return res.status(500).json({ error: err.message });
    }
  });

  app.post("/api/admin/ai/run", async (req: Request, res: Response) => {
    const userId = await requireRole(req, res, ["admin"]);
    if (!userId) return;

    try {
      const limit = Number(req.body?.limit || 20);
      const result = await runAiQueue(Math.min(limit, 100));
      return res.json(result);
    } catch (err: any) {
      return res.status(500).json({ error: err.message });
    }
  });

  app.get("/api/admin/ai/stats", async (req: Request, res: Response) => {
    const userId = await requireRole(req, res, ["admin"]);
    if (!userId) return;

    try {
      const stats = await storage.getAiQueueStats();
      return res.json(stats);
    } catch (err: any) {
      return res.status(500).json({ error: err.message });
    }
  });

  app.get("/api/stripe/publishable-key", async (_req: Request, res: Response) => {
    try {
      const key = await getStripePublishableKey();
      return res.json({ publishableKey: key });
    } catch (err: any) {
      return res.status(500).json({ error: "Stripe not configured" });
    }
  });

  app.get("/api/stripe/products", async (_req: Request, res: Response) => {
    try {
      const result = await db.execute(
        sql`SELECT 
          p.id as product_id,
          p.name as product_name,
          p.description as product_description,
          p.active as product_active,
          p.metadata as product_metadata,
          pr.id as price_id,
          pr.unit_amount,
          pr.currency,
          pr.recurring,
          pr.active as price_active
        FROM stripe.products p
        LEFT JOIN stripe.prices pr ON pr.product = p.id AND pr.active = true
        WHERE p.active = true
        ORDER BY pr.unit_amount ASC`
      );

      const productsMap = new Map<string, any>();
      for (const row of result.rows) {
        const r = row as any;
        if (!productsMap.has(r.product_id)) {
          productsMap.set(r.product_id, {
            id: r.product_id,
            name: r.product_name,
            description: r.product_description,
            metadata: r.product_metadata,
            prices: [],
          });
        }
        if (r.price_id) {
          productsMap.get(r.product_id).prices.push({
            id: r.price_id,
            unitAmount: r.unit_amount,
            currency: r.currency,
            recurring: r.recurring,
          });
        }
      }

      return res.json({ products: Array.from(productsMap.values()) });
    } catch (err: any) {
      return res.json({ products: [] });
    }
  });

  app.post("/api/stripe/checkout", async (req: Request, res: Response) => {
    const userId = requireAuth(req, res);
    if (!userId) return;

    try {
      const { priceId } = z.object({ priceId: z.string().min(1) }).parse(req.body);
      const user = await storage.getUser(userId);
      if (!user) return res.status(401).json({ error: "User not found" });

      const stripe = await getUncachableStripeClient();

      const price = await stripe.prices.retrieve(priceId, { expand: ["product"] });
      const product = price.product as any;
      const planMeta = product?.metadata?.plan;
      if (!planMeta || !["pro", "enterprise"].includes(planMeta)) {
        return res.status(400).json({ error: "Invalid plan selected" });
      }
      if (product?.metadata?.app !== "pivotlab") {
        return res.status(400).json({ error: "Invalid product" });
      }

      let customerId = user.stripeCustomerId;
      if (!customerId) {
        const customer = await stripe.customers.create({
          metadata: { userId: user.id, username: user.username },
        });
        await storage.updateUserStripeInfo(userId, { stripeCustomerId: customer.id });
        customerId = customer.id;
      }

      const session = await stripe.checkout.sessions.create({
        customer: customerId,
        payment_method_types: ["card"],
        line_items: [{ price: priceId, quantity: 1 }],
        mode: "subscription",
        success_url: `${req.protocol}://${req.get("host")}/billing?success=true`,
        cancel_url: `${req.protocol}://${req.get("host")}/billing?canceled=true`,
      });

      return res.json({ url: session.url });
    } catch (err: any) {
      return res.status(500).json({ error: err.message });
    }
  });

  app.post("/api/stripe/portal", async (req: Request, res: Response) => {
    const userId = requireAuth(req, res);
    if (!userId) return;

    try {
      const user = await storage.getUser(userId);
      if (!user?.stripeCustomerId) {
        return res.status(400).json({ error: "No billing account found. Subscribe to a plan first." });
      }

      const stripe = await getUncachableStripeClient();
      const session = await stripe.billingPortal.sessions.create({
        customer: user.stripeCustomerId,
        return_url: `${req.protocol}://${req.get("host")}/billing`,
      });

      return res.json({ url: session.url });
    } catch (err: any) {
      return res.status(500).json({ error: err.message });
    }
  });

  app.get("/api/stripe/subscription", async (req: Request, res: Response) => {
    const userId = requireAuth(req, res);
    if (!userId) return;

    try {
      const user = await storage.getUser(userId);
      if (!user?.stripeCustomerId) {
        return res.json({ subscription: null, plan: user?.plan || "free" });
      }

      const stripe = await getUncachableStripeClient();
      const subscriptions = await stripe.subscriptions.list({
        customer: user.stripeCustomerId,
        status: "active",
        limit: 1,
        expand: ["data.items.data.price.product"],
      });

      if (subscriptions.data.length > 0) {
        const sub = subscriptions.data[0];
        const item = sub.items.data[0];
        const price = item?.price;
        const product = price?.product as any;

        return res.json({
          subscription: {
            id: sub.id,
            status: sub.status,
            currentPeriodEnd: sub.current_period_end,
            cancelAtPeriodEnd: sub.cancel_at_period_end,
            productName: product?.name || null,
            unitAmount: price?.unit_amount || null,
            currency: price?.currency || null,
            interval: price?.recurring?.interval || null,
          },
          plan: user.plan,
        });
      }

      return res.json({ subscription: null, plan: user.plan });
    } catch (err: any) {
      return res.json({ subscription: null, plan: user?.plan || "free" });
    }
  });

  app.post("/api/stripe/sync-plan", async (req: Request, res: Response) => {
    const userId = requireAuth(req, res);
    if (!userId) return;

    try {
      const user = await storage.getUser(userId);
      if (!user?.stripeCustomerId) {
        return res.json({ plan: user?.plan || "free" });
      }

      const stripe = await getUncachableStripeClient();
      const subscriptions = await stripe.subscriptions.list({
        customer: user.stripeCustomerId,
        status: "active",
        limit: 1,
      });

      if (subscriptions.data.length > 0) {
        const sub = subscriptions.data[0];
        const subId = sub.id;
        const productId = (sub.items.data[0]?.price as any)?.product;
        
        let newPlan = "pro";
        if (productId) {
          const product = await stripe.products.retrieve(productId as string);
          const planMeta = product.metadata?.plan;
          if (planMeta === "enterprise") newPlan = "enterprise";
          else if (planMeta === "pro") newPlan = "pro";
        }

        await storage.updateUserStripeInfo(userId, { stripeSubscriptionId: subId });
        await storage.updateUserPlan(userId, newPlan);
        return res.json({ plan: newPlan, subscriptionId: subId });
      } else {
        await storage.updateUserStripeInfo(userId, { stripeSubscriptionId: undefined });
        await storage.updateUserPlan(userId, "free");
        return res.json({ plan: "free" });
      }
    } catch (err: any) {
      return res.status(500).json({ error: err.message });
    }
  });

  return httpServer;
}

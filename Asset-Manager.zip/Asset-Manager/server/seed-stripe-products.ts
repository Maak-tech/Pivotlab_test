import { getUncachableStripeClient } from "./stripeClient";

async function seedStripeProducts() {
  const stripe = await getUncachableStripeClient();

  const existing = await stripe.products.search({ query: "metadata['app']:'pivotlab'" });
  if (existing.data.length > 0) {
    console.log("Stripe products already exist, skipping seed.");
    for (const p of existing.data) {
      const prices = await stripe.prices.list({ product: p.id, active: true });
      console.log(`  ${p.name} (${p.id})`);
      for (const pr of prices.data) {
        console.log(`    Price: ${pr.id} - $${(pr.unit_amount! / 100).toFixed(2)}/${pr.recurring?.interval}`);
      }
    }
    return;
  }

  console.log("Creating Stripe products for PivotLab plans...");

  const proPlan = await stripe.products.create({
    name: "PivotLab Pro",
    description: "All integrations, real-time alerts, pivot mode, and AI normalization. Up to 10 workspaces and 5,000 signals.",
    metadata: { app: "pivotlab", plan: "pro" },
  });

  const proMonthly = await stripe.prices.create({
    product: proPlan.id,
    unit_amount: 4900,
    currency: "usd",
    recurring: { interval: "month" },
    metadata: { plan: "pro" },
  });

  const proYearly = await stripe.prices.create({
    product: proPlan.id,
    unit_amount: 47000,
    currency: "usd",
    recurring: { interval: "year" },
    metadata: { plan: "pro" },
  });

  console.log(`Created Pro Plan: ${proPlan.id}`);
  console.log(`  Monthly: ${proMonthly.id} ($49/mo)`);
  console.log(`  Yearly: ${proYearly.id} ($470/yr)`);

  const enterprisePlan = await stripe.products.create({
    name: "PivotLab Enterprise",
    description: "Unlimited workspaces, signals, integrations, and AI calls. Priority support and custom SLAs.",
    metadata: { app: "pivotlab", plan: "enterprise" },
  });

  const enterpriseMonthly = await stripe.prices.create({
    product: enterprisePlan.id,
    unit_amount: 19900,
    currency: "usd",
    recurring: { interval: "month" },
    metadata: { plan: "enterprise" },
  });

  const enterpriseYearly = await stripe.prices.create({
    product: enterprisePlan.id,
    unit_amount: 190000,
    currency: "usd",
    recurring: { interval: "year" },
    metadata: { plan: "enterprise" },
  });

  console.log(`Created Enterprise Plan: ${enterprisePlan.id}`);
  console.log(`  Monthly: ${enterpriseMonthly.id} ($199/mo)`);
  console.log(`  Yearly: ${enterpriseYearly.id} ($1,900/yr)`);

  console.log("\nDone! Products will be synced to the database via webhooks.");
}

seedStripeProducts().catch(console.error);

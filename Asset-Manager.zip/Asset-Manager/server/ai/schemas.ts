import { z } from "zod";

export const ThemeSchema = z.object({
  topic: z.string().min(1).max(60),
  subtopics: z.array(z.string().min(1).max(40)).max(6).default([]),
  sentiment: z.enum(["negative", "neutral", "positive"]),
  userPain: z.string().min(1).max(200),
  kpiHints: z.array(z.string().min(1).max(60)).max(5).default([]),
  urgency: z.enum(["low", "medium", "high"]),
});

export type Theme = z.infer<typeof ThemeSchema>;

export const RoadmapItemSchema = z.object({
  title: z.string().min(1).max(80),
  why: z.string().min(1).max(220),
  expectedImpact: z.enum(["low", "medium", "high"]),
  effortBand: z.enum(["xs", "s", "m", "l"]),
  confidence: z.number().min(0.3).max(0.95),
  kpi: z.string().min(1).max(50),
});

export const RoadmapSchema = z.object({
  summary: z.string().min(1).max(260),
  items: z.array(RoadmapItemSchema).min(1).max(8),
});

export type Roadmap = z.infer<typeof RoadmapSchema>;
export type RoadmapItem = z.infer<typeof RoadmapItemSchema>;

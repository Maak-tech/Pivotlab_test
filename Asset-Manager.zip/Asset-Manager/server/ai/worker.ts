import { storage } from "../storage";
import { normalizeSignal } from "./normalizeSignal";

function sleep(ms: number) {
  return new Promise((r) => setTimeout(r, ms));
}

const MAX_ATTEMPTS = 3;
const STALE_RUNNING_MS = 5 * 60 * 1000;

export async function runAiQueue(limit = 50) {
  await storage.resetStaleAiJobs(STALE_RUNNING_MS);

  const jobs = await storage.getPendingAiJobs(limit);

  if (!jobs.length) return { picked: 0, done: 0, failed: 0, retried: 0 };

  let done = 0;
  let failed = 0;
  let retried = 0;

  const minIntervalMs = Number(process.env.AI_MIN_INTERVAL_MS || 600);

  for (const job of jobs) {
    await storage.markAiJobsRunning([job.id]);
    const started = Date.now();
    try {
      if (job.type === "normalize_signal") {
        const signalId = (job.payload as any).signalId as string;
        await normalizeSignal(signalId);
      }

      await storage.completeAiJob(job.id);
      done++;
    } catch (e: any) {
      const nextAttempts = (job.attempts ?? 0) + 1;
      if (nextAttempts < MAX_ATTEMPTS) {
        await storage.retryAiJob(job.id, nextAttempts, String(e?.message ?? e));
        retried++;
      } else {
        await storage.failAiJob(job.id, String(e?.message ?? e));
        failed++;
      }
    } finally {
      const elapsed = Date.now() - started;
      const wait = Math.max(0, minIntervalMs - elapsed);
      if (wait) await sleep(wait);
    }
  }

  return { picked: jobs.length, done, failed, retried };
}

import { streamText, modelFast } from "./client";

export function explainOpportunity(args: {
  title: string;
  problemStatement: string;
  evidenceSnippets: string[];
  constraints?: { kpi?: string | null; budget?: number | null; deadline?: string | null };
}) {
  const ev = args.evidenceSnippets.slice(0, 6).map((s, i) => `E${i + 1}: ${s}`).join("\n");

  const result = streamText({
    model: modelFast,
    system:
      "You are a senior product manager. Be concise, evidence-based, and practical. No fluff.",
    prompt: [
      `Opportunity: ${args.title}`,
      `Problem: ${args.problemStatement}`,
      `Constraints: KPI=${args.constraints?.kpi ?? "n/a"}, budget=${args.constraints?.budget ?? "n/a"}, deadline=${args.constraints?.deadline ?? "n/a"}`,
      "Evidence snippets:",
      ev || "(none)",
      "",
      "Write:",
      "1) What's happening (1-2 sentences)",
      "2) Why now (1 sentence)",
      "3) Recommended bet (1-2 bullets)",
      "4) Risks/unknowns (1-2 bullets)",
      "5) Next validation step (1 bullet)",
    ].join("\n"),
  });

  return result;
}

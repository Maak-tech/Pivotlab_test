import { generateObject, modelFast } from "./client";
import { ThemeSchema, type Theme } from "./schemas";

export async function extractThemeAI(input: {
  text: string;
  source?: string;
}): Promise<Theme> {
  const cleaned = input.text.trim().slice(0, 4000);

  const result = await generateObject({
    model: modelFast,
    schema: ThemeSchema,
    prompt: [
      "You are a product analyst. Extract a theme from customer or product feedback.",
      "Return a concise topic used for clustering opportunities.",
      "Prefer consistent, reusable topics: onboarding, login, checkout, billing, performance, reliability, notifications, search, integrations, permissions, mobile, pricing, UX.",
      `Source: ${input.source ?? "unknown"}`,
      "Text:",
      cleaned,
    ].join("\n"),
  });

  return result.object;
}

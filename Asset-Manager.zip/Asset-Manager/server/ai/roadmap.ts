import { generateObject, modelBetter } from "./client";
import { RoadmapSchema, type Roadmap } from "./schemas";

export async function generateRoadmap(input: {
  goalKpi: string;
  budget?: number | null;
  timelineWeeks?: number | null;
  opportunities: Array<{ title: string; score: number; problemStatement: string }>;
}): Promise<Roadmap> {
  const opps = input.opportunities.slice(0, 8).map((o) => ({
    title: o.title,
    score: o.score,
    problem: o.problemStatement.slice(0, 240),
  }));

  const result = await generateObject({
    model: modelBetter,
    schema: RoadmapSchema,
    prompt: [
      "You are a product lead. Build a short roadmap based on ranked opportunities.",
      "Use the provided goal KPI, budget, and timeline constraints.",
      "Prefer high-impact, low-effort items first. Keep titles crisp.",
      `Goal KPI: ${input.goalKpi}`,
      `Budget: ${input.budget ?? "n/a"}`,
      `Timeline weeks: ${input.timelineWeeks ?? "n/a"}`,
      "Opportunities (ranked):",
      JSON.stringify(opps, null, 2),
    ].join("\n"),
  });

  return result.object;
}

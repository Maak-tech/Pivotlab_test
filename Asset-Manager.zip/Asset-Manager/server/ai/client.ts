import { openai } from "@ai-sdk/openai";
import { generateObject, streamText } from "ai";

export const modelFast = openai("gpt-4.1-mini");
export const modelBetter = openai("gpt-4.1");

export { generateObject, streamText };

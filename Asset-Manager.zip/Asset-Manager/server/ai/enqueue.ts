import { storage } from "../storage";

export async function enqueueNormalizeSignal(signalIds: string[]) {
  if (!signalIds.length) return { enqueued: 0 };

  const jobs = signalIds.map((id) => ({
    type: "normalize_signal",
    uniqueKey: `normalize_signal:${id}`,
    payload: { signalId: id },
  }));

  const enqueued = await storage.enqueueAiJobs(jobs);
  return { enqueued };
}

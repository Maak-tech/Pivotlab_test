import { db } from "../db";
import { eq } from "drizzle-orm";
import { signals } from "@shared/schema";
import { storage } from "../storage";
import { extractThemeAI } from "./theme";
import { sha256 } from "./hash";

function buildTextForAI(title: string, body: string | null) {
  const text = `${title}\n\n${body || ""}`.trim();
  return text.slice(0, 2500);
}

export async function normalizeSignal(signalId: string) {
  const [s] = await db.select().from(signals).where(eq(signals.id, signalId));
  if (!s) return { ok: false, reason: "signal_not_found" };

  if (s.normTopic && s.normCacheKey) return { ok: true, skipped: true };

  const text = buildTextForAI(s.title, s.body);
  const cacheKey = sha256(JSON.stringify({ v: 1, source: s.source, text }));

  const cached = await storage.getNormCache(cacheKey);
  if (cached) {
    const result = cached.result as any;
    await storage.updateSignalNorm(s.id, {
      normTopic: String(result.topic || "").slice(0, 60) || s.topic || "general",
      normTags: result,
      normCacheKey: cacheKey,
    });
    return { ok: true, cached: true };
  }

  const theme = await extractThemeAI({ text, source: s.source });

  await storage.setNormCache(cacheKey, theme);

  await storage.updateSignalNorm(s.id, {
    normTopic: theme.topic,
    normTags: theme as any,
    normCacheKey: cacheKey,
  });

  return { ok: true, cached: false };
}

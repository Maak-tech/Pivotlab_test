import { storage } from "./storage";
import { postPivotAlertToSlack } from "./slack";

interface TrendData {
  topic: string;
  currentCount: number;
  previousCount: number;
  currentSeverityAvg: number;
  previousSeverityAvg: number;
  changePercent: number;
  direction: "up" | "down" | "flat";
}

export async function computeInitiativeTrends(initiativeId: string): Promise<{
  trends: TrendData[];
  overallDirection: "improving" | "worsening" | "stable";
}> {
  const initiative = await storage.getInitiative(initiativeId);
  if (!initiative) throw new Error("Initiative not found");

  const topics = initiative.topics.map((t) => t.topic);
  if (topics.length === 0) return { trends: [], overallDirection: "stable" };

  const now = new Date();
  const oneWeekAgo = new Date(now.getTime() - 7 * 24 * 60 * 60 * 1000);
  const twoWeeksAgo = new Date(now.getTime() - 14 * 24 * 60 * 60 * 1000);

  const currentSignals = await storage.getSignalsByTopicsInRange(
    initiative.workspaceId, topics, oneWeekAgo, now
  );
  const previousSignals = await storage.getSignalsByTopicsInRange(
    initiative.workspaceId, topics, twoWeeksAgo, oneWeekAgo
  );

  const trends: TrendData[] = topics.map((topic) => {
    const current = currentSignals.filter((s) =>
      s.topic?.toLowerCase().includes(topic.toLowerCase())
    );
    const previous = previousSignals.filter((s) =>
      s.topic?.toLowerCase().includes(topic.toLowerCase())
    );

    const currentCount = current.length;
    const previousCount = previous.length;
    const currentSeverityAvg = currentCount > 0
      ? current.reduce((sum, s) => sum + s.severity, 0) / currentCount
      : 0;
    const previousSeverityAvg = previousCount > 0
      ? previous.reduce((sum, s) => sum + s.severity, 0) / previousCount
      : 0;

    const changePercent = previousCount > 0
      ? ((currentCount - previousCount) / previousCount) * 100
      : currentCount > 0 ? 100 : 0;

    const direction: "up" | "down" | "flat" =
      changePercent > 10 ? "up" : changePercent < -10 ? "down" : "flat";

    return {
      topic,
      currentCount,
      previousCount,
      currentSeverityAvg: Math.round(currentSeverityAvg * 10) / 10,
      previousSeverityAvg: Math.round(previousSeverityAvg * 10) / 10,
      changePercent: Math.round(changePercent),
      direction,
    };
  });

  const worseningCount = trends.filter((t) => t.direction === "up").length;
  const improvingCount = trends.filter((t) => t.direction === "down").length;

  const overallDirection: "improving" | "worsening" | "stable" =
    worseningCount > improvingCount ? "worsening" :
    improvingCount > worseningCount ? "improving" : "stable";

  return { trends, overallDirection };
}

export async function checkPivotRecommendations() {
  const activeInitiatives = await storage.getActiveInitiatives();

  for (const initiative of activeInitiatives) {
    if (initiative.topics.length === 0) continue;

    const daysSinceStart = Math.floor(
      (Date.now() - initiative.startDate.getTime()) / (1000 * 60 * 60 * 24)
    );

    if (daysSinceStart < 7) continue;

    try {
      const { trends, overallDirection } = await computeInitiativeTrends(initiative.id);

      if (overallDirection === "worsening" && daysSinceStart >= 14) {
        const worseningTopics = trends
          .filter((t) => t.direction === "up")
          .map((t) => `${t.topic} (+${t.changePercent}%)`);

        const severityIncrease = trends.some(
          (t) => t.currentSeverityAvg > t.previousSeverityAvg + 0.5
        );

        let type = "cut_scope";
        let confidence = 0.6;
        let reason = "";

        if (worseningTopics.length >= 2 && severityIncrease) {
          type = "solution_pivot";
          confidence = 0.75;
          reason = `Signal volume increasing across ${worseningTopics.length} topics (${worseningTopics.join(", ")}) with rising severity. Consider a fundamental approach change.`;
        } else if (worseningTopics.length >= 1) {
          type = "cut_scope";
          confidence = 0.6;
          reason = `Complaints rising in: ${worseningTopics.join(", ")}. Consider narrowing scope to address core issues first.`;
        }

        const killCriteria = initiative.killCriteria as any;
        if (killCriteria?.dropIfNoImprovementDays && daysSinceStart >= killCriteria.dropIfNoImprovementDays) {
          type = "stop";
          confidence = 0.8;
          reason = `No improvement after ${daysSinceStart} days (kill criteria: ${killCriteria.dropIfNoImprovementDays} days). ${reason}`;
        }

        if (reason) {
          await storage.createPivotRecommendation({
            initiativeId: initiative.id,
            type,
            reason,
            confidence,
          });
          console.log(`[pivot-analysis] recommendation created for initiative ${initiative.id}: ${type}`);

          try {
            await postPivotAlertToSlack(
              initiative.workspaceId,
              initiative.name,
              type,
              reason,
              confidence,
            );
          } catch (slackErr: any) {
            console.error(`[pivot-analysis] slack alert failed: ${slackErr.message}`);
          }
        }
      }
    } catch (err: any) {
      console.error(`[pivot-analysis] failed for initiative ${initiative.id}:`, err.message);
    }
  }
}

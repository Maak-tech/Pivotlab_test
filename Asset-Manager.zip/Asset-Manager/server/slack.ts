import { storage } from "./storage";
import { db } from "./db";
import { eq, desc } from "drizzle-orm";
import { opportunities, evidence, pivotRecommendations, initiatives, initiativeTopics } from "@shared/schema";

function fmtPct(x?: number | null): string {
  if (x === null || x === undefined) return "n/a";
  return `${(x * 100).toFixed(0)}%`;
}

export async function postToSlack(webhookUrl: string, text: string, channel?: string): Promise<void> {
  const payload: Record<string, string> = { text };
  if (channel) payload.channel = channel;
  const res = await fetch(webhookUrl, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(payload),
  });
  if (!res.ok) {
    const body = await res.text();
    throw new Error(`Slack post failed: ${res.status} ${body.slice(0, 200)}`);
  }
}

export async function buildWeeklyDigest(workspaceId: string): Promise<string> {
  const workspace = await storage.getWorkspace(workspaceId);
  const wsName = workspace?.name || workspaceId;

  const topOpps = await db.select().from(opportunities)
    .where(eq(opportunities.workspaceId, workspaceId))
    .orderBy(desc(opportunities.score))
    .limit(5);

  const allRecs = await db.select({
    rec: pivotRecommendations,
    initName: initiatives.name,
  })
    .from(pivotRecommendations)
    .innerJoin(initiatives, eq(pivotRecommendations.initiativeId, initiatives.id))
    .where(eq(initiatives.workspaceId, workspaceId))
    .orderBy(desc(pivotRecommendations.createdAt))
    .limit(3);

  const lines: string[] = [];
  lines.push(`*PivotLab AI -- Weekly Digest*`);
  lines.push(`Workspace: *${wsName}*`);
  lines.push(``);

  lines.push(`*Top Opportunities (what to build next)*`);
  if (topOpps.length === 0) {
    lines.push(`  No open opportunities yet.`);
  } else {
    for (const o of topOpps) {
      const evRows = await db.select().from(evidence)
        .where(eq(evidence.opportunityId, o.id))
        .limit(1);
      const snippet = evRows[0]?.snippet ? ` -- _"${evRows[0].snippet.slice(0, 100)}..."_` : "";
      const aiLine = o.aiSummary ? `\n    _AI: ${o.aiSummary.slice(0, 120)}_` : "";
      lines.push(`  *${o.title}* (score ${o.score.toFixed(1)}, conf ${(o.confidence * 100).toFixed(0)}%)${snippet}${aiLine}`);
    }
  }

  lines.push(``);
  lines.push(`*Pivot Watch (in-flight initiatives)*`);
  if (allRecs.length === 0) {
    lines.push(`  No pivot recommendations yet.`);
  } else {
    for (const { rec, initName } of allRecs) {
      const topics = await db.select().from(initiativeTopics)
        .where(eq(initiativeTopics.initiativeId, rec.initiativeId));
      const topicStr = topics.map(t => t.topic).slice(0, 6).join(", ");
      lines.push(
        `  *${initName}* -> *${rec.type}* (conf ${(rec.confidence * 100).toFixed(0)}%) -- topics: _${topicStr}_`
      );
    }
  }

  return lines.join("\n");
}

export async function postWeeklyDigestToSlack(workspaceId: string): Promise<{ posted: boolean; reason?: string }> {
  const slack = await storage.getSlackIntegration(workspaceId);
  if (!slack || !slack.enabled) return { posted: false, reason: "slack not connected" };

  const text = await buildWeeklyDigest(workspaceId);
  await postToSlack(slack.webhookUrl, text);
  return { posted: true };
}

export async function postPivotAlertToSlack(
  workspaceId: string,
  initiativeName: string,
  recType: string,
  reason: string,
  confidence: number,
): Promise<void> {
  const slack = await storage.getSlackIntegration(workspaceId);
  if (!slack || !slack.enabled) return;

  const text = [
    `*PivotLab AI -- Pivot Alert*`,
    `Initiative: *${initiativeName}*`,
    `Recommendation: *${recType}* (confidence ${(confidence * 100).toFixed(0)}%)`,
    `Reason: ${reason}`,
  ].join("\n");

  try {
    await postToSlack(slack.webhookUrl, text);
  } catch (err: any) {
    console.error(`[slack] pivot alert failed for workspace ${workspaceId}: ${err.message}`);
  }
}

import { db } from "../db";
import { eq } from "drizzle-orm";
import { jiraIntegrations, zendeskIntegrations, ga4Integrations } from "@shared/schema";
import { syncJira } from "../integrations/jira";
import { syncZendesk } from "../integrations/zendesk";
import { syncGa4 } from "../integrations/ga4";
import { recomputeOpportunities } from "../recompute";
import { checkPivotRecommendations } from "../pivot-analysis";
import { processAllPendingOutcomeChecks } from "../outcome-checker";

async function run() {
  console.log(`[dailySync] start ${new Date().toISOString()}`);
  let hasErrors = false;

  const jira = await db
    .select({ workspaceId: jiraIntegrations.workspaceId })
    .from(jiraIntegrations)
    .where(eq(jiraIntegrations.enabled, true));

  const zendesk = await db
    .select({ workspaceId: zendeskIntegrations.workspaceId })
    .from(zendeskIntegrations)
    .where(eq(zendeskIntegrations.enabled, true));

  const ga4 = await db
    .select({ workspaceId: ga4Integrations.workspaceId })
    .from(ga4Integrations)
    .where(eq(ga4Integrations.enabled, true));

  const ids = Array.from(new Set<string>([
    ...jira.map((x) => x.workspaceId),
    ...zendesk.map((x) => x.workspaceId),
    ...ga4.map((x) => x.workspaceId),
  ]));

  for (const workspaceId of ids) {
    console.log(`[dailySync] workspace=${workspaceId}`);

    try {
      if (jira.some((x) => x.workspaceId === workspaceId)) {
        const result = await syncJira(workspaceId);
        console.log(`[dailySync]   jira: fetched=${result.fetched} inserted=${result.inserted}`);
      }
    } catch (e: any) {
      console.error(`[dailySync]   jira failed: ${e.message}`);
      hasErrors = true;
    }

    try {
      if (zendesk.some((x) => x.workspaceId === workspaceId)) {
        const result = await syncZendesk(workspaceId);
        console.log(`[dailySync]   zendesk: fetched=${result.fetched} inserted=${result.inserted}`);
      }
    } catch (e: any) {
      console.error(`[dailySync]   zendesk failed: ${e.message}`);
      hasErrors = true;
    }

    try {
      if (ga4.some((x) => x.workspaceId === workspaceId)) {
        const result = await syncGa4(workspaceId);
        console.log(`[dailySync]   ga4: signals=${result.fetchedSignals} inserted=${result.inserted}`);
      }
    } catch (e: any) {
      console.error(`[dailySync]   ga4 failed: ${e.message}`);
      hasErrors = true;
    }

    try {
      await recomputeOpportunities(workspaceId);
      console.log(`[dailySync]   recomputed opportunities`);
    } catch (e: any) {
      console.error(`[dailySync]   recompute failed: ${e.message}`);
      hasErrors = true;
    }
  }

  try {
    await checkPivotRecommendations();
    console.log("[dailySync] pivot analysis complete");
  } catch (e: any) {
    console.error(`[dailySync] pivot analysis failed: ${e.message}`);
    hasErrors = true;
  }

  try {
    const processed = await processAllPendingOutcomeChecks();
    console.log(`[dailySync] outcome checks processed: ${processed}`);
  } catch (e: any) {
    console.error(`[dailySync] outcome checks failed: ${e.message}`);
    hasErrors = true;
  }

  console.log(`[dailySync] done (errors=${hasErrors})`);
  process.exit(hasErrors ? 1 : 0);
}

run().catch((e) => {
  console.error("[dailySync] fatal:", e);
  process.exit(1);
});

import "dotenv/config";
import { runAiQueue } from "../ai/worker";

async function main() {
  const limit = Number(process.env.AI_QUEUE_LIMIT || 60);
  console.log(`[aiNormalize] Starting queue run (limit=${limit})...`);
  const res = await runAiQueue(limit);
  console.log("[aiNormalize]", res);
  process.exit(0);
}

main().catch((e) => {
  console.error("[aiNormalize] Fatal error:", e);
  process.exit(1);
});

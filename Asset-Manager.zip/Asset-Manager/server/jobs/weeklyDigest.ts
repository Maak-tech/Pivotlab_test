import { db } from "../db";
import { eq } from "drizzle-orm";
import { slackIntegrations } from "@shared/schema";
import { postWeeklyDigestToSlack } from "../slack";

async function run() {
  console.log(`[weeklyDigest] start ${new Date().toISOString()}`);
  let hasErrors = false;

  const integs = await db.select().from(slackIntegrations)
    .where(eq(slackIntegrations.enabled, true));

  if (integs.length === 0) {
    console.log("[weeklyDigest] no enabled Slack integrations, exiting");
    process.exit(0);
  }

  for (const integ of integs) {
    try {
      const result = await postWeeklyDigestToSlack(integ.workspaceId);
      console.log(`[weeklyDigest] workspace=${integ.workspaceId} posted=${result.posted}`);
    } catch (e: any) {
      console.error(`[weeklyDigest] failed workspace=${integ.workspaceId}: ${e.message}`);
      hasErrors = true;
    }
  }

  console.log(`[weeklyDigest] done (errors=${hasErrors})`);
  process.exit(hasErrors ? 1 : 0);
}

run().catch((e) => {
  console.error("[weeklyDigest] fatal:", e);
  process.exit(1);
});

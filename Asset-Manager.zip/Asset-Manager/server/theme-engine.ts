const THEME_KEYWORDS: Record<string, string[]> = {
  billing: ["billing", "invoice", "charge", "payment", "refund", "subscription", "pricing", "plan", "upgrade", "downgrade", "receipt", "credit card"],
  login: ["login", "log in", "sign in", "signin", "authentication", "password", "reset password", "forgot password", "2fa", "mfa", "sso", "oauth", "session"],
  crash: ["crash", "crashes", "crashing", "freeze", "frozen", "hung", "unresponsive", "not responding", "force close", "fatal", "segfault", "panic"],
  performance: ["slow", "loading", "latency", "timeout", "lag", "sluggish", "hang", "speed", "performance", "takes forever", "long time", "takes too long", "delay"],
  onboarding: ["onboarding", "getting started", "setup", "first time", "new user", "welcome", "tutorial", "walkthrough", "invite", "invitation"],
  export: ["export", "download", "csv", "pdf", "report", "spreadsheet", "xlsx"],
  notifications: ["notification", "alert", "email notification", "push notification", "digest", "reminder", "subscribe", "unsubscribe"],
  permissions: ["permission", "access", "role", "admin", "unauthorized", "forbidden", "denied", "privilege"],
  api: ["api", "endpoint", "rate limit", "webhook", "integration", "sdk", "rest", "graphql"],
  data_loss: ["data loss", "lost data", "missing data", "deleted", "disappeared", "gone", "wiped", "erased", "corrupted"],
  ui: ["ui", "ux", "design", "layout", "display", "rendering", "font", "color", "theme", "dark mode", "responsive", "mobile view"],
  search: ["search", "filter", "sort", "find", "query", "results"],
  sync: ["sync", "synchronize", "out of sync", "not syncing", "stale", "outdated", "refresh"],
  security: ["security", "vulnerability", "breach", "exploit", "injection", "xss", "csrf"],
};

export function extractTheme(text: string): string | null {
  if (!text) return null;
  const lower = text.toLowerCase();

  let bestTheme: string | null = null;
  let bestScore = 0;

  for (const [theme, keywords] of Object.entries(THEME_KEYWORDS)) {
    let score = 0;
    for (const kw of keywords) {
      if (lower.includes(kw)) {
        score += kw.length;
      }
    }
    if (score > bestScore) {
      bestScore = score;
      bestTheme = theme;
    }
  }

  return bestTheme;
}

export function extractTopicForZendesk(ticket: {
  subject?: string;
  description?: string;
  tags?: string[];
}): string {
  const subjectTheme = extractTheme(ticket.subject || "");
  if (subjectTheme) return subjectTheme;

  const descTheme = extractTheme((ticket.description || "").slice(0, 500));
  if (descTheme) return descTheme;

  if (ticket.tags && ticket.tags.length > 0) {
    return ticket.tags[0];
  }

  return "support";
}

export function extractTopicForJira(issue: {
  summary?: string;
  description?: string;
  component?: string;
  label?: string;
  issueType?: string;
}): string {
  if (issue.component) return issue.component;
  if (issue.label) return issue.label;

  const summaryTheme = extractTheme(issue.summary || "");
  if (summaryTheme) return summaryTheme;

  const descTheme = extractTheme((issue.description || "").slice(0, 500));
  if (descTheme) return descTheme;

  return issue.issueType || "issue";
}

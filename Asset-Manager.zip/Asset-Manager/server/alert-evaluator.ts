import { storage } from "./storage";
import { postToSlack } from "./slack";
import type { AlertRule, Opportunity } from "@shared/schema";

type ConditionType = "ga4_drop_and_voc_rising" | "score_above" | "trend_rising" | "multi_source";

interface AlertCondition {
  type: ConditionType;
  params?: Record<string, any>;
}

function topicMatches(topicPattern: string | null, oppTitle: string): boolean {
  if (!topicPattern) return true;
  const patterns = topicPattern.split(",").map(p => p.trim().toLowerCase());
  const titleLower = oppTitle.toLowerCase();
  return patterns.some(p => {
    if (p.endsWith("/*")) {
      return titleLower.startsWith(p.slice(0, -2));
    }
    return titleLower.includes(p);
  });
}

function evaluateCondition(condition: AlertCondition, opp: Opportunity & { evidence?: any[] }): boolean {
  switch (condition.type) {
    case "score_above": {
      const threshold = condition.params?.threshold ?? 10;
      return opp.score >= threshold;
    }
    case "trend_rising": {
      return opp.trendDirection === "rising" && (opp.trendPercent ?? 0) > (condition.params?.minPercent ?? 10);
    }
    case "ga4_drop_and_voc_rising": {
      const breakdown = opp.sourceBreakdown as { source: string; count: number }[] | null;
      if (!breakdown) return false;
      const ga4Entry = breakdown.find(s => s.source === "ga4");
      const vocSources = ["reviews", "support", "zendesk", "app_reviews", "intercom"];
      const vocCount = breakdown.filter(s => vocSources.includes(s.source)).reduce((sum, s) => sum + s.count, 0);
      const hasGa4Drop = !!ga4Entry && ga4Entry.count > 0;
      const hasVocRising = vocCount >= 2 && opp.trendDirection === "rising";
      return hasGa4Drop && hasVocRising;
    }
    case "multi_source": {
      const breakdown = opp.sourceBreakdown as { source: string; count: number }[] | null;
      if (!breakdown) return false;
      const minSources = condition.params?.minSources ?? 2;
      return breakdown.length >= minSources;
    }
    default:
      return false;
  }
}

function buildAlertMessage(rule: AlertRule, opp: Opportunity): string {
  const breakdown = opp.sourceBreakdown as { source: string; count: number }[] | null;
  const sourceText = breakdown?.map(s => `${s.source}(${s.count})`).join(", ") || "unknown";
  const trendText = opp.trendDirection === "rising" ? `+${opp.trendPercent ?? 0}%` :
    opp.trendDirection === "falling" ? `${opp.trendPercent ?? 0}%` : "stable";

  return [
    `*Alert: ${rule.name}*`,
    `Topic: *${opp.title}*`,
    `Score: ${opp.score.toFixed(1)} | Trend: ${trendText} | Signals: ${opp.signalCount ?? 0}`,
    `Sources: ${sourceText}`,
    opp.problemStatement ? `> ${opp.problemStatement.slice(0, 200)}` : "",
  ].filter(Boolean).join("\n");
}

export async function evaluateAlerts(): Promise<{ checked: number; fired: number }> {
  const rules = await storage.getAllEnabledAlertRules();
  if (!rules.length) return { checked: 0, fired: 0 };

  let fired = 0;
  const checked = rules.length;

  const workspaceIds = Array.from(new Set(rules.map(r => r.workspaceId)));

  for (const wsId of workspaceIds) {
    const opps = await storage.getOpportunities(wsId);
    const wsRules = rules.filter(r => r.workspaceId === wsId);

    for (const rule of wsRules) {
      const conditions = (Array.isArray(rule.conditions) ? rule.conditions : [rule.conditions]) as AlertCondition[];

      for (const opp of opps) {
        if (!topicMatches(rule.topicPattern, opp.title)) continue;

        if (rule.scoreThreshold && opp.score < rule.scoreThreshold) continue;

        const allMatch = conditions.every(c => evaluateCondition(c, opp));
        if (!allMatch) continue;

        const lastAlert = await storage.getLastAlertForTopic(rule.id, opp.title);
        if (lastAlert) {
          const cooldownMs = (rule.cooldownHours ?? 24) * 60 * 60 * 1000;
          if (Date.now() - lastAlert.sentAt.getTime() < cooldownMs) continue;
        }

        const message = buildAlertMessage(rule, opp);

        const slackInteg = await storage.getSlackIntegration(wsId);
        if (slackInteg?.enabled && slackInteg.webhookUrl) {
          try {
            const channelOverride = rule.slackChannel || undefined;
            await postToSlack(slackInteg.webhookUrl, message, channelOverride);
          } catch (err: any) {
            console.error(`[alert-evaluator] Slack post failed for rule ${rule.id}: ${err.message}`);
          }
        }

        await storage.createAlertLog({
          workspaceId: wsId,
          ruleId: rule.id,
          topic: opp.title,
          message,
          slackChannel: rule.slackChannel ?? undefined,
        });

        fired++;
      }
    }
  }

  return { checked, fired };
}

export const TOPIC_CHANNEL_ROUTING: Record<string, string> = {
  "billing": "#billing",
  "payment": "#billing",
  "checkout": "#growth",
  "onboarding": "#growth",
  "activation": "#growth",
  "crash": "#platform",
  "reliability": "#platform",
  "performance": "#platform",
  "login": "#platform",
  "security": "#platform",
};

export function routeTopicToChannel(topic: string): string | undefined {
  const lower = topic.toLowerCase();
  for (const [key, channel] of Object.entries(TOPIC_CHANNEL_ROUTING)) {
    if (lower.includes(key)) return channel;
  }
  return undefined;
}

import { storage } from "../storage";
import type { InsertSignal } from "@shared/schema";
import { extractTopicForJira } from "../theme-engine";
import { enqueueNormalizeSignal } from "../ai/enqueue";

function normalizeBaseUrl(url: string) {
  return url.replace(/\/+$/, "");
}

function toBasicAuth(email: string, apiToken: string) {
  const b64 = Buffer.from(`${email}:${apiToken}`).toString("base64");
  return `Basic ${b64}`;
}

function adfToText(node: any): string {
  if (!node) return "";
  if (typeof node === "string") return node;
  if (node.type === "text" && typeof node.text === "string") return node.text;
  if (Array.isArray(node.content)) {
    return node.content.map(adfToText).join(" ").replace(/\s+/g, " ").trim();
  }
  return "";
}

function mapPriorityToSeverity(priorityName?: string): number {
  const p = (priorityName || "").toLowerCase();
  if (!p) return 3;
  if (p.includes("highest") || p.includes("critical") || p.includes("blocker")) return 5;
  if (p.includes("high")) return 4;
  if (p.includes("medium")) return 3;
  if (p.includes("low")) return 2;
  if (p.includes("lowest") || p.includes("trivial")) return 1;
  return 3;
}

export async function connectJira(params: {
  workspaceId: string;
  baseUrl: string;
  email: string;
  apiToken: string;
  jql?: string;
}) {
  const baseUrl = normalizeBaseUrl(params.baseUrl);
  const jql =
    params.jql?.trim() ||
    `issuetype = Bug AND updated >= -30d ORDER BY updated DESC`;

  const saved = await storage.upsertJiraIntegration({
    workspaceId: params.workspaceId,
    baseUrl,
    email: params.email,
    apiToken: params.apiToken,
    jql,
  });

  return saved;
}

export async function syncJira(workspaceId: string) {
  const integ = await storage.getJiraIntegration(workspaceId);
  if (!integ || !integ.enabled) {
    throw new Error("Jira integration not connected or disabled.");
  }

  const url = `${integ.baseUrl}/rest/api/3/search/jql`;

  const res = await fetch(url, {
    method: "POST",
    headers: {
      "Authorization": toBasicAuth(integ.email, integ.apiToken),
      "Accept": "application/json",
      "Content-Type": "application/json",
    },
    body: JSON.stringify({
      jql: integ.jql,
      maxResults: 100,
      fields: [
        "summary",
        "description",
        "status",
        "priority",
        "issuetype",
        "components",
        "labels",
        "created",
        "updated",
      ],
    }),
  });

  if (!res.ok) {
    const text = await res.text();
    throw new Error(`Jira sync failed: ${res.status} ${res.statusText} - ${text.slice(0, 300)}`);
  }

  const data = await res.json();
  const issues: any[] = data.issues || [];

  const signalData: InsertSignal[] = issues.map((issue) => {
    const key = issue.key as string;
    const fields = issue.fields || {};

    const summary = fields.summary || key;
    const status = fields.status?.name || "Unknown";
    const priorityName = fields.priority?.name || "";
    const severity = mapPriorityToSeverity(priorityName);

    const issueType = fields.issuetype?.name || "Issue";
    const component = fields.components?.[0]?.name;
    const label = fields.labels?.[0];
    const descriptionText = adfToText(fields.description);
    const topic = extractTopicForJira({
      summary,
      description: descriptionText,
      component,
      label,
      issueType,
    });
    const body = [
      `Status: ${status}`,
      `Priority: ${priorityName || "n/a"}`,
      descriptionText ? `Desc: ${descriptionText}` : "",
    ]
      .filter(Boolean)
      .join("\n")
      .slice(0, 2000);

    return {
      workspaceId,
      source: "jira",
      kind: "delivery",
      title: `[${key}] ${summary}`.slice(0, 250),
      topic: String(topic).slice(0, 120),
      body,
      severity,
      externalUrl: `${integ.baseUrl}/browse/${key}`,
      externalId: `jira:${key}`,
    };
  });

  const insertedCount = await storage.createSignalsSkipDuplicates(signalData);

  if (insertedCount > 0 && process.env.OPENAI_API_KEY) {
    try {
      const externalIds = signalData.map(s => s.externalId).filter(Boolean) as string[];
      const unnormalized = await storage.getUnnormalizedSignals(workspaceId, externalIds);
      if (unnormalized.length > 0) {
        await enqueueNormalizeSignal(unnormalized.map(s => s.id));
      }
    } catch (err: any) {
      console.error(`[jira-sync] Failed to enqueue AI normalization: ${err.message}`);
    }
  }

  await storage.updateJiraLastSynced(workspaceId);

  return {
    fetched: issues.length,
    inserted: insertedCount,
    jql: integ.jql,
  };
}

export async function createJiraIssue(workspaceId: string, params: {
  summary: string;
  description: string;
  issueType?: string;
  projectKey?: string;
}): Promise<{ key: string; url: string }> {
  const integ = await storage.getJiraIntegration(workspaceId);
  if (!integ || !integ.enabled) {
    throw new Error("Jira integration not connected or disabled.");
  }

  let projectKey = params.projectKey;
  if (!projectKey) {
    const projectsRes = await fetch(`${integ.baseUrl}/rest/api/3/project`, {
      headers: {
        "Authorization": toBasicAuth(integ.email, integ.apiToken),
        "Accept": "application/json",
      },
    });
    if (!projectsRes.ok) {
      throw new Error(`Failed to fetch Jira projects: ${projectsRes.status}`);
    }
    const projects = await projectsRes.json();
    if (!Array.isArray(projects) || projects.length === 0) {
      throw new Error("No Jira projects found");
    }
    projectKey = projects[0].key;
  }

  const issueType = params.issueType || "Story";
  const descriptionAdf = {
    type: "doc",
    version: 1,
    content: params.description.split("\n\n").map((para: string) => ({
      type: "paragraph",
      content: [{ type: "text", text: para }],
    })),
  };

  const res = await fetch(`${integ.baseUrl}/rest/api/3/issue`, {
    method: "POST",
    headers: {
      "Authorization": toBasicAuth(integ.email, integ.apiToken),
      "Accept": "application/json",
      "Content-Type": "application/json",
    },
    body: JSON.stringify({
      fields: {
        project: { key: projectKey },
        summary: params.summary.slice(0, 255),
        description: descriptionAdf,
        issuetype: { name: issueType },
      },
    }),
  });

  if (!res.ok) {
    const text = await res.text();
    throw new Error(`Jira issue creation failed: ${res.status} ${text.slice(0, 300)}`);
  }

  const data = await res.json();
  return {
    key: data.key,
    url: `${integ.baseUrl}/browse/${data.key}`,
  };
}

export async function getJiraDeliveryMetrics(workspaceId: string, daysSinceShip: number): Promise<{
  bugCount: number;
  reopenCount: number;
  totalResolved: number;
}> {
  const integ = await storage.getJiraIntegration(workspaceId);
  if (!integ || !integ.enabled) {
    return { bugCount: 0, reopenCount: 0, totalResolved: 0 };
  }

  const jql = `issuetype = Bug AND created >= -${daysSinceShip}d ORDER BY created DESC`;
  const res = await fetch(`${integ.baseUrl}/rest/api/3/search/jql`, {
    method: "POST",
    headers: {
      "Authorization": toBasicAuth(integ.email, integ.apiToken),
      "Accept": "application/json",
      "Content-Type": "application/json",
    },
    body: JSON.stringify({ jql, maxResults: 200, fields: ["status"] }),
  });

  if (!res.ok) {
    return { bugCount: 0, reopenCount: 0, totalResolved: 0 };
  }

  const data = await res.json();
  const issues: any[] = data.issues || [];
  let reopenCount = 0;
  let totalResolved = 0;

  for (const issue of issues) {
    const status = (issue.fields?.status?.name || "").toLowerCase();
    if (status === "done" || status === "resolved" || status === "closed") totalResolved++;
    if (status === "reopened" || status === "reopen") reopenCount++;
  }

  return { bugCount: issues.length, reopenCount, totalResolved };
}

export async function jiraStatus(workspaceId: string) {
  const integ = await storage.getJiraIntegration(workspaceId);
  if (!integ) return { connected: false as const };

  return {
    connected: true as const,
    enabled: integ.enabled,
    baseUrl: integ.baseUrl,
    jql: integ.jql,
    lastSyncedAt: integ.lastSyncedAt,
  };
}

import { db } from "../db";
import { eq } from "drizzle-orm";
import { zendeskIntegrations, signals } from "@shared/schema";
import { extractTopicForZendesk } from "../theme-engine";
import { enqueueNormalizeSignal } from "../ai/enqueue";

function normalizeBaseUrl(url: string) {
  return url.replace(/\/+$/, "");
}

function authHeader(email: string, apiToken: string) {
  const b64 = Buffer.from(`${email}/token:${apiToken}`).toString("base64");
  return `Basic ${b64}`;
}

function priorityToSeverity(priority?: string | null): number {
  const p = (priority || "").toLowerCase();
  if (p === "urgent") return 5;
  if (p === "high") return 4;
  if (p === "normal") return 3;
  if (p === "low") return 2;
  return 3;
}

async function fetchZendeskPaginated(
  startUrl: string,
  email: string,
  apiToken: string,
  itemsKey: string,
): Promise<any[]> {
  const items: any[] = [];
  let url: string | null = startUrl;
  for (let page = 0; page < 10 && url; page++) {
    try {
      const res: Response = await fetch(url, {
        headers: { Authorization: authHeader(email, apiToken), Accept: "application/json" },
      });
      if (!res.ok) break;
      const data: Record<string, any> = await res.json();
      const batch = data[itemsKey] ?? [];
      items.push(...batch);
      url = data.next_page ?? null;
    } catch {
      break;
    }
  }
  return items;
}

async function fetchZendeskGroups(baseUrl: string, email: string, apiToken: string): Promise<Map<number, string>> {
  const groups = await fetchZendeskPaginated(
    `${baseUrl}/api/v2/groups.json?per_page=100`, email, apiToken, "groups"
  );
  const map = new Map<number, string>();
  for (const g of groups) map.set(g.id, g.name);
  return map;
}

async function fetchZendeskForms(baseUrl: string, email: string, apiToken: string): Promise<Map<number, string>> {
  const forms = await fetchZendeskPaginated(
    `${baseUrl}/api/v2/ticket_forms.json?per_page=100`, email, apiToken, "ticket_forms"
  );
  const map = new Map<number, string>();
  for (const f of forms) map.set(f.id, f.name);
  return map;
}

export async function connectZendesk(params: {
  workspaceId: string;
  baseUrl: string;
  email: string;
  apiToken: string;
  startDaysAgo?: number;
}) {
  const baseUrl = normalizeBaseUrl(params.baseUrl);
  const days = params.startDaysAgo ?? 30;
  const startTime = Math.floor((Date.now() - days * 24 * 60 * 60 * 1000) / 1000);

  const existing = await db.select().from(zendeskIntegrations)
    .where(eq(zendeskIntegrations.workspaceId, params.workspaceId));

  if (existing.length > 0) {
    const [updated] = await db.update(zendeskIntegrations)
      .set({
        baseUrl,
        email: params.email,
        apiToken: params.apiToken,
        enabled: true,
        startTime,
        cursor: null,
      })
      .where(eq(zendeskIntegrations.workspaceId, params.workspaceId))
      .returning();
    return updated;
  }

  const [created] = await db.insert(zendeskIntegrations)
    .values({
      workspaceId: params.workspaceId,
      baseUrl,
      email: params.email,
      apiToken: params.apiToken,
      enabled: true,
      startTime,
      cursor: null,
    })
    .returning();
  return created;
}

type ZendeskTicket = {
  id: number;
  subject?: string;
  description?: string;
  priority?: "urgent" | "high" | "normal" | "low" | null;
  status?: string;
  tags?: string[];
  updated_at?: string;
  via?: { channel?: string };
  form_id?: number;
  group_id?: number;
};

export async function syncZendesk(workspaceId: string) {
  const [integ] = await db.select().from(zendeskIntegrations)
    .where(eq(zendeskIntegrations.workspaceId, workspaceId));

  if (!integ || !integ.enabled) {
    throw new Error("Zendesk integration not connected or disabled.");
  }

  const groupMap = await fetchZendeskGroups(integ.baseUrl, integ.email, integ.apiToken);
  const formMap = await fetchZendeskForms(integ.baseUrl, integ.email, integ.apiToken);

  let url = integ.cursor
    ? `${integ.baseUrl}/api/v2/incremental/tickets/cursor.json?cursor=${encodeURIComponent(integ.cursor)}`
    : `${integ.baseUrl}/api/v2/incremental/tickets/cursor.json?start_time=${integ.startTime}`;

  let totalFetched = 0;
  let totalInserted = 0;
  let lastAfterCursor: string | null = integ.cursor ?? null;
  const insertedSignalIds: string[] = [];

  for (let guard = 0; guard < 25; guard++) {
    const res = await fetch(url, {
      method: "GET",
      headers: {
        Authorization: authHeader(integ.email, integ.apiToken),
        Accept: "application/json",
      },
    });

    if (!res.ok) {
      const text = await res.text();
      throw new Error(`Zendesk sync failed: ${res.status} ${res.statusText} - ${text.slice(0, 300)}`);
    }

    const data = await res.json();
    const tickets: ZendeskTicket[] = data.tickets || [];
    totalFetched += tickets.length;

    if (tickets.length) {
      for (const t of tickets) {
        const formName = t.form_id ? formMap.get(t.form_id) : undefined;
        const groupName = t.group_id ? groupMap.get(t.group_id) : undefined;
        const themeTopic = extractTopicForZendesk({ subject: t.subject, description: t.description, tags: t.tags });
        const firstTag = t.tags && t.tags.length ? t.tags[0] : undefined;
        const topic = formName || groupName || themeTopic || firstTag || "support";
        const channel = t.via?.channel || "unknown";
        const externalId = `zendesk:${t.id}`;

        try {
          const inserted = await db.insert(signals).values({
            workspaceId,
            source: "zendesk",
            kind: "voc",
            title: `[ZD ${t.id}] ${(t.subject || "Ticket").slice(0, 220)}`,
            topic: String(topic).slice(0, 120),
            body: [
              `Status: ${t.status || "n/a"}`,
              `Priority: ${t.priority || "n/a"}`,
              `Channel: ${channel}`,
              "",
              (t.description || "").slice(0, 1800),
            ].join("\n"),
            severity: priorityToSeverity(t.priority),
            externalUrl: `${integ.baseUrl}/agent/tickets/${t.id}`,
            externalId,
          }).onConflictDoNothing().returning({ id: signals.id });
          if (inserted.length > 0) {
            totalInserted++;
            insertedSignalIds.push(inserted[0].id);
          }
        } catch (err: any) {
          if (err.code === "23505") continue;
          throw err;
        }
      }
    }

    lastAfterCursor = data.after_cursor ?? lastAfterCursor;

    if (data.end_of_stream === true) break;

    url = data.after_url ||
      `${integ.baseUrl}/api/v2/incremental/tickets/cursor.json?cursor=${encodeURIComponent(lastAfterCursor || "")}`;
  }

  if (insertedSignalIds.length > 0 && process.env.OPENAI_API_KEY) {
    try {
      await enqueueNormalizeSignal(insertedSignalIds);
    } catch (err: any) {
      console.error(`[zendesk-sync] Failed to enqueue AI normalization: ${err.message}`);
    }
  }

  await db.update(zendeskIntegrations)
    .set({
      cursor: lastAfterCursor,
      lastSyncedAt: new Date(),
    })
    .where(eq(zendeskIntegrations.workspaceId, workspaceId));

  return { fetched: totalFetched, inserted: totalInserted };
}

export async function zendeskStatus(workspaceId: string) {
  const [integ] = await db.select().from(zendeskIntegrations)
    .where(eq(zendeskIntegrations.workspaceId, workspaceId));

  if (!integ) return { connected: false };
  return {
    connected: true,
    enabled: integ.enabled,
    baseUrl: integ.baseUrl,
    lastSyncedAt: integ.lastSyncedAt,
  };
}

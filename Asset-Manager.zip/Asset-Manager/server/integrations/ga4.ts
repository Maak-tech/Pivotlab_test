import { BetaAnalyticsDataClient } from "@google-analytics/data";
import { storage } from "../storage";
import type { InsertSignal } from "@shared/schema";

function getGaClient() {
  const raw = process.env.GA_SERVICE_ACCOUNT_JSON;
  if (!raw) throw new Error("Missing GA_SERVICE_ACCOUNT_JSON secret.");

  const creds = JSON.parse(raw);
  const private_key = String(creds.private_key || "").replace(/\\n/g, "\n");
  const client_email = String(creds.client_email || "");
  const projectId = creds.project_id;

  if (!client_email || !private_key) throw new Error("Invalid GA service account JSON.");

  return new BetaAnalyticsDataClient({
    credentials: { client_email, private_key },
    projectId,
  });
}

function pctChange(curr: number, prev: number) {
  if (prev <= 0) return curr > 0 ? 1 : 0;
  return (curr - prev) / prev;
}

function severityFromDrop(dropPct: number) {
  const d = Math.abs(dropPct);
  if (d >= 0.5) return 5;
  if (d >= 0.3) return 4;
  if (d >= 0.2) return 3;
  return 2;
}

function topicFromEvent(eventName: string) {
  const e = eventName.toLowerCase();
  if (e.includes("sign") || e.includes("login") || e.includes("register")) return "onboarding";
  if (e.includes("checkout") || e.includes("purchase") || e.includes("payment")) return "checkout";
  if (e.includes("subscribe") || e.includes("billing") || e.includes("invoice")) return "billing";
  if (e.includes("search")) return "search";
  if (e.includes("scroll") || e.includes("engage")) return "engagement";
  if (e.includes("click") || e.includes("select")) return "interaction";
  return eventName.slice(0, 40);
}

async function runTotals(client: BetaAnalyticsDataClient, propertyId: string, startDate: string, endDate: string) {
  const [res] = await client.runReport({
    property: `properties/${propertyId}`,
    dateRanges: [{ startDate, endDate }],
    metrics: [{ name: "sessions" }, { name: "totalUsers" }, { name: "newUsers" }, { name: "engagedSessions" }],
  });

  const row = res.rows?.[0];
  const vals = row?.metricValues?.map(v => Number(v.value || 0)) ?? [0, 0, 0, 0];

  return {
    sessions: vals[0] || 0,
    totalUsers: vals[1] || 0,
    newUsers: vals[2] || 0,
    engagedSessions: vals[3] || 0,
  };
}

async function runEventCounts(
  client: BetaAnalyticsDataClient,
  propertyId: string,
  startDate: string,
  endDate: string,
  keyEvents?: string[]
) {
  const hasKeys = Array.isArray(keyEvents) && keyEvents.length > 0;

  const [res] = await client.runReport({
    property: `properties/${propertyId}`,
    dateRanges: [{ startDate, endDate }],
    dimensions: [{ name: "eventName" }],
    metrics: [{ name: "eventCount" }],
    ...(hasKeys
      ? {
          dimensionFilter: {
            filter: {
              fieldName: "eventName",
              inListFilter: { values: keyEvents },
            },
          },
        }
      : {}),
    orderBys: [{ metric: { metricName: "eventCount" }, desc: true }],
    limit: hasKeys ? 200 : 30,
  });

  const map = new Map<string, number>();
  for (const row of res.rows ?? []) {
    const name = row.dimensionValues?.[0]?.value ?? "";
    const count = Number(row.metricValues?.[0]?.value ?? 0);
    if (name) map.set(name, count);
  }
  return map;
}

async function runSegmentReport(
  client: BetaAnalyticsDataClient,
  propertyId: string,
  dimension: string,
  startDate: string,
  endDate: string,
) {
  const [res] = await client.runReport({
    property: `properties/${propertyId}`,
    dateRanges: [{ startDate, endDate }],
    dimensions: [{ name: dimension }],
    metrics: [{ name: "sessions" }, { name: "totalUsers" }],
    orderBys: [{ metric: { metricName: "sessions" }, desc: true }],
    limit: 20,
  });

  const result: Array<{ value: string; sessions: number; users: number }> = [];
  for (const row of res.rows ?? []) {
    const value = row.dimensionValues?.[0]?.value ?? "";
    if (!value || value === "(not set)") continue;
    const sessions = Number(row.metricValues?.[0]?.value ?? 0);
    const users = Number(row.metricValues?.[1]?.value ?? 0);
    result.push({ value, sessions, users });
  }
  return result;
}

async function runSegmentAnalysis(
  client: BetaAnalyticsDataClient,
  propertyId: string,
  workspaceId: string,
  lastStart: string,
  lastEnd: string,
  prevStart: string,
  prevEnd: string,
): Promise<InsertSignal[]> {
  const signals: InsertSignal[] = [];
  const segmentDimensions = [
    { dim: "deviceCategory", label: "Device", topic: "platform" },
    { dim: "country", label: "Country", topic: "geo" },
    { dim: "sessionDefaultChannelGroup", label: "Channel", topic: "acquisition" },
  ];

  for (const seg of segmentDimensions) {
    try {
      const [lastData, prevData] = await Promise.all([
        runSegmentReport(client, propertyId, seg.dim, lastStart, lastEnd),
        runSegmentReport(client, propertyId, seg.dim, prevStart, prevEnd),
      ]);

      const prevMap = new Map(prevData.map(d => [d.value, d]));

      for (const curr of lastData) {
        const prev = prevMap.get(curr.value);
        if (!prev || prev.sessions < 30) continue;

        const change = pctChange(curr.sessions, prev.sessions);
        if (change <= -0.2) {
          const sev = severityFromDrop(change);
          signals.push({
            workspaceId,
            source: "ga4",
            kind: "analytics",
            topic: seg.topic,
            title: `GA4: ${seg.label} "${curr.value}" sessions down ${(Math.abs(change) * 100).toFixed(0)}% WoW`,
            body: `Segment: ${seg.label} = ${curr.value}\nSessions last 7d: ${curr.sessions}\nSessions prev 7d: ${prev.sessions}\nUsers last 7d: ${curr.users}\nChange: ${(change * 100).toFixed(1)}%`,
            severity: sev,
            externalUrl: null,
            externalId: `ga4:${propertyId}:seg:${seg.dim}:${curr.value}:${lastEnd}`,
          });
        }
      }
    } catch (err: any) {
      console.error(`[ga4] Segment analysis failed for ${seg.dim}: ${err.message}`);
    }
  }

  return signals;
}

export async function connectGa4(params: {
  workspaceId: string;
  propertyId: string;
  keyEvents?: string[];
}) {
  return storage.upsertGa4Integration({
    workspaceId: params.workspaceId,
    propertyId: params.propertyId,
    keyEvents: params.keyEvents,
  });
}

export async function syncGa4(workspaceId: string) {
  const integ = await storage.getGa4Integration(workspaceId);
  if (!integ || !integ.enabled) throw new Error("GA4 not connected or disabled.");

  const client = getGaClient();
  const propertyId = integ.propertyId;

  const lastStart = "7daysAgo";
  const lastEnd = "1daysAgo";
  const prevStart = "14daysAgo";
  const prevEnd = "8daysAgo";

  const [lastTotals, prevTotals] = await Promise.all([
    runTotals(client, propertyId, lastStart, lastEnd),
    runTotals(client, propertyId, prevStart, prevEnd),
  ]);

  const keyEvents = Array.isArray(integ.keyEvents) ? (integ.keyEvents as unknown as string[]) : [];
  const [lastEvents, prevEvents] = await Promise.all([
    runEventCounts(client, propertyId, lastStart, lastEnd, keyEvents),
    runEventCounts(client, propertyId, prevStart, prevEnd, keyEvents),
  ]);

  const signalData: InsertSignal[] = [];

  const totalsChecks: Array<{ key: keyof typeof lastTotals; topic: string; label: string; minPrev: number }> = [
    { key: "sessions", topic: "growth", label: "Sessions", minPrev: 200 },
    { key: "totalUsers", topic: "growth", label: "Total users", minPrev: 200 },
    { key: "newUsers", topic: "acquisition", label: "New users", minPrev: 100 },
    { key: "engagedSessions", topic: "engagement", label: "Engaged sessions", minPrev: 150 },
  ];

  for (const t of totalsChecks) {
    const curr = lastTotals[t.key];
    const prev = prevTotals[t.key];
    const change = pctChange(curr, prev);

    if (prev >= t.minPrev && change <= -0.2) {
      const sev = severityFromDrop(change);
      signalData.push({
        workspaceId,
        source: "ga4",
        kind: "analytics",
        topic: t.topic,
        title: `GA4: ${t.label} down ${(Math.abs(change) * 100).toFixed(0)}% WoW`,
        body: `${t.label} last 7d: ${curr}\n${t.label} prev 7d: ${prev}\nChange: ${(change * 100).toFixed(1)}%\nWindow: ${lastStart}..${lastEnd}`,
        severity: sev,
        externalUrl: null,
        externalId: `ga4:${propertyId}:totals:${t.key}:${lastEnd}`,
      });
    }
  }

  for (const [eventName, curr] of Array.from(lastEvents.entries())) {
    const prev = prevEvents.get(eventName) ?? 0;
    const change = pctChange(curr, prev);

    if (prev >= 50 && change <= -0.25) {
      const sev = severityFromDrop(change);
      const topic = topicFromEvent(eventName);
      signalData.push({
        workspaceId,
        source: "ga4",
        kind: "analytics",
        topic,
        title: `GA4: ${eventName} down ${(Math.abs(change) * 100).toFixed(0)}% WoW`,
        body: `Event: ${eventName}\nCount last 7d: ${curr}\nCount prev 7d: ${prev}\nChange: ${(change * 100).toFixed(1)}%\nWindow: ${lastStart}..${lastEnd}`,
        severity: sev,
        externalUrl: null,
        externalId: `ga4:${propertyId}:event:${eventName}:${lastEnd}`,
      });
    }
  }

  const segmentSignals = await runSegmentAnalysis(client, propertyId, workspaceId, lastStart, lastEnd, prevStart, prevEnd);
  signalData.push(...segmentSignals);

  const inserted = await storage.createSignalsSkipDuplicates(signalData);

  await storage.updateGa4LastSynced(workspaceId);

  return { fetchedSignals: signalData.length, inserted };
}

export async function ga4Status(workspaceId: string) {
  const integ = await storage.getGa4Integration(workspaceId);
  if (!integ) return { connected: false as const };

  return {
    connected: true as const,
    enabled: integ.enabled,
    propertyId: integ.propertyId,
    lastSyncedAt: integ.lastSyncedAt,
    keyEvents: integ.keyEvents ?? [],
  };
}

import { storage } from "./storage";
import type { Signal, Constraint } from "@shared/schema";
import { extractThemeAI } from "./ai/theme";
import { sha256 } from "./ai/hash";

const SOURCE_WEIGHTS: Record<string, number> = {
  reviews: 1.3,
  app_reviews: 1.3,
  support: 1.2,
  zendesk: 1.2,
  surveys: 1.1,
  social: 1.0,
  analytics: 1.0,
  ga4: 1.15,
  jira: 0.9,
  intercom: 1.1,
  internal: 0.7,
};

function getSourceWeight(source: string): number {
  return SOURCE_WEIGHTS[source] ?? 1.0;
}

function scoreOpportunity(args: {
  signals: Signal[];
  constraint: Constraint | undefined;
}): { score: number; confidence: number } {
  const { signals: items, constraint } = args;
  const count = items.length;
  if (count === 0) return { score: 0, confidence: 0 };

  const severityWeightedVolume = items.reduce(
    (sum, s) => sum + s.severity * getSourceWeight(s.source),
    0
  );
  const volumeScore = Math.min(10, Math.log2(1 + severityWeightedVolume) * 2);

  const avgSeverity = items.reduce((sum, s) => sum + s.severity, 0) / count;
  const severityScore = Math.min(10, avgSeverity * 2);

  const now = Date.now();
  const oneWeekMs = 7 * 24 * 60 * 60 * 1000;
  const currentWeek = items.filter(
    (s) => now - s.createdAt.getTime() < oneWeekMs
  );
  const previousWeek = items.filter(
    (s) => {
      const age = now - s.createdAt.getTime();
      return age >= oneWeekMs && age < 2 * oneWeekMs;
    }
  );
  let trendBonus = 0;
  if (previousWeek.length > 0) {
    const changePercent =
      ((currentWeek.length - previousWeek.length) / previousWeek.length) * 100;
    if (changePercent > 50) trendBonus = 4;
    else if (changePercent > 25) trendBonus = 2.5;
    else if (changePercent > 10) trendBonus = 1;
  } else if (currentWeek.length > 0) {
    trendBonus = 1.5;
  }

  const textBlob = items.map((i) => `${i.title}\n${i.body ?? ""}`).join("\n");
  let kpiBonus = 0;
  if (
    constraint?.primaryKpi &&
    constraint.primaryKpi.trim().length > 0 &&
    textBlob.toLowerCase().includes(constraint.primaryKpi.toLowerCase())
  ) {
    kpiBonus = 5;
  }

  let deadlineBonus = 0;
  if (constraint?.deadlineDate) {
    const daysUntilDeadline =
      (constraint.deadlineDate.getTime() - now) / (1000 * 60 * 60 * 24);
    if (daysUntilDeadline > 0 && daysUntilDeadline <= 7) deadlineBonus = 4;
    else if (daysUntilDeadline > 0 && daysUntilDeadline <= 30) deadlineBonus = 2;
    else if (daysUntilDeadline > 0 && daysUntilDeadline <= 90) deadlineBonus = 1;
  }

  const rawScore =
    volumeScore + severityScore + trendBonus + kpiBonus + deadlineBonus;
  const score = Math.round(Math.min(35, rawScore) * 10) / 10;

  const sourceCount = new Set(items.map((s) => s.source)).size;
  const confidence = Math.min(
    0.95,
    0.3 + count / 40 + sourceCount * 0.05
  );

  return { score, confidence: Math.round(confidence * 100) / 100 };
}

export async function recomputeOpportunities(workspaceId: string) {
  const constraint = await storage.getConstraint(workspaceId);
  const allSignals = await storage.getSignals(workspaceId);
  const signalsSlice = allSignals.slice(0, 1000);

  const groups = new Map<string, Signal[]>();
  for (const s of signalsSlice) {
    const key = (s.normTopic || s.topic || s.title || "untitled").trim().toLowerCase();
    const arr = groups.get(key) || [];
    arr.push(s);
    groups.set(key, arr);
  }

  const entries = Array.from(groups.entries());
  for (const [key, items] of entries) {
    const { score, confidence } = scoreOpportunity({
      signals: items,
      constraint,
    });

    const title = items[0]?.normTopic || items[0]?.topic || items[0]?.title || "Opportunity";
    const problemStatement =
      items[0]?.body?.slice(0, 400) ||
      `Users report recurring friction around: ${title}`;

    const sources = [...new Set(items.map(s => s.source))];
    const sourceBreakdown = sources.map(src => ({
      source: src,
      count: items.filter(s => s.source === src).length,
    }));

    const now2 = Date.now();
    const oneWeekMs2 = 7 * 24 * 60 * 60 * 1000;
    const currentWeekCount = items.filter(s => now2 - s.createdAt.getTime() < oneWeekMs2).length;
    const previousWeekCount = items.filter(s => {
      const age = now2 - s.createdAt.getTime();
      return age >= oneWeekMs2 && age < 2 * oneWeekMs2;
    }).length;
    let trendDirection = "stable";
    let trendPercent = 0;
    if (previousWeekCount > 0) {
      trendPercent = Math.round(((currentWeekCount - previousWeekCount) / previousWeekCount) * 100);
      if (trendPercent > 10) trendDirection = "rising";
      else if (trendPercent < -10) trendDirection = "falling";
    } else if (currentWeekCount > 0) {
      trendDirection = "new";
      trendPercent = 100;
    }

    const opportunity = await storage.upsertOpportunity({
      workspaceId,
      key,
      title,
      problemStatement,
      score,
      confidence,
      status: "open",
      sourceBreakdown,
      trendDirection,
      trendPercent,
      signalCount: items.length,
    });

    await storage.deleteEvidenceByOpportunity(opportunity.id, "snippet");
    const top = items.slice(0, 3);
    await storage.createEvidence(
      top.map((s) => ({
        opportunityId: opportunity.id,
        kind: "snippet" as const,
        snippet: (s.body || s.title).slice(0, 500),
        url: s.externalUrl ?? undefined,
      }))
    );
  }

  if (process.env.OPENAI_API_KEY) {
    try {
      const allOpps = await storage.getOpportunities(workspaceId);
      const topOpps = allOpps
        .filter(o => o.status === "open")
        .sort((a, b) => b.score - a.score)
        .slice(0, 10);

      for (const opp of topOpps) {
        const textBlob = [
          opp.title,
          opp.problemStatement,
          ...opp.evidence.map(e => e.snippet || "").filter(Boolean),
        ].join("\n").slice(0, 4000);

        const cacheKey = sha256(textBlob + (constraint?.primaryKpi || ""));

        if (opp.aiCacheKey === cacheKey) continue;

        try {
          const theme = await extractThemeAI({ text: textBlob, source: "mixed" });
          await storage.updateOpportunityAI(opp.id, {
            aiSummary: theme.userPain,
            aiTags: {
              topic: theme.topic,
              subtopics: theme.subtopics,
              kpiHints: theme.kpiHints,
              sentiment: theme.sentiment,
              urgency: theme.urgency,
            },
            aiRationale: `Topic=${theme.topic}. Urgency=${theme.urgency}. Sentiment=${theme.sentiment}.`,
            aiCacheKey: cacheKey,
          });
        } catch (aiErr: any) {
          console.error(`[recompute] AI enrichment failed for ${opp.id}: ${aiErr.message}`);
        }
      }
    } catch (aiErr: any) {
      console.error(`[recompute] AI enrichment step failed: ${aiErr.message}`);
    }
  }

  return { opportunitiesUpdated: groups.size };
}

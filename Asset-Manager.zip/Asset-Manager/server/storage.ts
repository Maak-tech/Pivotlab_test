import { db } from "./db";
import { eq, desc, and, sql, count } from "drizzle-orm";
import { lte, lt, isNull, inArray } from "drizzle-orm";
import {
  users, organizations, workspaces, constraints, signals, opportunities, evidence, jiraIntegrations,
  initiatives, initiativeTopics, pivotRecommendations, slackIntegrations, ga4Integrations,
  decisionRecords, outcomeChecks, aiNormalizationCache, aiJobs, alertRules, alertLogs,
  type User, type InsertUser,
  type Organization, type InsertOrganization,
  type Workspace, type InsertWorkspace,
  type Constraint,
  type Signal, type InsertSignal,
  type Opportunity, type InsertOpportunity,
  type Evidence, type InsertEvidence,
  type JiraIntegration,
  type Initiative, type InsertInitiative,
  type InitiativeTopic,
  type PivotRecommendation, type InsertPivotRecommendation,
  type SlackIntegration,
  type Ga4Integration,
  type DecisionRecord, type InsertDecisionRecord,
  type OutcomeCheck, type InsertOutcomeCheck,
  type AlertRule, type InsertAlertRule, type AlertLog,
  type AiNormalizationCache, type AiJob,
} from "@shared/schema";

export interface IStorage {
  getUser(id: string): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  getUserByStripeCustomerId(stripeCustomerId: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  updateUserStripeInfo(userId: string, data: { stripeCustomerId?: string; stripeSubscriptionId?: string }): Promise<User | undefined>;
  updateUserPlan(userId: string, plan: string): Promise<User | undefined>;

  getOrganizationsByOwner(ownerId: string): Promise<Organization[]>;
  createOrganization(org: InsertOrganization): Promise<Organization>;

  getWorkspacesByOrg(orgId: string): Promise<Workspace[]>;
  getWorkspacesByOwner(ownerId: string): Promise<Workspace[]>;
  getWorkspace(id: string): Promise<Workspace | undefined>;
  createWorkspace(ws: InsertWorkspace): Promise<Workspace>;

  getConstraint(workspaceId: string): Promise<Constraint | undefined>;
  upsertConstraint(data: {
    workspaceId: string;
    primaryKpi?: string;
    targetValue?: number;
    budgetCap?: number;
    deadlineDate?: Date;
  }): Promise<Constraint>;

  getSignals(workspaceId: string): Promise<Signal[]>;
  getRecentSignals(limit: number): Promise<Signal[]>;
  createSignal(signal: InsertSignal): Promise<Signal>;
  createSignals(sigs: InsertSignal[]): Promise<void>;

  getOpportunities(workspaceId: string): Promise<(Opportunity & { evidence: Evidence[] })[]>;
  getOpportunity(id: string): Promise<(Opportunity & { evidence: Evidence[] }) | undefined>;
  upsertOpportunity(data: InsertOpportunity): Promise<Opportunity>;
  updateOpportunityStatus(id: string, status: string): Promise<Opportunity | undefined>;
  updateOpportunityAI(id: string, data: { aiSummary?: string; aiTags?: any; aiRationale?: string; aiCacheKey?: string }): Promise<void>;
  deleteEvidenceByOpportunity(opportunityId: string, kind: string): Promise<void>;
  createEvidence(items: InsertEvidence[]): Promise<void>;

  getInitiativesByWorkspace(workspaceId: string): Promise<(Initiative & { topics: InitiativeTopic[]; recommendations: PivotRecommendation[] })[]>;
  getInitiative(id: string): Promise<(Initiative & { topics: InitiativeTopic[]; recommendations: PivotRecommendation[] }) | undefined>;
  createInitiative(data: InsertInitiative): Promise<Initiative>;
  updateInitiativeStatus(id: string, status: string): Promise<Initiative | undefined>;
  addInitiativeTopic(initiativeId: string, topic: string): Promise<InitiativeTopic>;
  removeInitiativeTopic(id: string): Promise<void>;
  createPivotRecommendation(data: InsertPivotRecommendation): Promise<PivotRecommendation>;
  getActiveInitiatives(): Promise<(Initiative & { topics: InitiativeTopic[] })[]>;
  getSignalsByTopicsInRange(workspaceId: string, topics: string[], startDate: Date, endDate: Date): Promise<Signal[]>;

  getJiraIntegration(workspaceId: string): Promise<JiraIntegration | undefined>;
  upsertJiraIntegration(data: {
    workspaceId: string;
    baseUrl: string;
    email: string;
    apiToken: string;
    jql: string;
  }): Promise<JiraIntegration>;
  updateJiraLastSynced(workspaceId: string): Promise<void>;
  createSignalsSkipDuplicates(sigs: InsertSignal[]): Promise<number>;

  getSlackIntegration(workspaceId: string): Promise<SlackIntegration | undefined>;
  upsertSlackIntegration(data: { workspaceId: string; webhookUrl: string; channelName?: string }): Promise<SlackIntegration>;
  disableSlackIntegration(workspaceId: string): Promise<void>;
  getEnabledSlackIntegrations(): Promise<SlackIntegration[]>;

  getGa4Integration(workspaceId: string): Promise<Ga4Integration | undefined>;
  upsertGa4Integration(data: { workspaceId: string; propertyId: string; keyEvents?: string[] }): Promise<Ga4Integration>;
  updateGa4LastSynced(workspaceId: string): Promise<void>;
  getEnabledGa4Integrations(): Promise<Ga4Integration[]>;

  updateInitiativeShipped(id: string, shippedAt: Date): Promise<Initiative | undefined>;
  updateInitiativeJira(id: string, jiraIssueKey: string, jiraIssueUrl: string): Promise<Initiative | undefined>;

  createDecisionRecord(data: InsertDecisionRecord & { dueDate?: Date }): Promise<DecisionRecord>;
  getDecisionRecords(workspaceId: string): Promise<DecisionRecord[]>;
  getDecisionRecordsByInitiative(initiativeId: string): Promise<DecisionRecord[]>;

  createOutcomeCheck(data: InsertOutcomeCheck): Promise<OutcomeCheck>;
  getOutcomeChecksByInitiative(initiativeId: string): Promise<OutcomeCheck[]>;
  getPendingOutcomeChecks(): Promise<OutcomeCheck[]>;
  completeOutcomeCheck(id: string, metrics: any, resultSummary: string, slackNotified: boolean): Promise<OutcomeCheck | undefined>;
  failOutcomeCheck(id: string, resultSummary: string): Promise<OutcomeCheck | undefined>;

  updateSignalNorm(id: string, data: { normTopic: string; normTags: any; normCacheKey: string }): Promise<void>;
  getUnnormalizedSignals(workspaceId: string, externalIds: string[]): Promise<{ id: string }[]>;

  getNormCache(cacheKey: string): Promise<AiNormalizationCache | undefined>;
  setNormCache(cacheKey: string, result: any): Promise<void>;

  enqueueAiJobs(jobs: { type: string; uniqueKey: string; payload: any }[]): Promise<number>;
  getPendingAiJobs(limit: number): Promise<AiJob[]>;
  markAiJobsRunning(ids: string[]): Promise<void>;
  completeAiJob(id: string): Promise<void>;
  failAiJob(id: string, error: string): Promise<void>;
  retryAiJob(id: string, attempts: number, error: string): Promise<void>;
  resetStaleAiJobs(staleMs: number): Promise<number>;
  getAiQueueStats(): Promise<{
    pending: number;
    running: number;
    done: number;
    failed: number;
    total: number;
    successRate: number;
    avgProcessingMs: number;
  }>;

  getAlertRules(workspaceId: string): Promise<AlertRule[]>;
  createAlertRule(data: InsertAlertRule): Promise<AlertRule>;
  updateAlertRule(id: string, data: Partial<InsertAlertRule>): Promise<AlertRule | undefined>;
  deleteAlertRule(id: string): Promise<void>;
  getAlertLogs(workspaceId: string, limit?: number): Promise<AlertLog[]>;
  getLastAlertForTopic(ruleId: string, topic: string): Promise<AlertLog | undefined>;
  createAlertLog(data: { workspaceId: string; ruleId: string; topic: string; message: string; slackChannel?: string }): Promise<AlertLog>;
  getAllEnabledAlertRules(): Promise<AlertRule[]>;

  getDashboardStats(ownerId: string): Promise<{
    totalSignals: number;
    totalOpportunities: number;
    avgScore: number;
    topOpportunities: (Opportunity & { evidenceCount: number })[];
    recentSignals: Signal[];
    statusBreakdown: Record<string, number>;
  }>;
}

export class DatabaseStorage implements IStorage {
  async getUser(id: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user;
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.username, username));
    return user;
  }

  async getUserByStripeCustomerId(stripeCustomerId: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.stripeCustomerId, stripeCustomerId));
    return user;
  }

  async createUser(user: InsertUser): Promise<User> {
    const [created] = await db.insert(users).values(user).returning();
    return created;
  }

  async updateUserStripeInfo(userId: string, data: { stripeCustomerId?: string; stripeSubscriptionId?: string }): Promise<User | undefined> {
    const [updated] = await db.update(users).set(data).where(eq(users.id, userId)).returning();
    return updated;
  }

  async updateUserPlan(userId: string, plan: string): Promise<User | undefined> {
    const [updated] = await db.update(users).set({ plan }).where(eq(users.id, userId)).returning();
    return updated;
  }

  async getOrganizationsByOwner(ownerId: string): Promise<Organization[]> {
    return db.select().from(organizations).where(eq(organizations.ownerId, ownerId));
  }

  async createOrganization(org: InsertOrganization): Promise<Organization> {
    const [created] = await db.insert(organizations).values(org).returning();
    return created;
  }

  async getWorkspacesByOrg(orgId: string): Promise<Workspace[]> {
    return db.select().from(workspaces).where(eq(workspaces.orgId, orgId));
  }

  async getWorkspacesByOwner(ownerId: string): Promise<Workspace[]> {
    const orgs = await this.getOrganizationsByOwner(ownerId);
    if (orgs.length === 0) return [];
    const orgIds = orgs.map((o) => o.id);
    const result: Workspace[] = [];
    for (const orgId of orgIds) {
      const ws = await db.select().from(workspaces).where(eq(workspaces.orgId, orgId));
      result.push(...ws);
    }
    return result;
  }

  async getWorkspace(id: string): Promise<Workspace | undefined> {
    const [ws] = await db.select().from(workspaces).where(eq(workspaces.id, id));
    return ws;
  }

  async createWorkspace(ws: InsertWorkspace): Promise<Workspace> {
    const [created] = await db.insert(workspaces).values(ws).returning();
    return created;
  }

  async getConstraint(workspaceId: string): Promise<Constraint | undefined> {
    const [c] = await db.select().from(constraints).where(eq(constraints.workspaceId, workspaceId));
    return c;
  }

  async upsertConstraint(data: {
    workspaceId: string;
    primaryKpi?: string;
    targetValue?: number;
    budgetCap?: number;
    deadlineDate?: Date;
  }): Promise<Constraint> {
    const existing = await this.getConstraint(data.workspaceId);
    if (existing) {
      const [updated] = await db
        .update(constraints)
        .set({
          primaryKpi: data.primaryKpi ?? null,
          targetValue: data.targetValue ?? null,
          budgetCap: data.budgetCap ?? null,
          deadlineDate: data.deadlineDate ?? null,
        })
        .where(eq(constraints.workspaceId, data.workspaceId))
        .returning();
      return updated;
    }
    const [created] = await db.insert(constraints).values({
      workspaceId: data.workspaceId,
      primaryKpi: data.primaryKpi ?? null,
      targetValue: data.targetValue ?? null,
      budgetCap: data.budgetCap ?? null,
      deadlineDate: data.deadlineDate ?? null,
    }).returning();
    return created;
  }

  async getSignals(workspaceId: string): Promise<Signal[]> {
    return db.select().from(signals).where(eq(signals.workspaceId, workspaceId)).orderBy(desc(signals.createdAt));
  }

  async getRecentSignals(limit: number): Promise<Signal[]> {
    return db.select().from(signals).orderBy(desc(signals.createdAt)).limit(limit);
  }

  async createSignal(signal: InsertSignal): Promise<Signal> {
    const [created] = await db.insert(signals).values(signal).returning();
    return created;
  }

  async createSignals(sigs: InsertSignal[]): Promise<void> {
    if (sigs.length === 0) return;
    await db.insert(signals).values(sigs);
  }

  async getOpportunities(workspaceId: string): Promise<(Opportunity & { evidence: Evidence[] })[]> {
    const opps = await db.select().from(opportunities)
      .where(eq(opportunities.workspaceId, workspaceId))
      .orderBy(desc(opportunities.score));

    const result = [];
    for (const opp of opps) {
      const ev = await db.select().from(evidence).where(eq(evidence.opportunityId, opp.id));
      result.push({ ...opp, evidence: ev });
    }
    return result;
  }

  async getOpportunity(id: string): Promise<(Opportunity & { evidence: Evidence[] }) | undefined> {
    const [opp] = await db.select().from(opportunities).where(eq(opportunities.id, id));
    if (!opp) return undefined;
    const ev = await db.select().from(evidence).where(eq(evidence.opportunityId, opp.id));
    return { ...opp, evidence: ev };
  }

  async upsertOpportunity(data: InsertOpportunity & { sourceBreakdown?: any; trendDirection?: string; trendPercent?: number; signalCount?: number }): Promise<Opportunity> {
    const existing = await db.select().from(opportunities)
      .where(and(eq(opportunities.workspaceId, data.workspaceId!), eq(opportunities.key, data.key!)));

    if (existing.length > 0) {
      const [updated] = await db.update(opportunities).set({
        title: data.title,
        problemStatement: data.problemStatement,
        score: data.score,
        confidence: data.confidence,
        sourceBreakdown: data.sourceBreakdown ?? undefined,
        trendDirection: data.trendDirection ?? undefined,
        trendPercent: data.trendPercent ?? undefined,
        signalCount: data.signalCount ?? undefined,
        updatedAt: new Date(),
      }).where(eq(opportunities.id, existing[0].id)).returning();
      return updated;
    }

    const [created] = await db.insert(opportunities).values({
      ...data,
      status: data.status || "open",
    }).returning();
    return created;
  }

  async updateOpportunityStatus(id: string, status: string): Promise<Opportunity | undefined> {
    const [updated] = await db.update(opportunities)
      .set({ status, updatedAt: new Date() })
      .where(eq(opportunities.id, id))
      .returning();
    return updated;
  }

  async updateOpportunityAI(id: string, data: { aiSummary?: string; aiTags?: any; aiRationale?: string; aiCacheKey?: string }): Promise<void> {
    await db.update(opportunities)
      .set({
        aiSummary: data.aiSummary,
        aiTags: data.aiTags,
        aiRationale: data.aiRationale,
        aiCacheKey: data.aiCacheKey,
        aiUpdatedAt: new Date(),
        updatedAt: new Date(),
      })
      .where(eq(opportunities.id, id));
  }

  async deleteEvidenceByOpportunity(opportunityId: string, kind: string): Promise<void> {
    await db.delete(evidence).where(
      and(eq(evidence.opportunityId, opportunityId), eq(evidence.kind, kind))
    );
  }

  async createEvidence(items: InsertEvidence[]): Promise<void> {
    if (items.length === 0) return;
    await db.insert(evidence).values(items);
  }

  async getInitiativesByWorkspace(workspaceId: string): Promise<(Initiative & { topics: InitiativeTopic[]; recommendations: PivotRecommendation[] })[]> {
    const inits = await db.select().from(initiatives)
      .where(eq(initiatives.workspaceId, workspaceId))
      .orderBy(desc(initiatives.createdAt));

    const result = [];
    for (const init of inits) {
      const topics = await db.select().from(initiativeTopics).where(eq(initiativeTopics.initiativeId, init.id));
      const recs = await db.select().from(pivotRecommendations)
        .where(eq(pivotRecommendations.initiativeId, init.id))
        .orderBy(desc(pivotRecommendations.createdAt));
      result.push({ ...init, topics, recommendations: recs });
    }
    return result;
  }

  async getInitiative(id: string): Promise<(Initiative & { topics: InitiativeTopic[]; recommendations: PivotRecommendation[] }) | undefined> {
    const [init] = await db.select().from(initiatives).where(eq(initiatives.id, id));
    if (!init) return undefined;
    const topics = await db.select().from(initiativeTopics).where(eq(initiativeTopics.initiativeId, id));
    const recs = await db.select().from(pivotRecommendations)
      .where(eq(pivotRecommendations.initiativeId, id))
      .orderBy(desc(pivotRecommendations.createdAt));
    return { ...init, topics, recommendations: recs };
  }

  async createInitiative(data: InsertInitiative): Promise<Initiative> {
    const [created] = await db.insert(initiatives).values(data).returning();
    return created;
  }

  async updateInitiativeStatus(id: string, status: string): Promise<Initiative | undefined> {
    const [updated] = await db.update(initiatives)
      .set({ status })
      .where(eq(initiatives.id, id))
      .returning();
    return updated;
  }

  async addInitiativeTopic(initiativeId: string, topic: string): Promise<InitiativeTopic> {
    const [created] = await db.insert(initiativeTopics).values({ initiativeId, topic }).returning();
    return created;
  }

  async removeInitiativeTopic(id: string): Promise<void> {
    await db.delete(initiativeTopics).where(eq(initiativeTopics.id, id));
  }

  async createPivotRecommendation(data: InsertPivotRecommendation): Promise<PivotRecommendation> {
    const [created] = await db.insert(pivotRecommendations).values(data).returning();
    return created;
  }

  async getActiveInitiatives(): Promise<(Initiative & { topics: InitiativeTopic[] })[]> {
    const inits = await db.select().from(initiatives).where(eq(initiatives.status, "active"));
    const result = [];
    for (const init of inits) {
      const topics = await db.select().from(initiativeTopics).where(eq(initiativeTopics.initiativeId, init.id));
      result.push({ ...init, topics });
    }
    return result;
  }

  async getSignalsByTopicsInRange(workspaceId: string, topics: string[], startDate: Date, endDate: Date): Promise<Signal[]> {
    if (topics.length === 0) return [];
    const allSignals = await db.select().from(signals)
      .where(eq(signals.workspaceId, workspaceId))
      .orderBy(desc(signals.createdAt));

    return allSignals.filter((s) => {
      if (!s.topic) return false;
      const matchesTopic = topics.some((t) => s.topic!.toLowerCase().includes(t.toLowerCase()));
      const inRange = s.createdAt >= startDate && s.createdAt <= endDate;
      return matchesTopic && inRange;
    });
  }

  async getJiraIntegration(workspaceId: string): Promise<JiraIntegration | undefined> {
    const [integ] = await db.select().from(jiraIntegrations).where(eq(jiraIntegrations.workspaceId, workspaceId));
    return integ;
  }

  async upsertJiraIntegration(data: {
    workspaceId: string;
    baseUrl: string;
    email: string;
    apiToken: string;
    jql: string;
  }): Promise<JiraIntegration> {
    const existing = await this.getJiraIntegration(data.workspaceId);
    if (existing) {
      const [updated] = await db
        .update(jiraIntegrations)
        .set({
          baseUrl: data.baseUrl,
          email: data.email,
          apiToken: data.apiToken,
          jql: data.jql,
          enabled: true,
        })
        .where(eq(jiraIntegrations.workspaceId, data.workspaceId))
        .returning();
      return updated;
    }
    const [created] = await db.insert(jiraIntegrations).values({
      workspaceId: data.workspaceId,
      baseUrl: data.baseUrl,
      email: data.email,
      apiToken: data.apiToken,
      jql: data.jql,
      enabled: true,
    }).returning();
    return created;
  }

  async updateJiraLastSynced(workspaceId: string): Promise<void> {
    await db.update(jiraIntegrations)
      .set({ lastSyncedAt: new Date() })
      .where(eq(jiraIntegrations.workspaceId, workspaceId));
  }

  async createSignalsSkipDuplicates(sigs: InsertSignal[]): Promise<number> {
    if (sigs.length === 0) return 0;
    const before = await db.select({ count: count() }).from(signals);
    await db.insert(signals).values(sigs).onConflictDoNothing();
    const after = await db.select({ count: count() }).from(signals);
    return (after[0]?.count ?? 0) - (before[0]?.count ?? 0);
  }

  async getSlackIntegration(workspaceId: string): Promise<SlackIntegration | undefined> {
    const [integ] = await db.select().from(slackIntegrations).where(eq(slackIntegrations.workspaceId, workspaceId));
    return integ;
  }

  async upsertSlackIntegration(data: { workspaceId: string; webhookUrl: string; channelName?: string }): Promise<SlackIntegration> {
    const existing = await this.getSlackIntegration(data.workspaceId);
    if (existing) {
      const [updated] = await db.update(slackIntegrations)
        .set({
          webhookUrl: data.webhookUrl,
          channelName: data.channelName ?? null,
          enabled: true,
        })
        .where(eq(slackIntegrations.workspaceId, data.workspaceId))
        .returning();
      return updated;
    }
    const [created] = await db.insert(slackIntegrations).values({
      workspaceId: data.workspaceId,
      webhookUrl: data.webhookUrl,
      channelName: data.channelName ?? null,
      enabled: true,
    }).returning();
    return created;
  }

  async disableSlackIntegration(workspaceId: string): Promise<void> {
    await db.update(slackIntegrations)
      .set({ enabled: false })
      .where(eq(slackIntegrations.workspaceId, workspaceId));
  }

  async getEnabledSlackIntegrations(): Promise<SlackIntegration[]> {
    return db.select().from(slackIntegrations).where(eq(slackIntegrations.enabled, true));
  }

  async getGa4Integration(workspaceId: string): Promise<Ga4Integration | undefined> {
    const [integ] = await db.select().from(ga4Integrations).where(eq(ga4Integrations.workspaceId, workspaceId));
    return integ;
  }

  async upsertGa4Integration(data: { workspaceId: string; propertyId: string; keyEvents?: string[] }): Promise<Ga4Integration> {
    const existing = await this.getGa4Integration(data.workspaceId);
    if (existing) {
      const [updated] = await db.update(ga4Integrations)
        .set({
          propertyId: data.propertyId,
          keyEvents: data.keyEvents ?? [],
          enabled: true,
        })
        .where(eq(ga4Integrations.workspaceId, data.workspaceId))
        .returning();
      return updated;
    }
    const [created] = await db.insert(ga4Integrations).values({
      workspaceId: data.workspaceId,
      propertyId: data.propertyId,
      keyEvents: data.keyEvents ?? [],
      enabled: true,
    }).returning();
    return created;
  }

  async updateGa4LastSynced(workspaceId: string): Promise<void> {
    await db.update(ga4Integrations)
      .set({ lastSyncedAt: new Date() })
      .where(eq(ga4Integrations.workspaceId, workspaceId));
  }

  async getEnabledGa4Integrations(): Promise<Ga4Integration[]> {
    return db.select().from(ga4Integrations).where(eq(ga4Integrations.enabled, true));
  }

  async updateInitiativeShipped(id: string, shippedAt: Date): Promise<Initiative | undefined> {
    const [updated] = await db.update(initiatives)
      .set({ status: "shipped", shippedAt })
      .where(eq(initiatives.id, id))
      .returning();
    return updated;
  }

  async updateInitiativeJira(id: string, jiraIssueKey: string, jiraIssueUrl: string): Promise<Initiative | undefined> {
    const [updated] = await db.update(initiatives)
      .set({ jiraIssueKey, jiraIssueUrl })
      .where(eq(initiatives.id, id))
      .returning();
    return updated;
  }

  async createDecisionRecord(data: InsertDecisionRecord & { dueDate?: Date }): Promise<DecisionRecord> {
    const [created] = await db.insert(decisionRecords).values({
      workspaceId: data.workspaceId!,
      recommendationId: data.recommendationId ?? null,
      opportunityId: data.opportunityId ?? null,
      initiativeId: data.initiativeId ?? null,
      decision: data.decision!,
      reason: data.reason ?? null,
      expectedKpiImpact: data.expectedKpiImpact ?? null,
      owner: data.owner ?? null,
      dueDate: data.dueDate ?? null,
    }).returning();
    return created;
  }

  async getDecisionRecords(workspaceId: string): Promise<DecisionRecord[]> {
    return db.select().from(decisionRecords)
      .where(eq(decisionRecords.workspaceId, workspaceId))
      .orderBy(desc(decisionRecords.createdAt));
  }

  async getDecisionRecordsByInitiative(initiativeId: string): Promise<DecisionRecord[]> {
    return db.select().from(decisionRecords)
      .where(eq(decisionRecords.initiativeId, initiativeId))
      .orderBy(desc(decisionRecords.createdAt));
  }

  async createOutcomeCheck(data: InsertOutcomeCheck): Promise<OutcomeCheck> {
    const [created] = await db.insert(outcomeChecks).values({
      initiativeId: data.initiativeId!,
      workspaceId: data.workspaceId!,
      checkType: data.checkType!,
      scheduledAt: data.scheduledAt!,
    }).returning();
    return created;
  }

  async getOutcomeChecksByInitiative(initiativeId: string): Promise<OutcomeCheck[]> {
    return db.select().from(outcomeChecks)
      .where(eq(outcomeChecks.initiativeId, initiativeId))
      .orderBy(desc(outcomeChecks.scheduledAt));
  }

  async getPendingOutcomeChecks(): Promise<OutcomeCheck[]> {
    return db.select().from(outcomeChecks)
      .where(and(
        eq(outcomeChecks.status, "pending"),
        sql`${outcomeChecks.scheduledAt} <= NOW()`
      ));
  }

  async completeOutcomeCheck(id: string, metrics: any, resultSummary: string, slackNotified: boolean): Promise<OutcomeCheck | undefined> {
    const [updated] = await db.update(outcomeChecks)
      .set({
        status: "completed",
        metrics,
        resultSummary,
        slackNotified,
        completedAt: new Date(),
      })
      .where(eq(outcomeChecks.id, id))
      .returning();
    return updated;
  }

  async failOutcomeCheck(id: string, resultSummary: string): Promise<OutcomeCheck | undefined> {
    const [updated] = await db.update(outcomeChecks)
      .set({
        status: "failed",
        resultSummary,
        completedAt: new Date(),
      })
      .where(eq(outcomeChecks.id, id))
      .returning();
    return updated;
  }

  async getDashboardStats(ownerId: string): Promise<{
    totalSignals: number;
    totalOpportunities: number;
    avgScore: number;
    topOpportunities: (Opportunity & { evidenceCount: number })[];
    recentSignals: Signal[];
    statusBreakdown: Record<string, number>;
  }> {
    const ws = await this.getWorkspacesByOwner(ownerId);
    if (ws.length === 0) {
      return {
        totalSignals: 0,
        totalOpportunities: 0,
        avgScore: 0,
        topOpportunities: [],
        recentSignals: [],
        statusBreakdown: {},
      };
    }

    const wsIds = ws.map((w) => w.id);
    let totalSignals = 0;
    let totalOpps = 0;
    let scoreSum = 0;
    const allOpps: Opportunity[] = [];
    const statusMap: Record<string, number> = {};

    for (const wsId of wsIds) {
      const sigs = await db.select({ count: count() }).from(signals).where(eq(signals.workspaceId, wsId));
      totalSignals += sigs[0]?.count ?? 0;

      const opps = await db.select().from(opportunities).where(eq(opportunities.workspaceId, wsId));
      totalOpps += opps.length;
      for (const o of opps) {
        scoreSum += o.score;
        statusMap[o.status] = (statusMap[o.status] ?? 0) + 1;
        allOpps.push(o);
      }
    }

    allOpps.sort((a, b) => b.score - a.score);
    const top5 = allOpps.slice(0, 5);
    const topWithEvidence = [];
    for (const opp of top5) {
      const evCount = await db.select({ count: count() }).from(evidence).where(eq(evidence.opportunityId, opp.id));
      topWithEvidence.push({ ...opp, evidenceCount: evCount[0]?.count ?? 0 });
    }

    const recentSigs = await db.select().from(signals).orderBy(desc(signals.createdAt)).limit(5);

    return {
      totalSignals,
      totalOpportunities: totalOpps,
      avgScore: totalOpps > 0 ? scoreSum / totalOpps : 0,
      topOpportunities: topWithEvidence,
      recentSignals: recentSigs,
      statusBreakdown: statusMap,
    };
  }
  async updateSignalNorm(id: string, data: { normTopic: string; normTags: any; normCacheKey: string }): Promise<void> {
    await db.update(signals)
      .set({
        normTopic: data.normTopic,
        normTags: data.normTags,
        normCacheKey: data.normCacheKey,
        normUpdatedAt: new Date(),
      })
      .where(eq(signals.id, id));
  }

  async getUnnormalizedSignals(workspaceId: string, externalIds: string[]): Promise<{ id: string }[]> {
    if (externalIds.length === 0) return [];
    return db.select({ id: signals.id })
      .from(signals)
      .where(
        and(
          eq(signals.workspaceId, workspaceId),
          inArray(signals.externalId, externalIds),
          isNull(signals.normTopic),
        )
      );
  }

  async getNormCache(cacheKey: string): Promise<AiNormalizationCache | undefined> {
    const [row] = await db.select().from(aiNormalizationCache)
      .where(eq(aiNormalizationCache.cacheKey, cacheKey));
    return row;
  }

  async setNormCache(cacheKey: string, result: any): Promise<void> {
    await db.insert(aiNormalizationCache)
      .values({ cacheKey, result })
      .onConflictDoNothing();
  }

  async enqueueAiJobs(jobs: { type: string; uniqueKey: string; payload: any }[]): Promise<number> {
    if (jobs.length === 0) return 0;
    const result = await db.insert(aiJobs)
      .values(jobs.map(j => ({
        type: j.type,
        uniqueKey: j.uniqueKey,
        payload: j.payload,
        status: "pending",
      })))
      .onConflictDoNothing();
    return result.rowCount ?? 0;
  }

  async getPendingAiJobs(limit: number): Promise<AiJob[]> {
    return db.select().from(aiJobs)
      .where(
        and(
          eq(aiJobs.status, "pending"),
          lte(aiJobs.runAt, new Date()),
        )
      )
      .orderBy(aiJobs.runAt)
      .limit(limit);
  }

  async markAiJobsRunning(ids: string[]): Promise<void> {
    if (ids.length === 0) return;
    await db.update(aiJobs)
      .set({ status: "running", updatedAt: new Date() })
      .where(inArray(aiJobs.id, ids));
  }

  async completeAiJob(id: string): Promise<void> {
    await db.update(aiJobs)
      .set({ status: "done", updatedAt: new Date() })
      .where(eq(aiJobs.id, id));
  }

  async failAiJob(id: string, error: string): Promise<void> {
    await db.update(aiJobs)
      .set({
        status: "failed",
        attempts: sql`${aiJobs.attempts} + 1`,
        lastError: error.slice(0, 400),
        updatedAt: new Date(),
      })
      .where(eq(aiJobs.id, id));
  }

  async retryAiJob(id: string, attempts: number, error: string): Promise<void> {
    await db.update(aiJobs)
      .set({
        status: "pending",
        attempts,
        lastError: error.slice(0, 400),
        updatedAt: new Date(),
      })
      .where(eq(aiJobs.id, id));
  }

  async resetStaleAiJobs(staleMs: number): Promise<number> {
    const cutoff = new Date(Date.now() - staleMs);
    const result = await db.update(aiJobs)
      .set({ status: "pending", updatedAt: new Date() })
      .where(
        and(
          eq(aiJobs.status, "running"),
          lt(aiJobs.updatedAt, cutoff)
        )
      )
      .returning({ id: aiJobs.id });
    return result.length;
  }

  async getAiQueueStats() {
    const rows = await db
      .select({
        status: aiJobs.status,
        cnt: count(),
      })
      .from(aiJobs)
      .groupBy(aiJobs.status);

    const statusMap: Record<string, number> = {};
    let total = 0;
    for (const r of rows) {
      statusMap[r.status] = Number(r.cnt);
      total += Number(r.cnt);
    }

    const doneCount = statusMap["done"] || 0;
    const failedCount = statusMap["failed"] || 0;
    const finishedCount = doneCount + failedCount;
    const successRate = finishedCount > 0 ? Math.round((doneCount / finishedCount) * 10000) / 100 : 100;

    const avgRows = await db
      .select({
        avgMs: sql<number>`COALESCE(AVG(EXTRACT(EPOCH FROM (${aiJobs.updatedAt} - ${aiJobs.createdAt})) * 1000), 0)`,
      })
      .from(aiJobs)
      .where(eq(aiJobs.status, "done"));

    const avgProcessingMs = Math.round(Number(avgRows[0]?.avgMs || 0));

    return {
      pending: statusMap["pending"] || 0,
      running: statusMap["running"] || 0,
      done: doneCount,
      failed: failedCount,
      total,
      successRate,
      avgProcessingMs,
    };
  }

  async getAlertRules(workspaceId: string): Promise<AlertRule[]> {
    return db.select().from(alertRules).where(eq(alertRules.workspaceId, workspaceId));
  }

  async createAlertRule(data: InsertAlertRule): Promise<AlertRule> {
    const [created] = await db.insert(alertRules).values(data).returning();
    return created;
  }

  async updateAlertRule(id: string, data: Partial<InsertAlertRule>): Promise<AlertRule | undefined> {
    const [updated] = await db.update(alertRules).set(data).where(eq(alertRules.id, id)).returning();
    return updated;
  }

  async deleteAlertRule(id: string): Promise<void> {
    await db.delete(alertRules).where(eq(alertRules.id, id));
  }

  async getAlertLogs(workspaceId: string, limit = 50): Promise<AlertLog[]> {
    return db.select().from(alertLogs)
      .where(eq(alertLogs.workspaceId, workspaceId))
      .orderBy(desc(alertLogs.sentAt))
      .limit(limit);
  }

  async getLastAlertForTopic(ruleId: string, topic: string): Promise<AlertLog | undefined> {
    const [log] = await db.select().from(alertLogs)
      .where(and(eq(alertLogs.ruleId, ruleId), eq(alertLogs.topic, topic)))
      .orderBy(desc(alertLogs.sentAt))
      .limit(1);
    return log;
  }

  async createAlertLog(data: { workspaceId: string; ruleId: string; topic: string; message: string; slackChannel?: string }): Promise<AlertLog> {
    const [created] = await db.insert(alertLogs).values(data).returning();
    return created;
  }

  async getAllEnabledAlertRules(): Promise<AlertRule[]> {
    return db.select().from(alertRules).where(eq(alertRules.enabled, true));
  }
}

export const storage = new DatabaseStorage();

import { storage } from "./storage";
import { getJiraDeliveryMetrics } from "./integrations/jira";
import { postToSlack } from "./slack";

interface OutcomeMetrics {
  voc?: { before: number; after: number; changePct: number };
  jira?: { bugCount: number; reopenCount: number; totalResolved: number };
  ga4?: { kpi: string; before: number; after: number; changePct: number };
  overallVerdict: "improved" | "no_change" | "worsened";
}

function computeVerdict(metrics: OutcomeMetrics): string {
  const parts: string[] = [];

  if (metrics.voc) {
    const dir = metrics.voc.changePct < -5 ? "reduced" : metrics.voc.changePct > 5 ? "increased" : "stable";
    parts.push(`VoC/Zendesk volume ${dir} (${metrics.voc.changePct > 0 ? "+" : ""}${metrics.voc.changePct.toFixed(0)}%): ${metrics.voc.before} -> ${metrics.voc.after}`);
  }

  if (metrics.jira) {
    parts.push(`Jira: ${metrics.jira.bugCount} bugs, ${metrics.jira.reopenCount} reopens, ${metrics.jira.totalResolved} resolved`);
  }

  if (metrics.ga4) {
    const dir = metrics.ga4.changePct > 5 ? "improved" : metrics.ga4.changePct < -5 ? "declined" : "stable";
    parts.push(`GA4 KPI "${metrics.ga4.kpi}" ${dir} (${metrics.ga4.changePct > 0 ? "+" : ""}${metrics.ga4.changePct.toFixed(1)}%): ${metrics.ga4.before} -> ${metrics.ga4.after}`);
  }

  if (parts.length === 0) {
    return "No integration data available for outcome check.";
  }

  const verdictEmoji = metrics.overallVerdict === "improved" ? "[improved]" :
    metrics.overallVerdict === "worsened" ? "[worsened]" : "[no_change]";

  const verdict = metrics.overallVerdict === "improved"
    ? "Initiative improved key metrics"
    : metrics.overallVerdict === "worsened"
      ? "No improvement detected -- recommend pivot or stop"
      : "Metrics stable -- continue monitoring";

  return `${verdictEmoji} ${verdict}. ${parts.join(". ")}.`;
}

export async function runOutcomeCheck(checkId: string): Promise<void> {
  const allPending = await storage.getPendingOutcomeChecks();
  const check = allPending.find(c => c.id === checkId);
  if (!check) {
    console.warn(`[outcome-checker] Check ${checkId} not found or not pending, skipping`);
    return;
  }

  const initiative = await storage.getInitiative(check.initiativeId);
  if (!initiative) {
    await storage.failOutcomeCheck(checkId, "Initiative not found");
    return;
  }

  const daysSinceShip = check.checkType === "7d" ? 7 : 14;
  const shippedAt = initiative.shippedAt || initiative.createdAt;
  const beforeStart = new Date(shippedAt.getTime() - daysSinceShip * 24 * 60 * 60 * 1000);

  const metrics: OutcomeMetrics = { overallVerdict: "no_change" };

  try {
    const topics = initiative.topics.map(t => t.topic);
    if (topics.length > 0) {
      const beforeSignals = await storage.getSignalsByTopicsInRange(
        initiative.workspaceId, topics, beforeStart, shippedAt
      );
      const afterSignals = await storage.getSignalsByTopicsInRange(
        initiative.workspaceId, topics, shippedAt, new Date()
      );
      const beforeCount = beforeSignals.length;
      const afterCount = afterSignals.length;
      const changePct = beforeCount > 0
        ? ((afterCount - beforeCount) / beforeCount) * 100
        : 0;

      metrics.voc = { before: beforeCount, after: afterCount, changePct };
    }
  } catch (err: any) {
    console.error(`[outcome-checker] VoC metric fetch failed: ${err.message}`);
  }

  try {
    const jiraMetrics = await getJiraDeliveryMetrics(initiative.workspaceId, daysSinceShip);
    if (jiraMetrics.bugCount > 0 || jiraMetrics.totalResolved > 0) {
      metrics.jira = jiraMetrics;
    }
  } catch (err: any) {
    console.error(`[outcome-checker] Jira metric fetch failed: ${err.message}`);
  }

  if (initiative.goalKpi) {
    try {
      const ga4Signals = await storage.getSignals(initiative.workspaceId);
      const kpiLower = initiative.goalKpi.toLowerCase();
      const ga4Before = ga4Signals.filter(s =>
        s.source === "ga4" &&
        s.title.toLowerCase().includes(kpiLower) &&
        s.createdAt >= beforeStart &&
        s.createdAt < shippedAt
      );
      const ga4After = ga4Signals.filter(s =>
        s.source === "ga4" &&
        s.title.toLowerCase().includes(kpiLower) &&
        s.createdAt >= shippedAt
      );
      if (ga4Before.length > 0 || ga4After.length > 0) {
        const beforeCount = ga4Before.length;
        const afterCount = ga4After.length;
        const changePct = beforeCount > 0 ? ((afterCount - beforeCount) / beforeCount) * 100 : 0;
        metrics.ga4 = { kpi: initiative.goalKpi, before: beforeCount, after: afterCount, changePct };
      }
    } catch (err: any) {
      console.error(`[outcome-checker] GA4 KPI check failed: ${err.message}`);
    }
  }

  let improvementSignals = 0;
  let worsenSignals = 0;

  if (metrics.voc) {
    if (metrics.voc.changePct < -10) improvementSignals++;
    else if (metrics.voc.changePct > 10) worsenSignals++;
  }
  if (metrics.jira) {
    if (metrics.jira.bugCount <= 2 && metrics.jira.reopenCount === 0) improvementSignals++;
    else if (metrics.jira.bugCount > 5 || metrics.jira.reopenCount > 2) worsenSignals++;
  }
  if (metrics.ga4) {
    if (metrics.ga4.changePct > 5) improvementSignals++;
    else if (metrics.ga4.changePct < -5) worsenSignals++;
  }

  if (improvementSignals > worsenSignals) metrics.overallVerdict = "improved";
  else if (worsenSignals > improvementSignals) metrics.overallVerdict = "worsened";

  const resultSummary = computeVerdict(metrics);

  let slackNotified = false;
  try {
    const slack = await storage.getSlackIntegration(initiative.workspaceId);
    if (slack && slack.enabled) {
      const verdictLine = metrics.overallVerdict === "improved"
        ? `*[WIN]* ${initiative.name} -- metrics improved`
        : metrics.overallVerdict === "worsened"
          ? `*[MISS]* ${initiative.name} -- consider pivot`
          : `*[WATCH]* ${initiative.name} -- no significant change`;

      const metricLines: string[] = [];
      if (metrics.voc) {
        metricLines.push(`VoC: ${metrics.voc.before} -> ${metrics.voc.after} (${metrics.voc.changePct > 0 ? "+" : ""}${metrics.voc.changePct.toFixed(0)}%)`);
      }
      if (metrics.jira) {
        metricLines.push(`Jira: ${metrics.jira.bugCount} bugs, ${metrics.jira.totalResolved} resolved`);
      }
      if (metrics.ga4) {
        metricLines.push(`GA4 "${metrics.ga4.kpi}": ${metrics.ga4.before} -> ${metrics.ga4.after} (${metrics.ga4.changePct > 0 ? "+" : ""}${metrics.ga4.changePct.toFixed(1)}%)`);
      }

      const slackMsg = [
        `*PivotLab -- Outcome Check (${check.checkType})*`,
        verdictLine,
        metricLines.length > 0 ? metricLines.join("\n") : "No integration data available",
        metrics.overallVerdict === "worsened" ? "\n> Recommendation: Review initiative and consider pivot or stop." : "",
      ].filter(Boolean).join("\n");

      await postToSlack(slack.webhookUrl, slackMsg);
      slackNotified = true;
    }
  } catch (err: any) {
    console.error(`[outcome-checker] Slack notification failed: ${err.message}`);
  }

  await storage.completeOutcomeCheck(checkId, metrics, resultSummary, slackNotified);
}

export async function processAllPendingOutcomeChecks(): Promise<number> {
  const pending = await storage.getPendingOutcomeChecks();
  let processed = 0;

  for (const check of pending) {
    try {
      await runOutcomeCheck(check.id);
      processed++;
    } catch (err: any) {
      console.error(`[outcome-checker] Failed check ${check.id}: ${err.message}`);
      await storage.failOutcomeCheck(check.id, err.message);
    }
  }

  return processed;
}

export async function scheduleOutcomeChecks(initiativeId: string, workspaceId: string, shippedAt: Date): Promise<void> {
  const day7 = new Date(shippedAt.getTime() + 7 * 24 * 60 * 60 * 1000);
  const day14 = new Date(shippedAt.getTime() + 14 * 24 * 60 * 60 * 1000);

  await storage.createOutcomeCheck({
    initiativeId,
    workspaceId,
    checkType: "7d",
    scheduledAt: day7,
  });

  await storage.createOutcomeCheck({
    initiativeId,
    workspaceId,
    checkType: "14d",
    scheduledAt: day14,
  });
}

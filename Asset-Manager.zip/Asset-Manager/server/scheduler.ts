import cron from "node-cron";
import { db } from "./db";
import { eq } from "drizzle-orm";
import { jiraIntegrations, zendeskIntegrations } from "@shared/schema";
import { syncJira } from "./integrations/jira";
import { syncZendesk } from "./integrations/zendesk";
import { recomputeOpportunities } from "./recompute";
import { checkPivotRecommendations } from "./pivot-analysis";
import { processAllPendingOutcomeChecks } from "./outcome-checker";
import { runAiQueue } from "./ai/worker";
import { evaluateAlerts } from "./alert-evaluator";

export function startScheduler() {
  cron.schedule(
    "10 4 * * *",
    async () => {
      console.log("[scheduler] Starting daily sync...");

      const enabledIntegrations = await db
        .select({ workspaceId: jiraIntegrations.workspaceId })
        .from(jiraIntegrations)
        .where(eq(jiraIntegrations.enabled, true));

      for (const w of enabledIntegrations) {
        try {
          await syncJira(w.workspaceId);
          await recomputeOpportunities(w.workspaceId);
          console.log(`[scheduler] synced + recomputed for workspace ${w.workspaceId}`);
        } catch (e: any) {
          console.error(`[scheduler] failed workspace ${w.workspaceId}:`, e?.message ?? e);
        }
      }

      const zendeskWorkspaces = await db
        .select({ workspaceId: zendeskIntegrations.workspaceId })
        .from(zendeskIntegrations)
        .where(eq(zendeskIntegrations.enabled, true));

      for (const w of zendeskWorkspaces) {
        try {
          await syncZendesk(w.workspaceId);
          await recomputeOpportunities(w.workspaceId);
          console.log(`[scheduler] zendesk synced + recomputed for ${w.workspaceId}`);
        } catch (e: any) {
          console.error(`[scheduler] zendesk failed ${w.workspaceId}:`, e?.message ?? e);
        }
      }

      try {
        await checkPivotRecommendations();
        console.log("[scheduler] pivot analysis complete");
      } catch (e: any) {
        console.error("[scheduler] pivot analysis failed:", e?.message ?? e);
      }

      try {
        const processed = await processAllPendingOutcomeChecks();
        console.log(`[scheduler] outcome checks processed: ${processed}`);
      } catch (e: any) {
        console.error("[scheduler] outcome checks failed:", e?.message ?? e);
      }

      if (process.env.OPENAI_API_KEY) {
        try {
          const queueResult = await runAiQueue(60);
          console.log("[scheduler] AI queue processed:", queueResult);
        } catch (e: any) {
          console.error("[scheduler] AI queue failed:", e?.message ?? e);
        }
      }

      try {
        const alertResult = await evaluateAlerts();
        console.log("[scheduler] Alerts evaluated:", alertResult);
      } catch (e: any) {
        console.error("[scheduler] Alert evaluation failed:", e?.message ?? e);
      }

      console.log("[scheduler] Daily sync complete.");
    },
    { timezone: "America/New_York" }
  );

  console.log("[scheduler] Cron job registered: daily at 4:10 AM ET");
}

import { storage } from "./storage";
import { db } from "./db";
import { users } from "@shared/schema";
import { count } from "drizzle-orm";
import { scrypt, randomBytes } from "crypto";
import { promisify } from "util";

const scryptAsync = promisify(scrypt);

async function hashPassword(password: string): Promise<string> {
  const salt = randomBytes(16).toString("hex");
  const buf = (await scryptAsync(password, salt, 64)) as Buffer;
  return `${buf.toString("hex")}.${salt}`;
}

export async function seedDatabase() {
  const [{ count: userCount }] = await db.select({ count: count() }).from(users);
  if (userCount > 0) return;

  console.log("Seeding database with example data...");

  const hashedPw = await hashPassword("demo123");
  const demoUser = await storage.createUser({
    username: "demo",
    password: hashedPw,
    displayName: "Demo User",
  });

  const org = await storage.createOrganization({
    name: "Acme Corp",
    ownerId: demoUser.id,
  });

  const ws1 = await storage.createWorkspace({
    orgId: org.id,
    name: "Mobile App",
    description: "iOS and Android consumer application",
  });

  const ws2 = await storage.createWorkspace({
    orgId: org.id,
    name: "API Platform",
    description: "Developer API and integrations",
  });

  const ws3 = await storage.createWorkspace({
    orgId: org.id,
    name: "Web Dashboard",
    description: "Admin and analytics dashboard",
  });

  await storage.upsertConstraint({
    workspaceId: ws1.id,
    primaryKpi: "conversion rate",
    targetValue: 5.0,
    budgetCap: 50000,
    deadlineDate: new Date("2026-06-30"),
  });

  await storage.upsertConstraint({
    workspaceId: ws2.id,
    primaryKpi: "api response time",
    targetValue: 200,
    budgetCap: 30000,
  });

  const mobileSignals = [
    { source: "reviews", kind: "voc", title: "App crashes during checkout", topic: "checkout", body: "Multiple users report the app freezing when they try to complete a purchase. This happens especially on older Android devices. The conversion rate drops significantly.", severity: 5 },
    { source: "support", kind: "voc", title: "Cannot find saved items", topic: "navigation", body: "Users are confused by the navigation. They save items to favorites but can't find the favorites section. Need clearer navigation structure.", severity: 3 },
    { source: "analytics", kind: "metric", title: "High drop-off at onboarding step 3", topic: "onboarding", body: "72% of users abandon the app at the third onboarding screen where we ask for phone number verification. This is hurting our conversion rate.", severity: 4 },
    { source: "support", kind: "voc", title: "Search results are irrelevant", topic: "search", body: "Customers complain that search doesn't return what they expect. Typos aren't handled and results seem random. Impacts conversion rate.", severity: 4 },
    { source: "reviews", kind: "voc", title: "Love the new dark mode", topic: "ui", body: "Users are very positive about the dark mode feature. Many 5-star reviews mention it specifically.", severity: 1 },
    { source: "analytics", kind: "metric", title: "Push notification opt-in declining", topic: "notifications", body: "Push notification opt-in rate has dropped from 68% to 42% over the last quarter. Users seem annoyed by frequency.", severity: 3 },
    { source: "jira", kind: "delivery", title: "Payment gateway timeout issues", topic: "checkout", body: "Engineering reports intermittent timeouts with the payment gateway. 2% of transactions fail silently. Directly impacts conversion rate.", severity: 5 },
    { source: "surveys", kind: "voc", title: "Users want social login", topic: "onboarding", body: "Survey results show 65% of respondents prefer social login (Google/Apple) over email. Current email-only flow is a barrier.", severity: 3 },
    { source: "support", kind: "voc", title: "Order tracking is confusing", topic: "orders", body: "Many support tickets about order status confusion. Users don't understand the difference between 'processing' and 'shipped'.", severity: 3 },
    { source: "analytics", kind: "metric", title: "Cart abandonment at 78%", topic: "checkout", body: "Cart abandonment rate is 78%, well above industry average. The checkout flow has too many steps and the conversion rate suffers.", severity: 4 },
  ];

  for (const s of mobileSignals) {
    await storage.createSignal({ workspaceId: ws1.id, ...s });
  }

  const apiSignals = [
    { source: "support", kind: "voc", title: "Rate limiting is too aggressive", topic: "rate limits", body: "Enterprise customers report being rate limited during peak hours. Current 100 req/min limit is insufficient for their use cases. Affects api response time.", severity: 4 },
    { source: "analytics", kind: "metric", title: "P95 latency spiking on /users endpoint", topic: "performance", body: "The /users endpoint P95 latency has increased from 150ms to 800ms. Database queries need optimization. api response time is degraded.", severity: 5 },
    { source: "jira", kind: "delivery", title: "Webhook delivery failures", topic: "webhooks", body: "15% of webhook deliveries are failing with timeouts. Retry logic needs improvement.", severity: 4 },
    { source: "reviews", kind: "voc", title: "Documentation is outdated", topic: "docs", body: "Several developers have complained that API documentation doesn't match actual behavior. Missing examples for new endpoints.", severity: 3 },
    { source: "support", kind: "voc", title: "Need batch endpoint for bulk operations", topic: "batch api", body: "Multiple enterprise customers requesting a batch API endpoint to reduce number of individual requests and improve api response time.", severity: 3 },
  ];

  for (const s of apiSignals) {
    await storage.createSignal({ workspaceId: ws2.id, ...s });
  }

  const webSignals = [
    { source: "analytics", kind: "metric", title: "Dashboard load time is 8 seconds", topic: "performance", body: "The main dashboard takes 8 seconds to fully render. Too many API calls happening sequentially.", severity: 4 },
    { source: "support", kind: "voc", title: "Export to CSV broken for large datasets", topic: "exports", body: "Users report that CSV exports time out when there are more than 10,000 rows of data.", severity: 3 },
    { source: "internal", kind: "delivery", title: "Chart library has security vulnerability", topic: "security", body: "The current charting library has a known XSS vulnerability. Need to upgrade or replace.", severity: 5 },
  ];

  for (const s of webSignals) {
    await storage.createSignal({ workspaceId: ws3.id, ...s });
  }

  const { recomputeOpportunities } = await import("./recompute");
  await recomputeOpportunities(ws1.id);
  await recomputeOpportunities(ws2.id);
  await recomputeOpportunities(ws3.id);

  console.log("Seed data created successfully!");
}

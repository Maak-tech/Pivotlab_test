import { sql } from "drizzle-orm";
import { pgTable, text, varchar, integer, real, timestamp, uniqueIndex, boolean, jsonb } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const users = pgTable("users", {
  id: varchar("id", { length: 36 }).primaryKey().default(sql`gen_random_uuid()`),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
  displayName: text("display_name"),
  role: text("role").default("admin").notNull(),
  plan: text("plan").default("free").notNull(),
  stripeCustomerId: text("stripe_customer_id"),
  stripeSubscriptionId: text("stripe_subscription_id"),
});

export const insertUserSchema = createInsertSchema(users).pick({
  username: true,
  password: true,
  displayName: true,
});
export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;

export const organizations = pgTable("organizations", {
  id: varchar("id", { length: 36 }).primaryKey().default(sql`gen_random_uuid()`),
  name: text("name").notNull(),
  ownerId: varchar("owner_id", { length: 36 }).notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const insertOrganizationSchema = createInsertSchema(organizations).pick({
  name: true,
  ownerId: true,
});
export type InsertOrganization = z.infer<typeof insertOrganizationSchema>;
export type Organization = typeof organizations.$inferSelect;

export const workspaces = pgTable("workspaces", {
  id: varchar("id", { length: 36 }).primaryKey().default(sql`gen_random_uuid()`),
  orgId: varchar("org_id", { length: 36 }).notNull(),
  name: text("name").notNull(),
  description: text("description"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const insertWorkspaceSchema = createInsertSchema(workspaces).pick({
  orgId: true,
  name: true,
  description: true,
});
export type InsertWorkspace = z.infer<typeof insertWorkspaceSchema>;
export type Workspace = typeof workspaces.$inferSelect;

export const constraints = pgTable("constraints", {
  workspaceId: varchar("workspace_id", { length: 36 }).primaryKey(),
  primaryKpi: text("primary_kpi"),
  targetValue: real("target_value"),
  budgetCap: real("budget_cap"),
  deadlineDate: timestamp("deadline_date"),
});

export const insertConstraintSchema = createInsertSchema(constraints).pick({
  workspaceId: true,
  primaryKpi: true,
  targetValue: true,
  budgetCap: true,
});
export type InsertConstraint = z.infer<typeof insertConstraintSchema>;
export type Constraint = typeof constraints.$inferSelect;

export const signals = pgTable("signals", {
  id: varchar("id", { length: 36 }).primaryKey().default(sql`gen_random_uuid()`),
  workspaceId: varchar("workspace_id", { length: 36 }).notNull(),
  source: text("source").notNull(),
  kind: text("kind").notNull(),
  title: text("title").notNull(),
  topic: text("topic"),
  body: text("body"),
  severity: integer("severity").default(3).notNull(),
  externalUrl: text("external_url"),
  externalId: text("external_id"),
  normTopic: text("norm_topic"),
  normTags: jsonb("norm_tags"),
  normUpdatedAt: timestamp("norm_updated_at"),
  normCacheKey: text("norm_cache_key"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
}, (table) => [
  uniqueIndex("workspace_external_id_idx").on(table.workspaceId, table.externalId),
]);

export const insertSignalSchema = createInsertSchema(signals).pick({
  workspaceId: true,
  source: true,
  kind: true,
  title: true,
  topic: true,
  body: true,
  severity: true,
  externalUrl: true,
  externalId: true,
});
export type InsertSignal = z.infer<typeof insertSignalSchema>;
export type Signal = typeof signals.$inferSelect;

export const opportunities = pgTable("opportunities", {
  id: varchar("id", { length: 36 }).primaryKey().default(sql`gen_random_uuid()`),
  workspaceId: varchar("workspace_id", { length: 36 }).notNull(),
  key: text("key").notNull(),
  title: text("title").notNull(),
  problemStatement: text("problem_statement").notNull(),
  score: real("score").notNull(),
  confidence: real("confidence").notNull(),
  status: text("status").notNull().default("open"),
  aiSummary: text("ai_summary"),
  aiTags: jsonb("ai_tags"),
  aiRationale: text("ai_rationale"),
  aiCacheKey: text("ai_cache_key"),
  aiUpdatedAt: timestamp("ai_updated_at"),
  sourceBreakdown: jsonb("source_breakdown"),
  trendDirection: text("trend_direction"),
  trendPercent: real("trend_percent"),
  signalCount: integer("signal_count").default(0),
  jiraIssueKey: text("jira_issue_key"),
  jiraIssueUrl: text("jira_issue_url"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
}, (table) => [
  uniqueIndex("workspace_key_idx").on(table.workspaceId, table.key),
]);

export const insertOpportunitySchema = createInsertSchema(opportunities).pick({
  workspaceId: true,
  key: true,
  title: true,
  problemStatement: true,
  score: true,
  confidence: true,
  status: true,
});
export type InsertOpportunity = z.infer<typeof insertOpportunitySchema>;
export type Opportunity = typeof opportunities.$inferSelect;

export const evidence = pgTable("evidence", {
  id: varchar("id", { length: 36 }).primaryKey().default(sql`gen_random_uuid()`),
  opportunityId: varchar("opportunity_id", { length: 36 }).notNull(),
  kind: text("kind").notNull(),
  snippet: text("snippet"),
  url: text("url"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const insertEvidenceSchema = createInsertSchema(evidence).pick({
  opportunityId: true,
  kind: true,
  snippet: true,
  url: true,
});
export type InsertEvidence = z.infer<typeof insertEvidenceSchema>;
export type Evidence = typeof evidence.$inferSelect;

export const jiraIntegrations = pgTable("jira_integrations", {
  id: varchar("id", { length: 36 }).primaryKey().default(sql`gen_random_uuid()`),
  workspaceId: varchar("workspace_id", { length: 36 }).notNull().unique(),
  baseUrl: text("base_url").notNull(),
  email: text("email").notNull(),
  apiToken: text("api_token").notNull(),
  jql: text("jql").notNull(),
  enabled: boolean("enabled").default(true).notNull(),
  lastSyncedAt: timestamp("last_synced_at"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const insertJiraIntegrationSchema = createInsertSchema(jiraIntegrations).pick({
  workspaceId: true,
  baseUrl: true,
  email: true,
  apiToken: true,
  jql: true,
});
export type InsertJiraIntegration = z.infer<typeof insertJiraIntegrationSchema>;
export type JiraIntegration = typeof jiraIntegrations.$inferSelect;

export const zendeskIntegrations = pgTable("zendesk_integrations", {
  id: varchar("id", { length: 36 }).primaryKey().default(sql`gen_random_uuid()`),
  workspaceId: varchar("workspace_id", { length: 36 }).notNull().unique(),
  baseUrl: text("base_url").notNull(),
  email: text("email").notNull(),
  apiToken: text("api_token").notNull(),
  enabled: boolean("enabled").default(true).notNull(),
  startTime: integer("start_time").notNull(),
  cursor: text("cursor"),
  lastSyncedAt: timestamp("last_synced_at"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const insertZendeskIntegrationSchema = createInsertSchema(zendeskIntegrations).pick({
  workspaceId: true,
  baseUrl: true,
  email: true,
  apiToken: true,
  startTime: true,
});
export type InsertZendeskIntegration = z.infer<typeof insertZendeskIntegrationSchema>;
export type ZendeskIntegration = typeof zendeskIntegrations.$inferSelect;

export const initiatives = pgTable("initiatives", {
  id: varchar("id", { length: 36 }).primaryKey().default(sql`gen_random_uuid()`),
  workspaceId: varchar("workspace_id", { length: 36 }).notNull(),
  name: text("name").notNull(),
  goalKpi: text("goal_kpi"),
  targetValue: real("target_value"),
  startDate: timestamp("start_date").defaultNow().notNull(),
  endDate: timestamp("end_date"),
  killCriteria: jsonb("kill_criteria"),
  status: text("status").notNull().default("active"),
  shippedAt: timestamp("shipped_at"),
  jiraIssueKey: text("jira_issue_key"),
  jiraIssueUrl: text("jira_issue_url"),
  opportunityId: varchar("opportunity_id", { length: 36 }),
  recommendationId: varchar("recommendation_id", { length: 36 }),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const insertInitiativeSchema = createInsertSchema(initiatives).pick({
  workspaceId: true,
  name: true,
  goalKpi: true,
  targetValue: true,
  endDate: true,
  killCriteria: true,
  opportunityId: true,
  recommendationId: true,
});
export type InsertInitiative = z.infer<typeof insertInitiativeSchema>;
export type Initiative = typeof initiatives.$inferSelect;

export const initiativeTopics = pgTable("initiative_topics", {
  id: varchar("id", { length: 36 }).primaryKey().default(sql`gen_random_uuid()`),
  initiativeId: varchar("initiative_id", { length: 36 }).notNull(),
  topic: text("topic").notNull(),
}, (table) => [
  uniqueIndex("initiative_topic_unique").on(table.initiativeId, table.topic),
]);

export const insertInitiativeTopicSchema = createInsertSchema(initiativeTopics).pick({
  initiativeId: true,
  topic: true,
});
export type InsertInitiativeTopic = z.infer<typeof insertInitiativeTopicSchema>;
export type InitiativeTopic = typeof initiativeTopics.$inferSelect;

export const pivotRecommendations = pgTable("pivot_recommendations", {
  id: varchar("id", { length: 36 }).primaryKey().default(sql`gen_random_uuid()`),
  initiativeId: varchar("initiative_id", { length: 36 }).notNull(),
  type: text("type").notNull(),
  reason: text("reason").notNull(),
  confidence: real("confidence").notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const insertPivotRecommendationSchema = createInsertSchema(pivotRecommendations).pick({
  initiativeId: true,
  type: true,
  reason: true,
  confidence: true,
});
export type InsertPivotRecommendation = z.infer<typeof insertPivotRecommendationSchema>;
export type PivotRecommendation = typeof pivotRecommendations.$inferSelect;

export const slackIntegrations = pgTable("slack_integrations", {
  id: varchar("id", { length: 36 }).primaryKey().default(sql`gen_random_uuid()`),
  workspaceId: varchar("workspace_id", { length: 36 }).notNull().unique(),
  webhookUrl: text("webhook_url").notNull(),
  channelName: text("channel_name"),
  enabled: boolean("enabled").default(true).notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const insertSlackIntegrationSchema = createInsertSchema(slackIntegrations).pick({
  workspaceId: true,
  webhookUrl: true,
  channelName: true,
});
export type InsertSlackIntegration = z.infer<typeof insertSlackIntegrationSchema>;
export type SlackIntegration = typeof slackIntegrations.$inferSelect;

export const ga4Integrations = pgTable("ga4_integrations", {
  id: varchar("id", { length: 36 }).primaryKey().default(sql`gen_random_uuid()`),
  workspaceId: varchar("workspace_id", { length: 36 }).notNull().unique(),
  propertyId: text("property_id").notNull(),
  keyEvents: jsonb("key_events"),
  enabled: boolean("enabled").default(true).notNull(),
  lastSyncedAt: timestamp("last_synced_at"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const insertGa4IntegrationSchema = createInsertSchema(ga4Integrations).pick({
  workspaceId: true,
  propertyId: true,
  keyEvents: true,
});
export type InsertGa4Integration = z.infer<typeof insertGa4IntegrationSchema>;
export type Ga4Integration = typeof ga4Integrations.$inferSelect;

export const decisionRecords = pgTable("decision_records", {
  id: varchar("id", { length: 36 }).primaryKey().default(sql`gen_random_uuid()`),
  workspaceId: varchar("workspace_id", { length: 36 }).notNull(),
  recommendationId: varchar("recommendation_id", { length: 36 }),
  opportunityId: varchar("opportunity_id", { length: 36 }),
  initiativeId: varchar("initiative_id", { length: 36 }),
  decision: text("decision").notNull(),
  reason: text("reason"),
  expectedKpiImpact: text("expected_kpi_impact"),
  owner: text("owner"),
  dueDate: timestamp("due_date"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const insertDecisionRecordSchema = createInsertSchema(decisionRecords).pick({
  workspaceId: true,
  recommendationId: true,
  opportunityId: true,
  initiativeId: true,
  decision: true,
  reason: true,
  expectedKpiImpact: true,
  owner: true,
});
export type InsertDecisionRecord = z.infer<typeof insertDecisionRecordSchema>;
export type DecisionRecord = typeof decisionRecords.$inferSelect;

export const outcomeChecks = pgTable("outcome_checks", {
  id: varchar("id", { length: 36 }).primaryKey().default(sql`gen_random_uuid()`),
  initiativeId: varchar("initiative_id", { length: 36 }).notNull(),
  workspaceId: varchar("workspace_id", { length: 36 }).notNull(),
  checkType: text("check_type").notNull(),
  scheduledAt: timestamp("scheduled_at").notNull(),
  status: text("status").notNull().default("pending"),
  metrics: jsonb("metrics"),
  resultSummary: text("result_summary"),
  slackNotified: boolean("slack_notified").default(false).notNull(),
  completedAt: timestamp("completed_at"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const insertOutcomeCheckSchema = createInsertSchema(outcomeChecks).pick({
  initiativeId: true,
  workspaceId: true,
  checkType: true,
  scheduledAt: true,
});
export type InsertOutcomeCheck = z.infer<typeof insertOutcomeCheckSchema>;
export type OutcomeCheck = typeof outcomeChecks.$inferSelect;

export const aiNormalizationCache = pgTable("ai_normalization_cache", {
  id: varchar("id", { length: 36 }).primaryKey().default(sql`gen_random_uuid()`),
  cacheKey: text("cache_key").notNull().unique(),
  result: jsonb("result").notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});
export type AiNormalizationCache = typeof aiNormalizationCache.$inferSelect;

export const aiJobs = pgTable("ai_jobs", {
  id: varchar("id", { length: 36 }).primaryKey().default(sql`gen_random_uuid()`),
  type: text("type").notNull(),
  uniqueKey: text("unique_key").notNull().unique(),
  payload: jsonb("payload").notNull(),
  status: text("status").notNull().default("pending"),
  attempts: integer("attempts").notNull().default(0),
  lastError: text("last_error"),
  runAt: timestamp("run_at").defaultNow().notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});
export type AiJob = typeof aiJobs.$inferSelect;
export const aiJobStatusOptions = ["pending", "running", "done", "failed"] as const;

export const alertRules = pgTable("alert_rules", {
  id: varchar("id", { length: 36 }).primaryKey().default(sql`gen_random_uuid()`),
  workspaceId: varchar("workspace_id", { length: 36 }).notNull(),
  name: text("name").notNull(),
  topicPattern: text("topic_pattern"),
  conditions: jsonb("conditions").notNull(),
  scoreThreshold: real("score_threshold").default(10),
  cooldownHours: integer("cooldown_hours").default(24),
  slackChannel: text("slack_channel"),
  enabled: boolean("enabled").default(true).notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});
export type AlertRule = typeof alertRules.$inferSelect;
export const insertAlertRuleSchema = createInsertSchema(alertRules).pick({
  workspaceId: true,
  name: true,
  topicPattern: true,
  conditions: true,
  scoreThreshold: true,
  cooldownHours: true,
  slackChannel: true,
  enabled: true,
});
export type InsertAlertRule = z.infer<typeof insertAlertRuleSchema>;

export const alertLogs = pgTable("alert_logs", {
  id: varchar("id", { length: 36 }).primaryKey().default(sql`gen_random_uuid()`),
  workspaceId: varchar("workspace_id", { length: 36 }).notNull(),
  ruleId: varchar("rule_id", { length: 36 }).notNull(),
  topic: text("topic").notNull(),
  message: text("message").notNull(),
  slackChannel: text("slack_channel"),
  sentAt: timestamp("sent_at").defaultNow().notNull(),
});
export type AlertLog = typeof alertLogs.$inferSelect;

export const signalSourceOptions = ["reviews", "support", "analytics", "jira", "surveys", "social", "internal", "app_reviews", "zendesk", "intercom", "ga4"] as const;
export const signalKindOptions = ["voc", "metric", "delivery"] as const;
export const opportunityStatusOptions = ["open", "planned", "shipped", "rejected"] as const;
export const initiativeStatusOptions = ["active", "pivoted", "stopped", "shipped"] as const;
export const pivotTypeOptions = ["persevere", "cut_scope", "solution_pivot", "segment_pivot", "stop"] as const;
export const decisionOptions = ["accepted", "rejected"] as const;
export const outcomeCheckTypeOptions = ["7d", "14d"] as const;
export const outcomeCheckStatusOptions = ["pending", "completed", "failed"] as const;
